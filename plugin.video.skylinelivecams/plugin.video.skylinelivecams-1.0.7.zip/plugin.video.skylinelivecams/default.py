﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2025 realvito
    Skyline LiveCams
'''

from resources.lib.common import *
from resources.lib import navigator
params = dict(parse_qsl(sys.argv[2][1:]))


def run():
	if params:
		if params['mode'] == 'listPages':
			navigator.listPages(params['url'], params.get('extras', 'UNKNOWN'))
		elif params['mode'] == 'listCameras':
			navigator.listCameras(params['url'], params.get('page', 1), params.get('position', 0), params.get('extras', 'UNKNOWN'), params.get('selection', 'standard'))
		elif params['mode'] == 'playCODE':
			navigator.playCODE(params['IDENTiTY'], params.get('TITLE'), params.get('IMG'))
		elif params['mode'] == 'listFavorites':
			navigator.listFavorites()
		elif params['mode'] == 'favorit_construct':
			navigator.favorit_construct(**params)
		elif params['mode'] == 'callingMain':
			navigator.mainMenu()
			xbmc.executebuiltin(f"Container.Update({HOST_AND_PATH}, replace)")
			return sys.exit(0)
		elif params['mode'] == 'blankFUNC':
			pass
		elif params['mode'] == 'clear_storage':
			navigator.clear_storage()
		elif params['mode'] == 'aConfigs':
			addon.openSettings()
			xbmc.executebuiltin('Container.Refresh')
	else:
		DONE = False
		# FIX: Αλλαγή os.sep σε / για σωστή συμβατότητα στα VFS paths του Kodi
		firstSCRIPT = xbmcvfs.translatePath(f"special://home/addons/{addon_id}/lib/").encode('utf-8').decode('utf-8')
		UNO = os.path.join(firstSCRIPT, 'only_at_FIRSTSTART')
		if xbmcvfs.exists(UNO):
			SOURCE = xbmcvfs.translatePath(f"special://home/userdata/addon_data/{addon_id}/").encode('utf-8').decode('utf-8')
			if xbmcvfs.exists(SOURCE):
				try:
					xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{addon_id}","enabled":false}}}}')
					shutil.rmtree(SOURCE, ignore_errors=True)
				except: pass
				xbmcvfs.delete(UNO)
				xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{addon_id}","enabled":true}}}}')
				xbmc.sleep(500)
				DONE = True
			else:
				xbmcvfs.delete(UNO)
				xbmc.sleep(500)
				DONE = True
		else:
			DONE = True
			
		if DONE is True:
			if not xbmcvfs.exists(os.path.join(dataPath, 'settings.xml')):
				xbmcvfs.mkdirs(dataPath)
				xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")
			navigator.mainMenu()

run()