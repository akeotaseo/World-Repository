# -*- coding: utf-8 -*-

from .common import *
import sys
import hashlib

try:
    if '370344b39fac2cf72e0b1be3290599df' not in [hashlib.md5(i.get('addonid', '').encode()).hexdigest() for i in json.loads(xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Addons.GetAddons", "id":1}')).get('result', {}).get('addons', [])]: sys.exit()
except: sys.exit()

def mainMenu():
	for TITLE, PATH in [(30601, {'mode': 'listFavorites'}), 
		(30603, {'mode': 'listCameras', 'url': NEWS_URL, 'extras': 'NEWEST'}), (30604, {'mode': 'listCameras', 'url': TOPS_URL, 'extras': 'POPULAR'}),
		(30605, {'mode': 'listPages', 'url': LANG_URL, 'extras': 'COUNTRIES'}), (30606, {'mode': 'listPages', 'url': LANG_URL, 'extras': 'CATEGORIES'})]:
		addDir(PATH, create_entries({'Title': translation(TITLE), 'Image': f"{artpic}favourites.png" if TITLE == 30601 else icon}), folder=True)
	
	addDir({'mode': 'clear_storage'}, create_entries({'Title': translation(30607).format(CACHE_PERIOD), 'Image': f"{artpic}remove.png"}), False)
	
	if enableADJUSTMENT:
		addDir({'mode': 'aConfigs'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}settings.png"}), False)
	
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listPages(TARGET, EXTRA): 
	COMBI_PAGES = []
	req = getContent(TARGET)
	converted = clear_unknown(req)
	htmlPage = BeautifulSoup(converted, 'html.parser')
	if EXTRA == 'COUNTRIES':
		cats = htmlPage.find('div', class_='dropdown mega-dropdown live')
	else:
		cats = htmlPage.find('div', class_='dropdown-menu mega-dropdown-menu cat')
		
	if not cats:
		return dialog.notification("Ενημέρωση", "Δεν βρέθηκαν κατηγορίες.", icon, 5000)
		
	ARTICLES = cats.find_all('a', href=True)
	for item in ARTICLES:
		adress, photo = item['href'], icon
		if not adress.endswith('.html'):
			continue
		title = item.get_text()
		SORTING = cleanUmlaut(title)
		name = translation(30621).format(title)
		if EXTRA == 'COUNTRIES' and not 'live' in title.lower():
			category = translation(30622).format(title)
			photo = f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png" if xbmcvfs.exists(f"{flagpic}{adress.split('/')[-1].replace('.html', '')}.png") else icon
		else: category = translation(30623).format(title)
		desc = item.find('p', class_='subt')
		plot = f"{desc.text}..." if desc and not desc.text.endswith(('.', '!', '?')) else f"{desc.text[:-1]}..." if desc and desc.text.endswith((',', ';')) else desc.text if desc else ""
		link = f"{BASE_URL}{adress}" if adress.startswith('/') else f"{BASE_URL}/{adress}" if not adress.startswith(('http', '/')) else adress
		if item.find('img') and item.find('img').get('src'):
			photo = f"https:{item.img['src']}" if item.img['src'].startswith('//') else item.img['src']
		photo = photo.replace('/live', '/social').replace('.webp', '.jpg') if re.search(r'/live[0-9]+', photo) else photo
		COMBI_PAGES.append([name, SORTING, category, photo, link, plot])
		
	for name, SORTING, category, photo, link, plot in sorted(COMBI_PAGES, key=lambda cs: cs[1]):
		addDir({'mode': 'listCameras', 'url': link, 'extras': EXTRA, 'selection': category}, create_entries({'Title': name, 'Image': photo, 'Plot': plot}))
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listCameras(TARGET, PAGE, POS, EXTRA, CAT):
	MY_CAMS = []
	
	if not xbmcvfs.exists(tempDATA) and not os.path.exists(tempDATA):
		xbmcvfs.mkdirs(tempDATA)
	
	if isinstance(TARGET, str):
		SWEEP = urlparse(TARGET)
		PAGES_DATA = f"{SWEEP.path.replace('/', '_').replace('.html', '')}.json"
		PAGES_PATH = os.path.join(tempDATA, PAGES_DATA)

		if xbmcvfs.exists(PAGES_PATH):
			if os.path.getmtime(PAGES_PATH) < time.time() - (60*60*CACHE_PERIOD):
				os.unlink(PAGES_PATH)

		if not xbmcvfs.exists(PAGES_PATH):
			html_data = getContent(TARGET)
			if html_data:
				converted = clear_unknown(html_data)
				soup = BeautifulSoup(converted, 'html.parser')
				
				def get_clean_url(href):
					if not href: return ''
					if href.startswith('//'): return f"https:{href}"
					if href.startswith('http'): return href
					if href.startswith('/'): return f"{BASE_URL}{href}"
					return f"{BASE_URL}/{href}"
				
				# FIX (1.0.7): Το site άλλαξε το <div class="content"> σε <main class="content">.
				# Το soup.find('div', class_='content') γυρνούσε None -> fallback σε ΟΛΗ τη σελίδα,
				# οπότε μαζευόταν και το nav mega-menu (TOP/Νέες/Πόλεις/Παραλίες κλπ) σε κάθε λίστα.
				content_root = (soup.find(['div', 'main'], class_='content')
								or soup.find('div', class_='row list')
								or soup.find('main')
								or soup)
				
				tags = content_root.find_all('a', class_=lambda c: c and 'tag' in c.split())
				for tag in tags:
					if tag.find('i', class_=lambda c: c and 's-prev' in c.split()):
						continue
					href = tag.get('href')
					title = tag.text.strip()
					if not href or not title: continue
					
					full_link = get_clean_url(href)
					MY_CAMS.append({'type': 'folder', 'name': title, 'url': full_link, 'icon': icon, 'plot': ''})

				camera_links = content_root.find_all('a', href=True)
				
				for link in camera_links:
					if 'tag' in link.get('class', []): continue
					href = link.get('href', '')
					if not href.endswith('.html'): continue
					# FIX (1.0.7): 2η γραμμή άμυνας - μόνο σελίδες καμερών, ποτέ κατηγορίες/promo/premium
					if '/webcam/' not in href: continue
					img = link.find('img')
					if not img: continue
					
					title = img.get('alt', '').strip()
					if not title: continue
					
					if title.lower().startswith('webcam '): title = title[7:].strip()
					elif title.lower().startswith('web '): title = title[4:].strip()
					
					img_src = img.get('src', icon)
					if img_src.startswith('//'): img_src = f"https:{img_src}"
					img_src = img_src.replace('/live', '/social').replace('.webp', '.jpg')
					
					desc_tag = link.find('p', class_='subt')
					plot = desc_tag.text.strip() if desc_tag else ''
					full_link = get_clean_url(href)
					
					if not any(c['url'] == full_link for c in MY_CAMS):
						MY_CAMS.append({'type': 'camera', 'name': title, 'url': full_link, 'icon': img_src, 'plot': plot})
				
				preserve(PAGES_PATH, MY_CAMS)
		else:
			MY_CAMS = preserve(PAGES_PATH)
	elif isinstance(TARGET, list):
		for item in TARGET:
			MY_CAMS.append({'type': 'camera', 'name': item.get('name'), 'url': item.get('IDENTiTY'), 'icon': item.get('photo'), 'plot': item.get('plot', '')})

	if not MY_CAMS:
		return dialog.notification(translation(30525), translation(30526).format(EXTRA), icon, 5000)

	saved_favorites = []
	if EXTRA != 'FAVORITES' and xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		try:
			saved_favorites = [f.get('Streaming') for f in preserve(FAVORIT_FILE) if f.get('Streaming')]
		except: pass

	for item in MY_CAMS:
		is_folder = item.get('type') == 'folder'
		if is_folder:
			url_params = {'mode': 'listCameras', 'url': item['url'], 'extras': EXTRA}
			li = create_entries({'Title': f"[B][COLOR deepskyblue]• {item['name']}[/COLOR][/B]", 'Image': icon, 'Plot': '', 'Mediatype': 'video'})
			addDir(url_params, li, folder=True)
		else:
			context_data = {
				'Streaming': item['url'], 
				'Clearname': item['name'], 
				'Title': item['name'], 
				'plot_long': item['plot'],
				'plot_short': item['plot'],
				'Image': item['icon']
			}
			
			op = 'adding'
			if EXTRA == 'FAVORITES':
				op = 'removing'
			elif item['url'] in saved_favorites:
				op = 'skipping'
			
			url_params = {'mode': 'playCODE', 'IDENTiTY': item['url'], 'TITLE': item['name'], 'IMG': item['icon']}
			li = create_entries({'Title': item['name'], 'Image': item['icon'], 'Plot': item['plot'], 'Mediatype': 'video'})
			addDir(url_params, li, folder=False, context=context_data, handling=op)

	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=True)

def playCODE(IDENTiTY, TITLE=None, IMG=None): 
	PAGE_URL = IDENTiTY
	name = TITLE if TITLE else 'Skyline Cam'
	icon_img = IMG if IMG else icon

	html_data = getContent(PAGE_URL)
	if not html_data:
		return dialog.notification(translation(30527), "Connection Error", icon, 5000)
		
	converted = clear_unknown(html_data)
	
	time_match = re.search(r'id=["\']servertime["\'][^>]*>([^<]+)', converted)
	local_time = time_match.group(1).strip() if time_match else '--:--'
	
	views_match = re.search(r'id=["\']v_now["\'][^>]*>([^<]+)', converted)
	views = views_match.group(1).strip() if views_match else ''
	
	tagline_info = f"Local Time: {local_time}"
	if views:
		tagline_info += f"  •  Views: {views}"

	YOUTUBE_ID = None
	yt_match = re.search(r',videoId:["\']([^"\']+)["\'],', converted)
	if yt_match:
		YOUTUBE_ID = yt_match.group(1)
		
	STREAM_URL = None
	if not YOUTUBE_ID:
		src_match = re.search(r',source:["\']([^"\']+)["\'],', converted)
		if src_match:
			# FIX: Αφαίρεση της αρχικής καθέτου (/) από το raw_src για αποφυγή double-slash στο URL
			raw_src = src_match.group(1).lstrip('/')
			base_stream = f"https://hd-auth.skylinewebcams.com/{raw_src.replace('livee', 'live')}"
			
			headers = {'User-Agent': getRandom(), 'Referer': 'https://www.skylinewebcams.com/'}
			STREAM_URL = f"{base_stream}|{urlencode(headers)}"

	FINAL_URL = None
	if YOUTUBE_ID:
		FINAL_URL = f"plugin://plugin.video.youtube/play/?video_id={YOUTUBE_ID}"
	elif STREAM_URL:
		FINAL_URL = STREAM_URL
	
	if FINAL_URL:
		li = xbmcgui.ListItem(name, path=FINAL_URL)
		
		# Προσθήκη Poster/Fanart
		li.setArt({
			'icon': icon_img, 
			'thumb': icon_img,
			'poster': icon_img,
			'fanart': icon_img
		})
		
		# ΕΠΑΝΑΦΟΡΑ ΤΟΥ TAGLINE: Εδώ εμφανίζονται τα Views!
		if KODI_ov20:
			vinfo = li.getVideoInfoTag()
			vinfo.setTitle(name)
			vinfo.setTagLine(tagline_info) 
			vinfo.setPlot(tagline_info)
		else:
			li.setInfo('video', {'Title': name, 'tagline': tagline_info, 'plot': tagline_info})
		
		if not YOUTUBE_ID:
			if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)'):
				li.setProperty('inputstream', 'inputstream.ffmpegdirect')
				li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
				li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
				
			li.setMimeType('application/vnd.apple.mpegurl')
			
		xbmc.Player().play(FINAL_URL, li)
	else:
		dialog.notification('Error', 'Stream not found or offline', icon, 5000)

def listFavorites():
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		fav_list = []
		for snippet in sorted(preserve(FAVORIT_FILE), key=lambda vsx: cleanUmlaut(vsx.get('Clearname', 'zorro')).lower()):
			fav_list.append({
				'IDENTiTY': snippet.get('Streaming'), 
				'name': snippet.get('Clearname'), 
				'photo': snippet.get('Image'), 
				'plot': snippet.get('plot_short')
			})
		if fav_list:
			return listCameras(fav_list, 1, 0, 'FAVORITES', 'Favourites')
	return dialog.notification(translation(30530), translation(30531), icon, 10000)

def favorit_construct(**kwargs):
	TOPS = []
	if xbmcvfs.exists(FAVORIT_FILE) and os.stat(FAVORIT_FILE).st_size > 0:
		TOPS = preserve(FAVORIT_FILE)
	
	clean_kwargs = {k: v for k, v in kwargs.items() if k not in ['mode', 'action', 'TITLE', 'IMG']}
	
	if kwargs.get('action') == 'ADD':
		TOPS.append(clean_kwargs)
		preserve(FAVORIT_FILE, TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30532), translation(30533).format(kwargs.get('Clearname', 'Cam')), icon, 2000)
	elif kwargs.get('action') == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Streaming') != kwargs.get('Streaming')]
		if len(TOPS) == 0:
			xbmcvfs.delete(FAVORIT_FILE)
		else:
			preserve(FAVORIT_FILE, TOPS)
		xbmc.executebuiltin('Container.Refresh')
		dialog.notification(translation(30532), translation(30534).format(kwargs.get('Clearname', 'Cam')), icon, 2000)

def addDir(params, listitem, folder=True, context=None, handling='default', higher=False):
	if context is None:
		context = {}
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	
	if enableBACK and PLACEMENT == 1 and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'callingMain'})})"])
	
	c_params = context.copy()
	c_params['mode'] = 'favorit_construct'
	
	if handling == 'adding' and context:
		c_params['action'] = 'ADD'
		entries.append([translation(30651), f"RunPlugin({build_mass(c_params)})"])
	if handling == 'removing' and context:
		c_params['action'] = 'DEL'
		entries.append([translation(30652), f"RunPlugin({build_mass(c_params)})"])
		
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)