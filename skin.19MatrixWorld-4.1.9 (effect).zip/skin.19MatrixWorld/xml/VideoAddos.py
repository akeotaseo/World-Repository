﻿import xbmc, xbmcgui

def VideoAddo():

    #xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR green]Last Played[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    #xbmc.executebuiltin("Action(back)")
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("ActivateWindow(Videos,Addons)")

VideoAddo()