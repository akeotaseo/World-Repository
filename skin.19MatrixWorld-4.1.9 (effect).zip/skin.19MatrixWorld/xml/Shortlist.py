﻿import xbmc, xbmcgui

def Shortlist():

    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR green]Shortlist[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.shortlist/?dbName=Shortlist")')

Shortlist()