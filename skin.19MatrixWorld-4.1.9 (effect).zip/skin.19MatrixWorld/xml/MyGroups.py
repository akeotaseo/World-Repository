﻿import xbmc, xbmcgui

def MyGroups():

    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR green]My Groups[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    #xbmc.executebuiltin("Action(back)")
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(2000)
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload)")

MyGroups()
