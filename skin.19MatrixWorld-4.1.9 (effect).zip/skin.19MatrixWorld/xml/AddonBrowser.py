﻿import xbmc

def AddonBrowser():
    xbmc.executebuiltin("Action(Close)")
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(AddonBrowser,return)')

AddonBrowser()
