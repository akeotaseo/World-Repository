﻿import xbmc, xbmcgui

def LastPlayed():

    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR green]Last Played[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')

    xbmc.executebuiltin("Action(Close)")
    #xbmc.executebuiltin("Action(Back)")
    xbmc.sleep(1000)

    xbmc.executebuiltin("RunAddon(plugin.video.last_played)")

LastPlayed()