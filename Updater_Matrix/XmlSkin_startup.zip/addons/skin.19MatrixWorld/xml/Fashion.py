import xbmc, xbmcgui


def Fashion():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Fashion[/COLOR][/B]',
['[COLOR=grey]Fashion TV Player[/COLOR]',

 '[COLOR aqua]Fashion Channel[/COLOR] ',
 '[COLOR=grey]Інше[/COLOR]  playlistloaderworld'])


    if call:
        if call < 1:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fashiontv.com/",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/channel/UCepVy23t8l-CEaASZzfo9Jg/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=http%3a%2f%2fimg.prosto.tv%2fstorage%2fchannel%2flogo%2fch00041.png&index=9&logos&mode=10&name=%d0%86%d0%bd%d1%88%d0%b5&url=http%3a%2f%2fmy.prosto.tv%2fa9g2n75r.m3u&uuid=0")')




Fashion()
