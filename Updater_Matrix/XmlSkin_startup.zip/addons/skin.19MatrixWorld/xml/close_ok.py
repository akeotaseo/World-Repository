# -*- coding: utf-8 -*-
import xbmc, xbmcgui, socket, importlib

# 1. Αποθηκεύουμε το βασικό παράθυρο και την κατηγορία που βρισκόταν ο χρήστης
start_win = xbmcgui.getCurrentWindowId()
home_win = xbmcgui.Window(10000)
last_cat_id = xbmc.getInfoLabel('Skin.String(LastFocusedCategory)')

# 2. Κλείνουμε αμέσως όποιο dialog είναι ανοιχτό τώρα (όποιο ID κι αν έχει)
curr_dlg = xbmcgui.getCurrentWindowDialogId()
if curr_dlg != 9999:
	xbmc.executebuiltin(f'Dialog.Close({curr_dlg},true)')
xbmc.executebuiltin('Dialog.Close(all,true)')

xbmcgui.Dialog().notification(
	'[B][COLOR orange]Κλείσιμο όλων...[/COLOR][/B]',
	'[COLOR white]Παρακαλώ περιμένετε...[/COLOR]',
	xbmcgui.NOTIFICATION_INFO,
	time=2500,
	sound=False
)

# 3. Παρακολουθούμε έως 7 δευτερόλεπτα (70 x 0.1s):
#    Εντοπίζει ΑΥΤΟΜΑΤΑ το ID οποιουδήποτε dialog ανοίξει (OK, YesNo, Select, 5004, ή οποιοδήποτε άλλο custom dialog)
#    και το κλείνει ακαριαία! Σταματάει αμέσως μετά από 1s ησυχίας.
quiet_ticks = 0

for _ in range(70):
	xbmc.sleep(100)
	closed_something = False

	dlg_id = xbmcgui.getCurrentWindowDialogId()
	# Το 9999 σημαίνει "κανένα ενεργό dialog". Οποιοσδήποτε άλλος αριθμός είναι ανοιχτό dialog!
	if dlg_id != 9999:
		xbmc.executebuiltin(f'Dialog.Close({dlg_id},true)')
		closed_something = True

	if closed_something:
		quiet_ticks = 0
	else:
		quiet_ticks += 1
		if quiet_ticks >= 10:
			break

# 4. Αν το script άνοιξε κανονικό παράθυρο (όχι dialog, π.χ. Ρυθμίσεις), επιστρέφουμε πίσω
if xbmcgui.getCurrentWindowId() != start_win:
	home_win.setProperty('BlockHomeAutoFocus', 'true')
	xbmc.executebuiltin('Dialog.Close(all,true)')
	xbmc.sleep(100)
	xbmc.executebuiltin('Action(PreviousMenu)')
	xbmc.sleep(300)

	if last_cat_id == '1':
		xbmc.executebuiltin('Control.SetFocus(9000,0,absolute)')

	home_win.clearProperty('BlockHomeAutoFocus')

# 5. Ακαριαίος καθαρισμός DNS/Socket της Python (0.001s)
try:
	importlib.reload(socket)
	socket.setdefaulttimeout(6)
except:
	pass

xbmcgui.Dialog().notification(
	'[B][COLOR lime]Έτοιμο![/COLOR][/B]',
	'[COLOR white]Τα παράθυρα έκλεισαν.[/COLOR]',
	xbmcgui.NOTIFICATION_INFO,
	time=1500,
	sound=False
)
