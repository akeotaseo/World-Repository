import xbmc, xbmcgui



def Basketball():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR orange]BASKETBALL[/COLOR][/B]',
['[COLOR=orange]Basketball / Microjen[/COLOR]  [COLORred][B]Daddylive[/COLOR][/B]',

 '[COLOR=orange]Basketball / Microjen[/COLOR]   [COLOR red]Live[COLOR white]TV.ru[/COLOR]'

 # '[COLOR=green]Volley[/COLOR] (Dracarys)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmcgui.Dialog().ok('[COLOR orange]BASKETBALL[/COLOR]', '[COLOR=orange](Microjen)[/COLOR][CR][CR]Επιλέγουμε την κατηγορία που μας ενδιαφέρει.')
    
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().notification("[B][COLOR orange]BASKETBALL[/COLOR][/B]", "Παρακαλώ περιμένετε...", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    
    # 1. Άνοιγμα του μενού του DaddyLive
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')
    
    # ⏱️ Περιμένουμε να φορτώσει το παράθυρο 10025
    timeout = 10
    while not xbmc.getCondVisibility('Window.IsActive(10025)') and timeout > 0:
        xbmc.sleep(200)
        timeout -= 1
        
    xbmc.sleep(1500) # Αέρας για το UI

    # 2. Στέλνουμε το focus στο Φίλτρο (ID 19) στα αριστερά
    xbmc.executebuiltin('SetFocus(19)')
    xbmc.sleep(400)

    # 3. Πατάμε "OK" για να ανοίξει το πληκτρολόγιο (DialogKeyboard.xml)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(1200) # Περιμένουμε να εμφανιστεί το πληκτρολόγιο στην οθόνη

    # 4. 🔥 THE BUTTON INJECTION AUTOMATION (CHECKMATE):
    # Κάνουμε focus και πατάμε ένα-ένα τα IDs των γραμμάτων που ανακάλυψες!
    
    # Γράμμα b (id 164)
    xbmc.executebuiltin('SetFocus(164)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα a (id 140)
    xbmc.executebuiltin('SetFocus(140)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα s (id 141)
    xbmc.executebuiltin('SetFocus(141)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα k (Όπως είδαμε, το k είναι δίπλα στο j, βάσει της φωτογραφίας σου είναι το id 147)
    xbmc.executebuiltin('SetFocus(147)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα e (id 122)
    xbmc.executebuiltin('SetFocus(122)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα t (id 124)
    xbmc.executebuiltin('SetFocus(124)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(250)
    
    # 5. Πατάμε το κουμπί "Τέλος" (id 300) για να κλείσει και να φιλτράρει!
    xbmc.executebuiltin('SetFocus(300)')
    xbmc.sleep(200)
    xbmc.executebuiltin('Action(Select)')
    
    xbmc.sleep(500)
    xbmc.executebuiltin('Action(Right)')
    
    # 6. Ειδοποιήσεις
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR orange]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/DL.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')


def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/set_setting_LivetvsxACE_off.py")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Basketball&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=Basketball%20(88)&url=sport%7cBasketball")')
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR darkorange]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR darkorange]BASKETBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')


Basketball()
