﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import threading
import sys
import socket


def _force_stop_worker():
    try:
        xbmc.executebuiltin('Playlist.Clear')
        xbmc.executebuiltin('PlayerControl(Stop)')
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()
    except Exception:
        pass


def universal_safe_stop():
    play_trailer_after = False
    if len(sys.argv) > 1 and 'play_trailer' in sys.argv[-1]:
        play_trailer_after = True

    is_video = xbmc.Player().isPlayingVideo()

    # 1. Καθαρισμός μνήμης & κλείσιμο OSD
    xbmc.executebuiltin('Dialog.Close(musicosd,true)')
    xbmc.executebuiltin('Dialog.Close(videoosd,true)')
    xbmc.executebuiltin('Skin.ResetString(HubMovieTrailer)')
    xbmc.executebuiltin('Skin.ResetString(HubTrailerActive)')

    # 2. Εκτέλεση Stop σε daemon thread ώστε αν κολλήσει το stream σε Android να ΜΗΝ παγώσει το Kodi
    t = threading.Thread(target=_force_stop_worker)
    t.daemon = True
    t.start()

    # 3. Reset socket timeout (χωρίς importlib.reload που κολλάει σε Android)
    xbmcgui.Window(10000).clearProperty('IPServiceRunning')
    try:
        socket.setdefaulttimeout(5)
    except Exception:
        pass

    # 4. Αναμονή μέχρι 2.0s για καθαρό κλείσιμο
    monitor = xbmc.Monitor()
    max_wait = 2.0 if is_video else 1.2
    waited = 0.0
    while xbmc.Player().isPlaying() and waited < max_wait and not monitor.abortRequested():
        if monitor.waitForAbort(0.25):
            return
        waited += 0.25

    if not xbmc.Player().isPlaying():
        xbmc.executebuiltin('UpdateLocalAddons()')

    xbmcgui.Window(10000).setProperty('TriggerIPCheck', 'true')
    xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')

    if play_trailer_after:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        trailer_url = xbmc.getInfoLabel('ListItem.Trailer')
        if trailer_url:
            xbmc.executebuiltin('PlayMedia(' + trailer_url + ')')


if __name__ == '__main__':
    universal_safe_stop()
