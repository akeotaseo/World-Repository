﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def universal_safe_stop():
    # 1. Έλεγχος: Αν παίζει βίντεο ή ραδιόφωνο
    is_video = xbmc.Player().isPlayingVideo()
    
    # 2. 🎬 ΚΑΘΑΡΙΣΜΟΣ ΤΡΕΪΛΕΡ: Σβήνουμε αμέσως το string από τη μνήμη για να ελευθερωθεί η RAM
    xbmc.executebuiltin('Skin.ResetString(HubMovieTrailer)')
    
    # 3. Πατάμε το STOP στο Kodi Core
    xbmc.executebuiltin('PlayerControl(Stop)')
    
    # 4. Καθαρίζουμε το Property της υπηρεσίας δικτύου για να ξεμπλοκάρει το Skin layout
    xbmcgui.Window(10000).clearProperty('IPServiceRunning')
    
    # 5. ⏳ THE BOX SHIELD: Έξυπνη αναμονή για να προλάβει το Boxάκι να κλείσει τα sockets
    if is_video:
        xbmc.sleep(2000)  # 2 δευτερόλεπτα για βαριά βίντεο/ταινίες
    else:
        xbmc.sleep(1200)  # 1.2 δευτερόλεπτο για live ραδιοφωνικά streams
        
    # 6. Εκτελούμε το UpdateLocalAddons (cURL Ghost Sockets Fix)
    xbmc.executebuiltin('UpdateLocalAddons()')
    
    # 7. 🎯 TRIGGER ΔΙΚΤΥΟΥ: Ξυπνάμε το service να ελέγξει την IP (αντί για το onclick στο XML)
    xbmcgui.Window(10000).setProperty('TriggerIPCheck', 'true')
    
    # 8. Επαναφορά της κατάστασης της υπηρεσίας σε Running
    xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')

if __name__ == '__main__':
    universal_safe_stop()
