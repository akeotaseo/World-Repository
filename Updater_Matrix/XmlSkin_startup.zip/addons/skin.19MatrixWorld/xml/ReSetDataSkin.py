﻿import os
import sys
import xml.etree.ElementTree as ET
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

LOCAL_SETTINGS = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/resources/default_settings.xml')


def _apply_local_settings(show_msg=True):
    if not os.path.exists(LOCAL_SETTINGS):
        if show_msg:
            xbmcgui.Dialog().ok(
                '[B][COLOR orange]World[/COLOR][/B]',
                f'Δεν βρέθηκε το αρχείο:\n{LOCAL_SETTINGS}'
            )
        return False

    try:
        tree = ET.parse(LOCAL_SETTINGS)
        root = tree.getroot()
        for setting in root.findall('setting'):
            s_id = setting.get('id', '')
            s_type = setting.get('type', '')
            s_val = setting.text or ''
            if not s_id:
                continue
            if s_type == 'bool':
                if s_val.lower() == 'true':
                    xbmc.executebuiltin(f'Skin.SetBool({s_id})')
                else:
                    xbmc.executebuiltin(f'Skin.Reset({s_id})')
            elif s_type == 'string':
                safe_val = s_val.replace('"', '\\"')
                xbmc.executebuiltin(f'Skin.SetString({s_id},"{safe_val}")')
    except Exception as e:
        if show_msg:
            xbmcgui.Dialog().ok('[B][COLOR orange]World[/COLOR][/B]', f'Σφάλμα ανάγνωσης XML:\n{e}')
        return False

    xbmc.executebuiltin('Skin.SetBool(WorldBuildInitialized)')
    xbmc.executebuiltin('Skin.SetBool(InitialSetUpRun)')
    xbmc.sleep(200)
    xbmc.executebuiltin('ReloadSkin()')

    if show_msg:
        xbmcgui.Dialog().notification(
            '[B][COLOR orange]World[/COLOR][/B]',
            'Επαναφέρθηκε το Προκαθορισμένο HOME MENU!',
            xbmcgui.NOTIFICATION_INFO,
            3500
        )
    return True


def ReSetDataSkin():
    if 'auto' in sys.argv:
        if not xbmc.getCondVisibility('Skin.HasSetting(WorldBuildInitialized)'):
            _apply_local_settings(show_msg=False)
        return

    try:
        if xbmc.getCondVisibility('System.HasAddon(plugin.program.downloader19)'):
            addon_d19 = xbmcaddon.Addon('plugin.program.downloader19')
            if addon_d19.getSetting('xmlskinversion') == '2046':
                xbmcgui.Dialog().ok(
                    '[COLOR red]ReSet[/COLOR] Data Skin',
                    'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin.'
                )
                return
    except Exception:
        pass

    choice = xbmcgui.Dialog().yesno(
        '[B][COLOR orange]World[/COLOR][/B]',
        'Επιστροφή στο Προκαθορισμένο [B]HOME MENU[/B].[CR]Θέλετε να εφαρμοστούν οι αλλαγές;',
        nolabel='Όχι',
        yeslabel='Ναι'
    )
    if choice:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ReplaceWindow(10000)')
        xbmc.sleep(200)
        _apply_local_settings(show_msg=True)


if __name__ == '__main__':
    ReSetDataSkin()
