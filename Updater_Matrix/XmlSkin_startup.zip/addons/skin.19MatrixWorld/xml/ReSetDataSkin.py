﻿import os
import sys
import xml.etree.ElementTree as ET
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

LOCAL_SETTINGS = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/resources/default_settings.xml')
USER_DATA_DIR  = xbmcvfs.translatePath('special://profile/addon_data/skin.19MatrixWorld/')
USER_SETTINGS  = os.path.join(USER_DATA_DIR, 'settings.xml')


def _is_skin_empty():
    # Αν λείπει η δική σου ρύθμιση (HomeItem.1.Label) από τη μνήμη του Kodi, το skin είναι "μαμά/άδειο"
    lbl1 = xbmc.getInfoLabel('Skin.String(HomeItem.1.Label)') or ''
    if not lbl1.strip():
        return True
    if not os.path.exists(USER_SETTINGS):
        return True
    try:
        if os.path.getsize(USER_SETTINGS) < 1500:
            return True
    except Exception:
        return True
    return False


def _apply_local_settings(show_msg=True):
    if not os.path.exists(LOCAL_SETTINGS):
        if show_msg:
            xbmcgui.Dialog().ok(
                '[B][COLOR orange]World[/COLOR][/B]',
                f'Δεν βρέθηκε το αρχείο:\n{LOCAL_SETTINGS}'
            )
        return False

    # 1. Αδειάζουμε τα μαμά/παλιά settings από τη μνήμη RAM του Kodi
    xbmc.executebuiltin('Skin.ResetSettings')
    xbmc.sleep(300)

    # 2. Διαβάζουμε το resources/default_settings.xml και περνάμε ΚΑΘΕ ρύθμιση ζωντανά στη RAM του Kodi
    try:
        tree = ET.parse(LOCAL_SETTINGS)
        root = tree.getroot()
        for setting in root.findall('setting'):
            s_id = setting.get('id', '')
            s_type = setting.get('type', '')
            s_val = setting.text or ''
            if not s_id:
                continue
            if s_type == 'bool':
                if s_val.lower() == 'true':
                    xbmc.executebuiltin(f'Skin.SetBool({s_id})')
                else:
                    xbmc.executebuiltin(f'Skin.Reset({s_id})')
            elif s_type == 'string':
                safe_val = s_val.replace('"', '\\"')
                xbmc.executebuiltin(f'Skin.SetString({s_id},"{safe_val}")')
    except Exception as e:
        if show_msg:
            xbmcgui.Dialog().ok('[B][COLOR orange]World[/COLOR][/B]', f'Σφάλμα ανάγνωσης XML:\n{e}')
        return False

    # Σημειώνουμε ότι έχει ήδη τρέξει το αρχικό setup ώστε να μην ξαναβγάλει wizard το Xonfluence
    xbmc.executebuiltin('Skin.SetBool(InitialSetUpRun)')
    xbmc.sleep(300)
    xbmc.executebuiltin('ReloadSkin()')

    if show_msg:
        xbmcgui.Dialog().notification(
            '[B][COLOR orange]World[/COLOR][/B]',
            'Επαναφέρθηκε το Προκαθορισμένο HOME MENU!',
            xbmcgui.NOTIFICATION_INFO,
            3500
        )
    return True


def ReSetDataSkin():
    is_auto = len(sys.argv) > 1 and sys.argv[1] == 'auto'
    if is_auto:
        if _is_skin_empty():
            _apply_local_settings(show_msg=False)
        return

    try:
        if xbmc.getCondVisibility('System.HasAddon(plugin.program.downloader19)'):
            addon_d19 = xbmcaddon.Addon('plugin.program.downloader19')
            if addon_d19.getSetting('xmlskinversion') == '2046':
                xbmcgui.Dialog().ok(
                    '[COLOR red]ReSet[/COLOR] Data Skin',
                    'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin.'
                )
                return
    except Exception:
        pass

    choice = xbmcgui.Dialog().yesno(
        '[B][COLOR orange]World[/COLOR][/B]',
        'Επιστροφή στο Προκαθορισμένο [B]HOME MENU[/B].[CR]Θέλετε να εφαρμοστούν οι αλλαγές;',
        nolabel='Όχι',
        yeslabel='Ναι'
    )
    if choice:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ReplaceWindow(10000)')
        xbmc.sleep(300)
        _apply_local_settings(show_msg=True)


if __name__ == '__main__':
    ReSetDataSkin()
