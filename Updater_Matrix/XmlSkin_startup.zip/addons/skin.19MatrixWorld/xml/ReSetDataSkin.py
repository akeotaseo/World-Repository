﻿import os
import sys
import shutil
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

LOCAL_SETTINGS = xbmcvfs.translatePath('special://skin/resources/default_settings.xml')
USER_DATA_DIR  = xbmcvfs.translatePath('special://profile/addon_data/skin.19MatrixWorld/')
USER_SETTINGS  = os.path.join(USER_DATA_DIR, 'settings.xml')


def _is_skin_empty():
    if not os.path.exists(USER_SETTINGS):
        return True
    try:
        if os.path.getsize(USER_SETTINGS) < 500:
            return True
        with open(USER_SETTINGS, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return 'HomeItem.1.Label' not in content
    except Exception:
        return True


def _apply_local_settings(show_msg=True):
    if not os.path.exists(LOCAL_SETTINGS):
        if show_msg:
            xbmcgui.Dialog().ok(
                '[B][COLOR orange]World[/COLOR][/B]',
                'Δεν βρέθηκε το τοπικό αρχείο ρυθμίσεων μέσα στο Skin!'
            )
        return False

    os.makedirs(USER_DATA_DIR, exist_ok=True)
    shutil.copy2(LOCAL_SETTINGS, USER_SETTINGS)
    xbmc.sleep(300)
    xbmc.executebuiltin('ReloadSkin()')
    if show_msg:
        xbmcgui.Dialog().notification(
            '[B][COLOR orange]World[/COLOR][/B]',
            'Επαναφέρθηκε το Προκαθορισμένο HOME MENU!',
            xbmcgui.NOTIFICATION_INFO,
            3500
        )
    return True


def ReSetDataSkin():
    is_auto = len(sys.argv) > 1 and sys.argv[1] == 'auto'
    if is_auto:
        if _is_skin_empty():
            _apply_local_settings(show_msg=False)
        return

    try:
        if xbmc.getCondVisibility('System.HasAddon(plugin.program.downloader19)'):
            addon_d19 = xbmcaddon.Addon('plugin.program.downloader19')
            if addon_d19.getSetting('xmlskinversion') == '2046':
                xbmcgui.Dialog().ok(
                    '[COLOR red]ReSet[/COLOR] Data Skin',
                    'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin.'
                )
                return
    except Exception:
        pass

    choice = xbmcgui.Dialog().yesno(
        '[B][COLOR orange]World[/COLOR][/B]',
        'Επιστροφή στο Προκαθορισμένο [B]HOME MENU[/B].[CR]Θέλετε να εφαρμοστούν οι αλλαγές;',
        nolabel='Όχι',
        yeslabel='Ναι'
    )
    if choice:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ReplaceWindow(10000)')
        _apply_local_settings(show_msg=True)


if __name__ == '__main__':
    ReSetDataSkin()
