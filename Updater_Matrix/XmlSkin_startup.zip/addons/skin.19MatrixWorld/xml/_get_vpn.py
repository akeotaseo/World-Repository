# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request
import json
import sys

xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
monitor = xbmc.Monitor()

# Κρατάμε τις αρχικές τιμές για LAN και WAN
last_local_ip = xbmc.getInfoLabel('Network.IPAddress')
last_wan_ip = xbmcgui.Window(10000).getProperty('MyWANIP')

def check_network_and_vpn():
    global last_wan_ip
    try:
        # 🎯 Χρησιμοποιούμε το ip-api με fields για Χώρα, IP, ISP και έλεγχο Hosting (VPN)
        url = 'http://ip-api.com/json'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=5).read().decode('utf8')
        data = json.loads(response)
        
        if data.get('status') == 'success':
            ip_addr = data.get('query', 'N/A')
            country = data.get('country', 'Greece')
            country_code = data.get('countryCode', 'GR').upper()
            is_hosting = data.get('hosting', False)
            isp = data.get('isp', '').lower()

            # 1. Αποθήκευση και ενημέρωση του WAN IP
            if ip_addr != 'N/A':
                xbmcgui.Window(10000).setProperty('MyWANIP', ip_addr)
                last_wan_ip = ip_addr  # Ενημέρωση της global μεταβλητής για το loop

            # 2. Έλεγχος αν είναι VPN (Είτε λόγω χώρας, είτε λόγω Hosting flag/ISP)
            if country_code != 'GR' or is_hosting or 'datacamp' in isp or 'vpn' in isp:
                xbmcgui.Window(10000).setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
            else:
                xbmcgui.Window(10000).setProperty('MyVPNState', '')

            # 3. Χρωματισμός της Χώρας (Μπλε για Ελλάδα, Πορτοκαλί για εξωτερικό)
            if country_code == 'GR':
                formatted_country = '[COLOR blue]' + country + '[/COLOR]'
            else:
                formatted_country = '[COLOR orange]' + country + '[/COLOR]'
                
            xbmcgui.Window(10000).setProperty('MyRealCountry', formatted_country)
            
    except:
        if not xbmcgui.Window(10000).getProperty('MyRealCountry'):
            xbmcgui.Window(10000).setProperty('MyRealCountry', '[COLOR cornflowerblue]Greece[/COLOR]')

# Πρώτο request στο boot
check_network_and_vpn()

was_playing_anything = False
loop_counter = 0

while not monitor.abortRequested():
    # 🕵️‍♂️ ΕΛΕΓΧΟΣ Α: ΑΛΛΑΓΗ ΤΟΠΙΚΟΥ ΔΙΚΤΥΟΥ (LAN IP)
    try:
        current_local_ip = xbmc.getInfoLabel('Network.IPAddress')
        if current_local_ip and not current_local_ip == last_local_ip:
            last_local_ip = current_local_ip
            monitor.waitForAbort(2.5)  # Χρόνος να κάτσει το νέο routing
            check_network_and_vpn()    
    except:
        pass

    # 🕵️‍♂️ ΕΛΕΓΧΟΣ Β: ΑΥΤΟΜΑΤΗ ΑΛΛΑΓΗ VPN ΣΕ VPN (Κάθε 6 δευτερόλεπτα)
    # Χτυπάει ένα υπερ-ελαφρύ endpoint που επιστρέφει ΜΟΝΟ την IP σε text, χωρίς JSON parsing, για οικονομία
    loop_counter += 1
    if loop_counter >= 3:  # 3 loops x 2 δευτερόλεπτα = 6 δευτερόλεπτα ελέγχου WAN IP
        loop_counter = 0
        try:
            req_fast = urllib.request.Request('https://icanhazip.com', headers={'User-Agent': 'Mozilla/5.0'})
            current_wan_ip = urllib.request.urlopen(req_fast, timeout=3).read().decode('utf8').strip()
            
            if current_wan_ip and current_wan_ip != last_wan_ip:
                xbmc.log("[World_Updater] Ραντάρ: Ανιχνεύτηκε αλλαγή στο WAN Route (VPN -> VPN). Ανανέωση...", xbmc.LOGINFO)
                check_network_and_vpn()
        except:
            pass

    # 🎯 ΜΟΛΙΣ ΠΑΤΗΘΕΙ STOP (CURL GHOST FIX)
    try:
        if xbmc.Player().isPlaying():
            was_playing_anything = True
        else:
            if was_playing_anything:
                xbmc.log("[World_Updater] Ανιχνεύτηκε STOP. Καθαρισμός sockets cURL.", xbmc.LOGINFO)
                xbmcgui.Window(10000).clearProperty('IPServiceRunning')
                xbmc.executebuiltin('UpdateLocalAddons()') 
                was_playing_anything = False
                monitor.waitForAbort(1.5)
                check_network_and_vpn() 
                xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
    except:
        pass

    # Χειροκίνητο Trigger από το Skin κουμπί
    if xbmcgui.Window(10000).getProperty('TriggerIPCheck') == 'true':
        xbmcgui.Window(10000).clearProperty('TriggerIPCheck')
        monitor.waitForAbort(0.5)
        check_network_and_vpn()

    # Έλεγχος loop ανά 2 δευτερόλεπτα
    if monitor.waitForAbort(2):
        break

xbmcgui.Window(10000).clearProperty('IPServiceRunning')
