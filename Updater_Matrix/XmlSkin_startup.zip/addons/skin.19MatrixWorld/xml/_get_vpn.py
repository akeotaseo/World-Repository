# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request
import json
import sys

xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
monitor = xbmc.Monitor()

# Κρατάμε τις αρχικές τιμές για LAN και WAN
last_local_ip = xbmc.getInfoLabel('Network.IPAddress')
last_wan_ip = xbmcgui.Window(10000).getProperty('MyWANIP')

def check_network_and_vpn(custom_timeout=5):
    global last_wan_ip
    try:
        # 🎯 Ρυθμιζόμενο timeout για να μην κλειδώνει η C++ Core αν κολλήσει το stream
        url = 'http://ip-api.com/json'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=custom_timeout).read().decode('utf8')
        data = json.loads(response)
        
        if data.get('status') == 'success':
            ip_addr = data.get('query', 'N/A')
            country = data.get('country', 'Greece')
            country_code = data.get('countryCode', 'GR').upper()
            is_hosting = data.get('hosting', False)
            isp = data.get('isp', '').lower()

            # 1. Αποθήκευση και ενημέρωση του WAN IP
            if ip_addr != 'N/A':
                xbmcgui.Window(10000).setProperty('MyWANIP', ip_addr)
                last_wan_ip = ip_addr

            # 2. Έλεγχος αν είναι VPN
            if country_code != 'GR' or is_hosting or 'datacamp' in isp or 'vpn' in isp:
                xbmcgui.Window(10000).setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
            else:
                xbmcgui.Window(10000).setProperty('MyVPNState', '')

            # 3. Χρωματισμός της Χώρας
            if country_code == 'GR':
                formatted_country = '[COLOR cornflowerblue]' + country + '[/COLOR]'
            else:
                formatted_country = '[COLOR orange]' + country + '[/COLOR]'
                
            xbmcgui.Window(10000).setProperty('MyRealCountry', formatted_country)
            
    except:
        if not xbmcgui.Window(10000).getProperty('MyRealCountry'):
            xbmcgui.Window(10000).setProperty('MyRealCountry', '[COLOR cornflowerblue]Greece[/COLOR]')

# Πρώτο request στο boot
check_network_and_vpn()

was_playing_anything = False
loop_counter = 0

while not monitor.abortRequested():
    # 🕵️‍♂️ ΕΛΕΓΧΟΣ Α: ΑΛΛΑΓΗ ΤΟΠΙΚΟΥ ΔΙΚΤΥΟΥ (LAN IP)
    try:
        current_local_ip = xbmc.getInfoLabel('Network.IPAddress')
        if current_local_ip and not current_local_ip == last_local_ip:
            last_local_ip = current_local_ip
            monitor.waitForAbort(2.5)
            check_network_and_vpn()    
    except:
        pass

    # 🕵️‍♂️ ΕΛΕΓΧΟΣ Β: ΑΥΤΟΜΑΤΗ ΑΛΛΑΓΗ VPN ΣΕ VPN (Κάθε 6 δευτερόλεπτα)
    loop_counter += 1
    if loop_counter >= 3:
        loop_counter = 0
        try:
            req_fast = urllib.request.Request('https://icanhazip.com', headers={'User-Agent': 'Mozilla/5.0'})
            current_wan_ip = urllib.request.urlopen(req_fast, timeout=3).read().decode('utf8').strip()
            
            if current_wan_ip and current_wan_ip != last_wan_ip:
                xbmc.log("[World_Updater] Ραντάρ: Ανιχνεύτηκε αλλαγή στο WAN Route. Ανανέωση...", xbmc.LOGINFO)
                check_network_and_vpn()
        except:
            pass

    # 🎯 ΜΟΛΙΣ ΠΑΤΗΘΕΙ STOP (CURL GHOST FIX)
    try:
        if xbmc.Player().isPlaying():
            was_playing_anything = True
        else:
            if was_playing_anything:
                xbmc.log("[World_Updater] Ανιχνεύτηκε STOP. Καθαρισμός sockets cURL.", xbmc.LOGINFO)
                
                # 1. Κλείνουμε αμέσως το property για να «ανασάνει» το skin
                xbmcgui.Window(10000).clearProperty('IPServiceRunning')
                
                # 2. Εκτελούμε το build update του Kodi
                xbmc.executebuiltin('UpdateLocalAddons()') 
                was_playing_anything = False
                
                # 3. ⏳ THE SAFETY BUFFER: Περιμένουμε 3 δευτερόλεπτα να πεθάνουν τελείως τα ghost sockets του ραδιοφώνου
                monitor.waitForAbort(3.0)
                
                # 4. Εκτελούμε τον έλεγχο με αυστηρό timeout 2 δευτερολέπτων για να μην hangάρει ΠΟΤΕ η Python
                check_network_and_vpn(custom_timeout=2) 
                
                # 5. Επαναφορά της υπηρεσίας
                xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
    except:
        pass

    # Χειροκίνητο Trigger από το Skin κουμπί
    if xbmcgui.Window(10000).getProperty('TriggerIPCheck') == 'true':
        xbmcgui.Window(10000).clearProperty('TriggerIPCheck')
        monitor.waitForAbort(0.5)
        check_network_and_vpn()

    if monitor.waitForAbort(2):
        break

xbmcgui.Window(10000).clearProperty('IPServiceRunning')
