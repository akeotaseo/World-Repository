# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request
import json
import sys

xbmcgui.Dialog().notification("[B][COLOR cornflowerblue]World Build[/COLOR][/B]", "[COLOR white]Υπηρεσία Δικτύου έτοιμη...[/COLOR]", icon='special://home/addons/skin.19MatrixWorld/media/_get_ip.png', sound=False)


xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
monitor = xbmc.Monitor()

def get_ip_data():
    try:
        req = urllib.request.Request('http://ip-api.com', headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=5).read().decode('utf8')
        data = json.loads(response)
        
        if data.get('status') == 'success':
            xbmcgui.Window(10000).setProperty('MyWANIP', data.get('query', 'N/A'))
            xbmcgui.Window(10000).setProperty('MyCountry', data.get('country', ''))
        else:
            xbmcgui.Window(10000).setProperty('MyWANIP', 'N/A')
            xbmcgui.Window(10000).setProperty('MyCountry', '')
            
    except Exception:
        xbmcgui.Window(10000).setProperty('MyWANIP', 'Σφάλμα')
        xbmcgui.Window(10000).setProperty('MyCountry', '')

# Πρώτο request στην εκκίνηση του Kodi
get_ip_data()

# 🛡️ ΚΑΘΟΛΙΚΟ ΧΕΙΡΟΦΡΕΝΟ ΓΙΑ ΟΛΑ ΤΑ ΠΡΟΣΘΕΤΑ (CURL GHOST FIX)
player = xbmc.Player()
was_playing_anything = False

# Αθόρυβη λούπα παρασκηνίου
while not monitor.abortRequested():
    
    try:
        # Ελέγχουμε αν παίζει ΟΠΟΙΟΔΗΠΟΤΕ media (Βίντεο, Live TV, Μουσική)
        if player.isPlaying():
            was_playing_anything = True
        else:
            if was_playing_anything:
                # 🎯 ΜΟΛΙΣ ΠΑΤΗΘΕΙ STOP ΣΕ ΟΤΙΔΗΠΟΤΕ
                xbmc.log("[World_Updater] Ανιχνεύτηκε STOP. Εκτέλεση καθολικού Network Flush για αποφυγή Android Deadlock.", xbmc.LOGINFO)
                
                # 🧼 Dynamic «κλώτσημα» στη cURL core του Kodi για να κλείσει τα κολλημένα sockets
                xbmc.executebuiltin('ClearProperty(IPServiceRunning,home)')
                xbmc.executebuiltin('UpdateLocalAddons()') # Force refresh των streams
                
                was_playing_anything = False
                
                # ⏳ Δίνουμε 1 δευτερόλεπτο αέρα στην κάρτα δικτύου του Android να συνέλθει
                xbmc.sleep(1000)
                
                # Ξανατρέχουμε τον έλεγχο IP. Αυτό το request αναγκάζει το Kodi 
                # να ανοίξει νέο, καθαρό socket και «ξυπνάει» αμέσως το internet!
                get_ip_data() 
    except Exception as e:
        xbmc.log(f"[World_Updater] Σφάλμα στον Player Monitor: {str(e)}", xbmc.LOGERROR)

    # Έλεγχος για χειροκίνητο Trigger από το μενού
    if xbmcgui.Window(10000).getProperty('TriggerIPCheck') == 'true':
        xbmcgui.Window(10000).clearProperty('TriggerIPCheck')
        get_ip_data() 
        
    # Έλεγχος κάθε 2 δευτερόλεπτα (Ακαριαία αντίδραση πριν προλάβει να παγώσει το σύστημα)
    if monitor.waitForAbort(2):
        break

# Καθαρισμός κατά το κλείσιμο του Kodi
xbmcgui.Window(10000).clearProperty('IPServiceRunning')
