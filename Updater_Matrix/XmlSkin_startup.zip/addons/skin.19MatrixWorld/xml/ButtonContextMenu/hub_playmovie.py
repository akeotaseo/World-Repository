﻿# -*- coding: utf-8 -*-
import xbmc
import time

def main():
    xbuiltin = xbmc.executebuiltin
    start_time = time.time()  # ⏱️ Το ρολόι για το 20αρο (7" και 13")
    icon_changed = False

    # 🔒 1. ΑΜΕΣΟ ΚΛΕΙΣΙΜΟ ΗΥΒ 6199
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(400) 

    # ⚡ ΑΡΧΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ ΤΟΥ ΠΡΟΗΓΟΥΜΕΝΟΥ PLAYER
    xbuiltin('Action(Stop)')
    xbuiltin('PlayerControl(Stop)')
    xbmc.sleep(350)

    # =======================================================================
    # ⚙️ ΔΥΝΑΜΙΚΑ ΔΕΔΟΜΕΝΑ
    # =======================================================================
    sound_file   = 'special://skin/sounds/fox.wav'
    icon_file_1  = 'special://home/addons/skin.19MatrixWorld/media/300.gif'
    icon_file_2  = 'special://home/addons/skin.19MatrixWorld/media/200.gif'
    title_text   = '[COLOR white]Αναζήτηση[/COLOR] [B][COLOR orange]Scrapers[/COLOR][/B]'
    msg_text     = '[COLOR red]Blacklodge[/COLOR]'
    # =======================================================================

    # 2. 📥 DYNAMIC INJECTION: Γεμίζουμε τη μνήμη του Skin
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file_1})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    
    # 🔔 ΑΝΟΙΓΜΑ CUSTOM POP-UP ΠΑΝΩ ΔΕΞΙΑ (4202)
    xbuiltin('ActivateWindow(4202)')
    xbmc.sleep(250)

    # =======================================================================
    # 🚀 3. Η ΑΠΟΛΥΤΗ ΠΑΡΑΚΑΜΨΗ (ΚΛΗΣΗ SCRAPER ΜΕΣΩ CONTRAINER PATH)
    # =======================================================================
    # 🎯 FORCE FOCUS LOCK στη λίστα 8044
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(250)

    # 🕵️‍♂️ Διαβάζουμε το FolderPath της ταινίας προσδιορίζοντας καρφωτά το Container(8044)
    target_path = xbmc.getInfoLabel('Container(8044).ListItem.FolderPath')

    # Αν η παραπάνω είναι άδεια, δοκιμάζουμε εναλλακτικές ετικέτες που χρησιμοποιεί το Kodi στα Skins
    if not target_path or target_path == '':
        target_path = xbmc.getInfoLabel('Container(8044).ListItem.FileNameAndPath')
    if not target_path or target_path == '':
        target_path = xbmc.getInfoLabel('ListItem.FolderPath')

    # 🔥 Αν βρήκαμε το URL της ταινίας, το εκτελούμε απευθείας στο background!
    if target_path and target_path != '' and "plugin://" in target_path:
        xbmc.log(f"[World_Hub] Εκκίνηση Scraper μέσω RunPlugin: {target_path}", xbmc.LOGINFO)
        xbuiltin(f'RunPlugin("{target_path}")')
    else:
        # 🎯 ΕΣΧΑΤΗ ΛΥΣΗ (Ασφάλεια): Αν τα paths βγαίνουν άδεια λόγω του custom skin, 
        # χρησιμοποιούμε το Action(Play) που ξέρουμε ότι δουλεύει στο PC, αλλά κλείνουμε το Trailer ακαριαία!
        xbmc.log("[World_Hub] Τα XML labels βγήκαν άδεια. Χρήση Safe Action Play.", xbmc.LOGINFO)
        xbuiltin('Action(Play)')
        xbmc.sleep(200)
        xbuiltin('Action(Stop)')
        xbuiltin('PlayerControl(Stop)')

    # ⏱️ Αναμονή για να προλάβει το πρόσθετο να εμφανίσει τους Scrapers στην οθόνη
    xbmc.sleep(2000)

    # =======================================================================
    # 🤖 4. ΠΑΡΑΚΑΜΨΗ ΠΑΡΑΘΥΡΟΥ MANALAB (ΑΝ ΕΜΦΑΝΙΣΤΕΙ)
    # =======================================================================
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(100)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(200)
        xbuiltin('Action(Left)')   
        xbmc.sleep(150)
        xbuiltin('Action(Select)') 

    xbmc.sleep(400) 

    # =======================================================================
    # ⏱️ 🎯 ΒΗΜΑ 5: ΔΥΝΑΜΙΚΟ ΚΛΕΙΔΩΜΑ 20"
    # =======================================================================
    while (time.time() - start_time) < 20.0:
        current_elapsed = time.time() - start_time
        if current_elapsed >= 7.0 and not icon_changed:
            xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file_2})')
            icon_changed = True
        xbmc.sleep(100) 

    # 🔥 ΟΡΙΣΤΙΚΟ ΚΛΕΙΣΙΜΟ ΤΟΥ ΠΟΠ-ΑΠ 4202
    xbuiltin('Dialog.Close(4202)')

if __name__ == '__main__':
    main()
