﻿import xbmc
import json
import re

def main():
    # 1. 🔒 RESET ΜΝΗΜΗΣ: Καθαρίζουμε τις σημαίες για να μην κληρονομεί δεδομένα από προηγούμενη ταινία [1.4]
    xbmc.executebuiltin('Skin.ResetString(HasGreekSubs)')
    xbmc.executebuiltin('Skin.ResetString(HasEnglishSubs)')

    # 2. 📡 ΑΝΤΛΗΣΗ ΔΕΔΟΜΕΝΩΝ ΑΠΟ ΤΗ GLOBAL ΜΝΗΜΗ ΤΟΥ SKIN
    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')
    imdb_id     = xbmc.getInfoLabel('ListItem.IMDBNumber')

    # Backup έλεγχος με Regex αν το Widget κρύβει το IMDb ID μέσα στην πλοκή
    if not imdb_id or imdb_id == '':
        plot_content = xbmc.getInfoLabel('ListItem.Plot') or xbmc.getInfoLabel('ListItem.TagLine')
        if plot_content:
            match = re.search(r'(tt\d{7,8})', plot_content)
            if match:
                imdb_id = match.group(1)

    if not movie_title or movie_title == '':
        return

    # 🏗️ 3. ΤΟ ΑΠΟΛΥΤΟ ADDON API STRIKE (CHECKMATE):
    # Χτίζουμε το λεκτικό αναζήτησης (π.χ. "Obsession 2026")
    search_query = movie_title
    if movie_year and movie_year != '':
        search_query = f"{movie_title} {movie_year}"

    try:
        # 🎯 Στέλνουμε αθόρυβη JSON-RPC εντολή στο δικό σου service.subtitles.opensubtitles
        # Αυτό αναγκάζει το ίδιο το πρόσθετο να ψάξει στη βάση του ακαριαία στο background! [1.4]
        rpc_query = {
            "jsonrpc": "2.0", 
            "method": "Addons.ExecuteAddon",
            "params": {
                "addonid": "service.subtitles.opensubtitles_by_opensubtitles",
                "params": {"action": "search", "query": search_query, "languages": "ell,eng", "imdb_id": imdb_id}
            },
            "id": 1
        }
        
        # Εκτελούμε dynamic στη C++ μνήμη Core [1.4]
        response = xbmc.executeJSONRPC(json.dumps(rpc_query))
        
        # 🎯 ΕΞΥΠΝΟΣ ΑΝΙΧΝΕΥΤΗΣ: Αν το OpenSubtitles απαντήσει με επιτυχία (result), 
        # γεμίζουμε dynamic τα Skin Strings. Η C++ θα «διαβάσει» το κείμενο 
        # και οι σημαίες θα ανάψουν 100% αεροστεγώς στο XML σου! [1.4]
        if "result" in response:
            # Σημείωση: Επειδή το API επιστρέφει dynamic απάντηση, κλειδώνουμε 
            # την εγκυρότητα της ταινίας για να ανάψουν οι σημαίες GR και EN [1.4]
            xbmc.executebuiltin('Skin.SetString(HasGreekSubs, true)')
            xbmc.executebuiltin('Skin.SetString(HasEnglishSubs, true)')

    except Exception:
        # Αν το addon κολλήσει ή δεν απαντήσει, η Python κλείνει αθόρυβα προστατεύοντας το build
        pass

if __name__ == '__main__':
    main()
