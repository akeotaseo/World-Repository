# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import requests
import threading

OS_REST_HEADERS = {'User-Agent': 'HotSubtitlesV1'}

# Λεξικό κανονικοποίησης γλωσσών από το API (Πλήρως θωρακισμένο για την Ελλάδα)
NORM_LANG = {
    'ell': 'el', 
    'gre': 'el', 
    'el': 'el',
    'gr': 'el', 
    'greek': 'el',
    'ελληνικά': 'el',
    'ελληνικα': 'el',
    'eng': 'en', 
    'en': 'en',
    'english': 'en'
}



def main():
    # 🧼 Καθαρίζουμε ακαριαία τα παλιά κατάλοιπα στη RAM της αρχικής οθόνης
    xbmcgui.Window(10000).clearProperty('tmdbmovies.has_el_sub')
    xbmcgui.Window(10000).clearProperty('tmdbmovies.has_en_sub')

    # 🕵️‍♂️ ΚΛΕΒΟΥΜΕ LIVE ΤΑ ΔΕΔΟΜΕΝΑ ΠΟΥ ΕΧΕΙ ΚΛΕΙΔΩΣΕΙ ΤΟ SKIN ΣΤΗ RAM
    movie_title = xbmc.getInfoLabel('Skin.String(HubMovieTitle)')
    movie_year  = xbmc.getInfoLabel('Skin.String(HubMovieYear)')
    imdb_id     = xbmc.getInfoLabel('ListItem.IMDBNumber')
    season      = xbmc.getInfoLabel('ListItem.Season')
    episode     = xbmc.getInfoLabel('ListItem.Episode')

    if not movie_title or movie_title == '':
        xbmc.log("[Skin_OS_Checker] Σφάλμα: Δεν βρέθηκε τίτλος ταινίας στη μνήμη του Skin.", xbmc.LOGWARNING)
        return

    # 🛠️ ΔΟΜΗΣΗ ΔΙΑΔΡΟΜΗΣ (Αν δεν υπάρχει IMDb ID, χρησιμοποιούμε Query Αναζήτησης)
    if imdb_id and imdb_id != '' and str(imdb_id).startswith('tt'):
        numeric_id = str(imdb_id).replace('tt', '')
        is_tv = season and episode and str(season) != '0' and str(episode) != '0'
        if is_tv:
            query_path = f"episode-{episode}/imdbid-{numeric_id}/season-{season}"
        else:
            query_path = f"imdbid-{numeric_id}"
    else:
        query_clean = requests.utils.quote(movie_title)
        if movie_year and movie_year != '':
            query_path = f"query-{query_clean}/year-{movie_year}"
        else:
            query_path = f"query-{query_clean}"

    def _worker():
        try:
            # 🎯 ΤΟ ΕΠΙΣΗΜΟ endpoint του OpenSubtitles REST API
            url = f"https://rest.opensubtitles.org/search/{query_path}"
            xbmc.log(f"[Skin_OS_Checker] Έναρξη αυτόνομου σκαναρίσματος στο OpenSubtitles API: {url}", xbmc.LOGINFO)
            
            r = requests.get(url, headers=OS_REST_HEADERS, timeout=6.0)
            
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, list):
                    found_el = False
                    found_en = False

                    # 🔍 ULTRA SCAN: Ψάχνουμε live σε όλη τη λίστα του server
                    # 🔍 ULTRA SCAN: Ψάχνουμε live σε όλη τη λίστα του server
                    for item in data:
                        # 🎯 Παίρνουμε τις τιμές και τις κάνουμε μικρά γράμματα χωρίς κενά
                        sub_lang_raw = str(item.get('ISO639', '')).lower().strip()
                        sub_lang_id  = str(item.get('SubLanguageID', '')).lower().strip()
                        sub_name     = str(item.get('LanguageName', '')).lower().strip()
                        
                        # 🔄 Μετατρέπουμε τα πάντα στη βασική γλώσσα ('el' ή 'en') χρησιμοποιώντας το λεξικό
                        lang_resolved = (
                            NORM_LANG.get(sub_lang_raw) or 
                            NORM_LANG.get(sub_lang_id) or 
                            NORM_LANG.get(sub_name)
                        )

                        # 🇬🇷 ΕΛΕΓΧΟΣ ΓΙΑ ΕΛΛΗΝΙΚΑ
                        if lang_resolved == 'el':
                            found_el = True
                            
                        # 🇬🇧 ΕΛΕΓΧΟΣ ΓΙΑ ΑΓΓΛΙΚΑ
                        if lang_resolved == 'en':
                            found_en = True

                        # Αν βρέθηκαν και τα δύο, σταματάμε για οικονομία πόρων
                        if found_el and found_en:
                            break


                    # 💾 ΕΓΓΡΑΦΗ ΣΤΗΝ ΚΕΝΤΡΙΚΗ RAM (Window 10000): Ανάβουν μόνο αν υπάρχουν πραγματικά srt!
                    if found_el:
                        xbmc.log("[Skin_OS_Checker] ΕΠΙΤΥΧΙΑ! Βρέθηκαν Ελληνικοί υπότιτλοι.", xbmc.LOGINFO)
                        xbmcgui.Window(10000).setProperty('tmdbmovies.has_el_sub', 'true')
                    if found_en:
                        xbmc.log("[Skin_OS_Checker] ΕΠΙΤΥΧΙΑ! Βρέθηκαν Αγγλικοί υπότιτλοι.", xbmc.LOGINFO)
                        xbmcgui.Window(10000).setProperty('tmdbmovies.has_en_sub', 'true')
                        
                    # 🔄 ΑΝΤΙΚΑΤΑΣΤΑΣΗ: Ανανέωση μόνο των controls αντί για ολικό κρασάρισμα του παραθύρου
                    # if found_el or found_en:
                        # xbmc.executebuiltin('Container.Refresh')

            else:
                xbmc.log(f"[Skin_OS_Checker] API Error: Status {r.status_code}", xbmc.LOGERROR)

        except Exception as e:
            xbmc.log(f"[Skin_OS_Checker] Εσωτερικό σφάλμα κατά την αναζήτηση: {str(e)}", xbmc.LOGERROR)

    # Εκκίνηση σε background thread για να μην κολλάει καθόλου το UI
    t = threading.Thread(target=_worker)
    t.daemon = True
    t.start()


if __name__ == '__main__':
    main()
