import xbmc, xbmcgui


def WeatherWidget():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Weather[/COLOR][/B]', 
['Web TV ALPHA (Ειδήσεις Καιρός)',
 'ΚΑΙΡΟΣ STAR',
 'ANT1 Δελτίο Καιρού',
 'Δελτίο Καιρού Mega',
 'ΣΚΑΪ Καιρός',
 'Δελτίο στη Νοηματική SKAI',
 'Ειδήσεις ERTflix',
 'NEWS'])


    if call:
        if call < 0:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.alphatv.gr/?action=listing&image=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.alphatv.gr%5cresources%5cmedia%5crecent.png&title=Web%20TV&url=%7b%22kind%22%3a%22broadcasts%22%7d")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.star.gr/?action=listing&image=https%3a%2f%2fwww.star.gr%2ftv%2fimages%2f347x195%2f3%2fjpg%2ffiles%2fStarKairos_1920x1004.webp&title=STAR%20%ce%9a%ce%91%ce%99%ce%a1%ce%9f%ce%a3&url=%7b%22kind%22%3a%22episodes%22%2c%22base%22%3a%22https%3a%2f%2fwww.star.gr%2ftv%2fenimerosi%2fstar-kairos%22%2c%22title%22%3a%22STAR%20%5cu039a%5cu0391%5cu0399%5cu03a1%5cu039f%5cu03a3%22%7d")')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.antenna.gr/?action=weather")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.megatv.com/?action=listing&image=https%3a%2f%2fwww.megatv.com%2fwp-content%2fuploads%2f2025%2f07%2f%ce%ba%ce%b1%ce%b9%cf%81%ce%bf%cf%83-2-234x300-1.jpg&title=%ce%94%ce%b5%ce%bb%cf%84%ce%af%ce%bf%20%ce%9a%ce%b1%ce%b9%cf%81%ce%bf%cf%8d&url=%7b%22kind%22%3a%22episodes%22%2c%22base%22%3a%22https%3a%2f%2fwww.megatv.com%2fekpompes%2f2036710%2fdeltio-kairou-3%22%2c%22title%22%3a%22%5cu0394%5cu03b5%5cu03bb%5cu03c4%5cu03af%5cu03bf%20%5cu039a%5cu03b1%5cu03b9%5cu03c1%5cu03bf%5cu03cd%22%7d")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.skai.gr/?action=listing&image=https%3a%2f%2fmedia.skaitv.gr%2fimages%2f450%2f0%2ffiles%2feidiseis%2flogos%2f2025_2026%2fkairos_new_landscape.jpg&title=%ce%a3%ce%9a%ce%91%ce%aa%20%ce%9a%ce%b1%ce%b9%cf%81%cf%8c%cf%82&url=%7b%22kind%22%3a%22episodes%22%2c%22base%22%3a%22https%3a%2f%2fwww.skai.gr%2ftv%2fshow%2fenimerosi%2fskai-kairos%2fsezon-2026-2027%22%2c%22title%22%3a%22%5cu03a3%5cu039a%5cu0391%5cu03aa%20%5cu039a%5cu03b1%5cu03b9%5cu03c1%5cu03cc%5cu03c2%22%7d")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.skai.gr/?action=listing&image=https%3a%2f%2fmedia.skaitv.gr%2fimages%2f450%2f0%2ffiles%2feidiseis%2flogos%2f2025_2026%2fnoimatiki_new_landscape.jpg&title=%ce%94%ce%b5%ce%bb%cf%84%ce%af%ce%bf%20%cf%83%cf%84%ce%b7%20%ce%9d%ce%bf%ce%b7%ce%bc%ce%b1%cf%84%ce%b9%ce%ba%ce%ae&url=%7b%22kind%22%3a%22episodes%22%2c%22base%22%3a%22https%3a%2f%2fwww.skai.gr%2ftv%2fshow%2fenimerosi%2fdeltio-sti-noimatiki%2fsezon-2026-2027%22%2c%22title%22%3a%22%5cu0394%5cu03b5%5cu03bb%5cu03c4%5cu03af%5cu03bf%20%5cu03c3%5cu03c4%5cu03b7%20%5cu039d%5cu03bf%5cu03b7%5cu03bc%5cu03b1%5cu03c4%5cu03b9%5cu03ba%5cu03ae%22%7d")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.ert.gr/?action=listing&title=%ce%95%ce%b9%ce%b4%ce%ae%cf%83%ce%b5%ce%b9%cf%82&url=https%3a%2f%2fapi.app.ertflix.gr%2fv1%2fInsysGoPage%2fGetSectionContent%3fplatformCodename%3dwww%26page%3d1%26limit%3d50%26sectionCodename%3deideseis%26%24headers%3d%257B%2522X-Api-Date-Format%2522%3a%2522iso%2522%2c%2522X-Api-Camel-Case%2522%3atrue%257D")')


def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.manalab/?action=parse_m3u&category=ALL_CHANNELS_FLAG&m3u_url=https%3a%2f%2ftest.manalab.net%2fwizard%2f111.m3u")')


WeatherWidget()
