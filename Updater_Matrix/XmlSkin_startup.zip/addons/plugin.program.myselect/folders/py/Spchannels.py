# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def spchannels():
    # 1. Ορίζουμε τις επιλογές του μενού (Όνομα, Υπότιτλος, Εικονίδιο, Περιγραφή, Script ή Builtin ή Function)
    menu_items = [
        {
            "label": "[COLOR lime]TV Loucos[/COLOR]",
            "subtitle": "[COLOR yellow] Brasil[/COLOR]",
            "icon": "https://thumb.wikimedia.org/wikipedia/en/thumb/0/05/Flag_of_Brazil.svg/1280px-Flag_of_Brazil.svg.png?utm_source=en.wikipedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
            "plot": "[COLOR lime]TV Loucos[COLOR yellow] Brasil[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.tvloucosbr")',
            "notification": {"title": "They don't always work", "msg": "Δεν λειτουργούν πάντα...", "icon": "special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png"}
        },
        {
            "label": "[COLOR=white]DESPORTO/SPORTS[/COLOR]",
            "subtitle": "",
            "icon": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFvQJrXerqkEyNLNoKz6HTXH4QADfAYjXGPLSCIi1F2phw9xASREczmhA&s=10",
            "plot": "[COLOR=green](Magellan)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.Magellan_Matrix/?fanart=https%3a%2f%2fwallpapercave.com%2fwp%2fwp7245862.jpg&mode=1&name=%5bCOLOR%20lime%5d%20%3e%20%5bCOLOR%20yellow%5dDESPORTO%2fSPORTS%20%5b%2fCOLOR%5d&url=https%3a%2f%2fpastebin.com%2fraw%2fz9jHvduv")'
        },
        {
            "label": "[COLOR=white]**Sports** [/COLOR]",
            "subtitle": "[COLOR=orange](LiveStreamsPro)[/COLOR]",
            "icon": "special://home/addons/plugin.video.live.streamspro/icon.png",
            "plot": "[COLOR=orange](LiveStreamsPro)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart&mode=1&name=%2a%2aSports%2a%2a&url=https%3a%2f%2fiptv-org.github.io%2fiptv%2fcategories%2fsports.m3u")'
        },
        {
            "label": "[COLOR=white]Ζωντανά Κανάλια",
            "subtitle": "[COLOR=red]daddylive[/COLOR]",
            "icon": "special://home/addons/plugin.video.daddylive/icon.png",
            "plot": "[COLOR orange](microjen)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv")'
            
   
            # "function": mandrakodi  # <--- ΑΛΛΑΓΗ 1: Καλούμε τη def απευθείας χωρίς εισαγωγικά
        },
        {
            "label": "[COLOR=white]Elitegol[/COLOR]",
            "subtitle": "",
            "icon": "https://thumb.wikimedia.org/wikipedia/en/thumb/c/c3/Flag_of_France.svg/1280px-Flag_of_France.svg.png?utm_source=en.wikipedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
            "plot": "[COLOR=blue]France[COLOR=purple][CR](vstream)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showTV&sFav=showTV&site=elitegol&siteUrl=lecteur%2f&title=Elitegol")'
        },
        {
            "label": "[COLOR deepskyblue]FreeShot Live",
            "subtitle": "",
            "icon": "https://thumb.wikimedia.org/wikipedia/en/thumb/0/03/Flag_of_Italy.svg/1280px-Flag_of_Italy.svg.png?utm_source=en.wikipedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
            "plot": "[COLOR red] Italia[/COLOR][CR][COLOR=green](Thegroove360)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.torproxy/?link=https%3a%2f%2fwww.freeshot.live%2flive-tv%2fitalia&mode=resolver&title2=freeshot_country",return)'
        },
        {
            "label": "[COLOR deepskyblue]Live Channels List",
            "subtitle": "[COLOR skyblue] (A-Z)[/COLOR]",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/loop.png",
            "plot": " [COLOR lime](the-loop)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/https://loopaddon.uk/files/k19/xmls/CHANNEL_LIST/1__all_categories.json")'
        },
        {
            "label": "Ζωντανά Κανάλια",
            "subtitle": "",
            "icon": "special://home/addons/plugin.video.microjen/icon.png",
            "plot": "[COLOR orange](microjen)[/COLOR][CR][COLOR blue](Ελληνικά/Κυπριακά)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_greek")'
        },
        {
            "label": "спорт",
            "subtitle": "",
            "icon": "https://thumb.wikimedia.org/wikipedia/en/thumb/f/f3/Flag_of_Russia.svg/1280px-Flag_of_Russia.svg.png?utm_source=en.wikipedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
            "plot": "[COLOR red]Russia[/COLOR][CR](playlistloaderworld)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.playlistloaderworld/?cache=0&epg&iconimage=http%3a%2f%2fepg.one%2fimg2%2f2051.png&index=3&logos&mode=10&name=%d0%a1%d0%bf%d0%be%d1%80%d1%82&url=https%3a%2f%2filook.epg.one%2fEAMZWV3TFEVWL3&uuid=0",return)'
        },
        {
            "label": "[COLORwhite]SPORTS NETWORKS[COLOR red] - FIXED[/COLOR]",
            "subtitle": "",
            "icon": "special://home/addons/plugin.image.World/resources/media/addonset foto/madtitansports.png",
            "plot": " [COLOR red](madtitansports)[/COLOR]",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.madtitansports/get_list/https://magnetic.website/jet/TVGUIDE/TVGUIDE_Sports Networks.json",return)'
        },
    ]

    # 2. Φτιάχνουμε τη λίστα με τα αντικείμενα (ListItems)
    movie_page = []
    for item in menu_items:
        selected_title = f"[B]{item['label']}[/B]  [COLOR blue]{item['subtitle']}[/COLOR]"
        liz = xbmcgui.ListItem(selected_title)
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        liz.setArt({'thumb': item["icon"], 'icon': item["icon"]})
        movie_page.append(liz)

    # 3. Καλούμε το select (useDetails=True για να εμφανίζεται το δεξί παράθυρο)
    ret = xbmcgui.Dialog().select('[B][COLOR=orange]Live Now[/COLOR][/B]', movie_page, useDetails=True)

    # 4. Έξυπνη εκτέλεση ανάλογα με τον τύπο της επιλογής
    if ret >= 0:
        chosen = menu_items[ret]
        xbmc.sleep(300)
        
        # Έλεγχος αν υπάρχει ειδοποίηση προς εμφάνιση
        if "notification" in chosen:
            notif = chosen["notification"]
            xbmcgui.Dialog().notification(notif["title"], notif["msg"], sound=False, icon=notif["icon"])
        
        if "function" in chosen:
            # Εκτέλεση Python def
            chosen["function"]()
        elif "builtin" in chosen:
            # Εκτέλεση εντολής Kodi (ActivateWindow)
            xbmc.executebuiltin(chosen["builtin"])
        elif "script" in chosen:
            # Εκτέλεση εξωτερικού αρχείου .py (RunScript)
            xbmc.executebuiltin(f'RunScript("{chosen["script"]}")')


def mandrakodi():
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/")')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php")')

    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dA1A110")')
    # xbmc.executebuiltin('SendClick(11)')

    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=myresolve&parIn=zonline&url=sportMenu")')


if __name__ == '__main__':
    spchannels()
