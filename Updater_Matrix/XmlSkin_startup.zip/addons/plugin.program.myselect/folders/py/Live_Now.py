﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def Live_Now():
    # 1. Ορίζουμε τις επιλογές του μενού (Όνομα, Υπότιτλος, Εικονίδιο, Περιγραφή, Script ή Builtin ή Function)
    menu_items = [
        {
            "label": "[COLOR white]Sport[COLOR gold]HD[/COLOR]",
            "subtitle": "Πλήρες Πρόγραμμα Αγώνων ",
            "icon": "https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/plugin.video.sporthdme/icon.png",
            "plot": "(microjen)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Daily%20events%20list&iconimage=https%3a%2f%://githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=events&name=%5bB%5d-%20%5bCOLOR%20white%5dSport%5bCOLOR%20gold%5dHD%5bCOLOR%20white%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fleague.st%2f")'
            # "notification": {"title": "Αντίγραφα Ασφαλείας", "msg": "...", "icon": "special://home/addons/plugin.program.downloader19/resources/media/backup.png"}  TEST
        },
        {
            "label": "[COLOR red]Live[/COLOR][COLOR white]TV.ru[/COLOR]",
            "subtitle": "Πλήρες Πρόγραμμα Αγώνων ",
            "icon": "special://home/addons/skin.19MatrixWorld/media/livetv.sx.png",
            "plot": "(microjen)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=LiveTV.ru%20Daily%20events%20list&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=%5bB%5d-%20%5bCOLOR%20red%5dLive%5b%2fCOLOR%5d%5bCOLOR%20white%5dTV.ru%5b%2fCOLOR%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fB%5d&url=eJzLKCkpKLbS109OydPLySxLLSmzMDXWy03VLyou1i8tSM7PzcxLj0%2fN06vIzQEAZbMQMg%3d%3d")'
        },
        {
            "label": "[B][COLORred][B]Daddylive[/COLOR]",
            "subtitle": "Ζωντανοί αγώνες - Πρόγραμμα Ημέρας",
            "icon": "special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg",
            "plot": "(microjen)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")'
        },
        {
            "label": "[COLOR gold]Sportzonline[/COLOR]",
            "subtitle": "LISTA 3",
            "icon": "https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1",
            "plot": "(mandrakodi)",
            "function": mandrakodi  # <--- ΑΛΛΑΓΗ 1: Καλούμε τη def απευθείας χωρίς εισαγωγικά
        }

    ]

    # 2. Φτιάχνουμε τη λίστα με τα αντικείμενα (ListItems)
    movie_page = []
    for item in menu_items:
        selected_title = f"[B]{item['label']}[/B]  [COLOR blue]{item['subtitle']}[/COLOR]"
        liz = xbmcgui.ListItem(selected_title)
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        liz.setArt({'thumb': item["icon"], 'icon': item["icon"]})
        movie_page.append(liz)

    # 3. Καλούμε το select (useDetails=True για να εμφανίζεται το δεξί παράθυρο)
    ret = xbmcgui.Dialog().select('[B][COLOR=orange]Live Now[/COLOR][/B]', movie_page, useDetails=True)

    # 4. Έξυπνη εκτέλεση ανάλογα με τον τύπο της επιλογής
    if ret >= 0:
        chosen = menu_items[ret]
        xbmc.sleep(300)
        
        # Έλεγχος αν υπάρχει ειδοποίηση προς εμφάνιση
        if "notification" in chosen:
            notif = chosen["notification"]
            xbmcgui.Dialog().notification(notif["title"], notif["msg"], sound=False, icon=notif["icon"])
        
        if "function" in chosen:
            # Εκτέλεση Python def
            chosen["function"]()
        elif "builtin" in chosen:
            # Εκτέλεση εντολής Kodi (ActivateWindow)
            xbmc.executebuiltin(chosen["builtin"])
        elif "script" in chosen:
            # Εκτέλεση εξωτερικού αρχείου .py (RunScript)
            xbmc.executebuiltin(f'RunScript("{chosen["script"]}")')


def mandrakodi():
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/")')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php")')

    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dA1A110")')
    # xbmc.executebuiltin('SendClick(11)')

    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=myresolve&parIn=zonline&url=sportMenu")')


if __name__ == '__main__':
    Live_Now()
