﻿import xbmc
import xbmcgui

xbmc.executebuiltin('ActivateWindow(Weather)')
xbmc.sleep(300)
xbmc.executebuiltin('Action(Back)')
xbmc.sleep(100)
xbmc.executebuiltin('Weather.Refresh')

xbmcgui.Dialog().notification("Καιρός", "Η πρόγνωση και οι τοποθεσίες ανανεώθηκαν!", "Weather.ico", 2500, False)
