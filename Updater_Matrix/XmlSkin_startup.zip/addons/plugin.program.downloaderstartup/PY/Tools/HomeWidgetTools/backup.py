﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def BackupMenu():
    # 1. Πετάμε αμέσως την ειδοποίηση (Notification) στην οθόνη
    xbmcgui.Dialog().notification("[COLOR orange]Backup[/COLOR]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/backup.png')
    
    # 2. Ορίζουμε τις επιλογές (Όνομα, Υπότιτλος, Περιγραφή)
    backup_items = [
        {
            "label": "World Updater",
            "subtitle": "Αντίγραφο Build",
            "plot": "Δημιουργία πλήρους αντιγράφου ασφαλείας ή επαναφορά του Build μέσω του επίσημου εργαλείου World Updater Tools."
        },
        {
            "label": "G.K.N.Wizard",
            "subtitle": "Αντίγραφο Ασφαλείας",
            "plot": "Μετάβαση στο μενού συντήρησης του G.K.N. Wizard για τη δημιουργία και διαχείριση αντιγράφων ασφαλείας."
        }
    ]
    
    # 3. 🚀 ΙΔΙΟ LOOP ΚΑΙ ΔΟΜΗ ΜΕ ΤΟ TOOLSMENU (Με Title και Plot μαζί!)
    movie_page = []
    for item in backup_items:
        selected_title = f"[B]{item['label']}[/B] | [B][COLOR blue]{item['subtitle']}[/COLOR][/B]"
        
        liz = xbmcgui.ListItem(selected_title)
        # Εδώ είναι το κλειδί: Περνάμε και το Title και το Plot για να "πιάσει" το XML
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        
        backup_icon = 'special://home/addons/plugin.program.downloader19/resources/media/backup.png'
        liz.setArt({'thumb': backup_icon, 'icon': backup_icon})
        
        movie_page.append(liz)

    # 4. Καλούμε το select με useDetails=True
    ret = xbmcgui.Dialog().select('[COLOR orange]Επιλογή :[/COLOR]', movie_page, useDetails=True)

    # 5. Εκτέλεση της ανακατεύθυνσης με ασφάλεια
    if ret == 0:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        
        xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR orange]World Updater - Tools [/COLOR]Back up", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
        xbmc.sleep(1000)
        
        url = "plugin://plugin.program.downloader19/?description&fanart=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2ffanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fsave.png&mode=17&name=%ce%91%ce%bd%cf%84%ce%af%ce%b3%cf%81%ce%b1%cf%86%ce%bf%20%ce%b1%cf%83%cf%86%ce%b5%ce%af%ce%b1%cf%82%20%26%20%ce%95%cf%80%ce%b1%ce%bd%ce%b1%cf%86%ce%bf%cf%81%ce%ac%20Build"
        xbmc.executebuiltin(f'ActivateWindow(10001,"{url}",return)')

    elif ret == 1:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        
        xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR blue]G.K.N.Wizard [/COLOR]Back up", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
        xbmc.sleep(1000)
        
        url = "plugin://plugin.program.G.K.N.Wizard/?mode=maint&name=backup"
        xbmc.executebuiltin(f'ActivateWindow(10001,"{url}",return)')

if __name__ == '__main__':
    BackupMenu()
