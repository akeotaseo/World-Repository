﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def backup():
    # 1. Ορίζουμε τις επιλογές του μενού (Όνομα, Υπότιτλος, Εικονίδιο, Περιγραφή, Script)
    menu_items = [
        {
            "label": "World Updater",
            "subtitle": "Αντίγραφο Build",
            "icon": "special://home/addons/plugin.program.downloader19/resources/media/backup.png",
            "plot": "Δημιουργία πλήρους αντιγράφου ασφαλείας ή επαναφορά του Build μέσω του επίσημου εργαλείου World Updater Tools.",
            "builtin": 'ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fsave.png&mode=17&name=%ce%91%ce%bd%cf%84%ce%af%ce%b3%cf%81%ce%b1%cf%86%ce%bf%20%ce%b1%cf%83%cf%86%ce%b1%ce%bb%ce%b5%ce%af%ce%b1%cf%82%20%26%20%ce%95%cf%80%ce%b1%ce%bd%ce%b1%cf%86%ce%bf%cf%81%ce%ac%20Build&name2&url&version")'
        },
        {
            "label": "G.K.N.Wizard",
            "subtitle": "Αντίγραφο Ασφαλείας",
            "icon": "special://home/addons/plugin.program.downloader19/resources/media/save.png",
            "plot": "Μετάβαση στο μενού συντήρησης του G.K.N. Wizard για τη δημιουργία και διαχείριση αντιγράφων ασφαλείας.",
            "builtin": 'ActivateWindow(10001,"plugin://plugin.program.G.K.N.Wizard/?mode=maint&name=backup")'
        }
    ]

    # 2. Φτιάχνουμε τη λίστα με τα αντικείμενα (ListItems)
    movie_page = []
    for item in menu_items:
        selected_title = f"[B]{item['label']}[/B]  [COLOR blue]{item['subtitle']}[/COLOR]"
        liz = xbmcgui.ListItem(selected_title)
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        liz.setArt({'thumb': item["icon"], 'icon': item["icon"]})
        movie_page.append(liz)

    # 3. Καλούμε το select (useDetails=True για να εμφανίζεται το δεξί παράθυρο)
    ret = xbmcgui.Dialog().select('[B][COLOR=orange]Backup[/COLOR][/B]', movie_page, useDetails=True)

    # 4. Έξυπνη εκτέλεση ανάλογα με τον τύπο της επιλογής
    if ret >= 0:
        chosen = menu_items[ret]
        xbmc.sleep(300)
        
        # Έλεγχος αν υπάρχει ειδοποίηση προς εμφάνιση
        if "notification" in chosen:
            notif = chosen["notification"]
            xbmcgui.Dialog().notification(notif["title"], notif["msg"], sound=False, icon=notif["icon"])
        
        if "function" in chosen:
            # Εκτέλεση Python def
            chosen["function"]()
        elif "builtin" in chosen:
            # Εκτέλεση εντολής Kodi (ActivateWindow)
            xbmc.executebuiltin(chosen["builtin"])
        elif "script" in chosen:
            # Εκτέλεση εξωτερικού αρχείου .py (RunScript)
            xbmc.executebuiltin(f'RunScript("{chosen["script"]}")')


if __name__ == '__main__':
    backup()
