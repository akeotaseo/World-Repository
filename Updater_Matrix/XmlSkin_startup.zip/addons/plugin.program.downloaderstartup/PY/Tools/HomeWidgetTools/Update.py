﻿# -*- coding: utf-8 -*-
import os
import glob
import sqlite3
import xbmc
import xbmcgui
import xbmcvfs

def click_unblock():
    """ 🔓 Καθαρισμός cache αποθετηρίων & άμεσο ξεμπλοκάρισμα ενημερώσεων """
    xbmcgui.Dialog().notification(
        "[B][COLOR aqua]Ξεμπλοκάρισμα Ενημερώσεων[/COLOR][/B]",
        "Καθαρισμός cache αποθετηρίων...",
        icon="special://home/addons/skin.19MatrixWorld/media/update.png",
        sound=False
    )

    # 1. Μηδενισμός checksums & πακέτων στην Addons33.db
    db_path = xbmcvfs.translatePath('special://database/Addons33.db')
    if os.path.exists(db_path):
        try:
            conn = sqlite3.connect(db_path, timeout=15)
            cur = conn.cursor()
            cur.execute("UPDATE repo SET checksum = '', lastcheck = ''")
            cur.execute("DELETE FROM package")
            cur.execute("DELETE FROM update_rules")
            conn.commit()
            conn.close()
            xbmc.log("[Master_Build] Καθαρίστηκαν τα checksums των repositories στην Addons33.db.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Master_Build] Σφάλμα καθαρισμού Addons33.db: {e}", xbmc.LOGERROR)

    # 2. Διαγραφή κολλημένων .zip στον φάκελο addons/packages
    packages_dir = xbmcvfs.translatePath('special://home/addons/packages')
    if os.path.exists(packages_dir):
        for zip_file in glob.glob(os.path.join(packages_dir, '*.zip')):
            try:
                os.remove(zip_file)
            except:
                pass

    # 3. Αναγκαστικός επανέλεγχος & άνοιγμα διαθέσιμων ενημερώσεων
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
    xbmc.sleep(300)
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.sleep(1500)
    xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')

def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=forceupdate")')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fixaddonupdate")')

def Update():
    funcs = [click_unblock, click_1, click_2]
    options = [
        '[COLOR lime]Ξεμπλοκάρισμα & Έλεγχος Ενημερώσεων (World)[/COLOR]',
        '[COLOR dodgerblue]Force Update Addons[/COLOR]',
        '[COLOR dodgerblue]Fix Addons Not Updating[/COLOR]'
    ]
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Update[/COLOR][/B]', options)
    if call >= 0:
        return funcs[call]()

if __name__ == '__main__':
    Update()
