﻿import xbmc
import xbmcgui

def show_tools_menu():
    # 1. Ορίζουμε τις επιλογές του μενού (Όνομα, Εικονίδιο, Script που θα εκτελεστεί)
    menu_items = [
        {
            "label": "Ενεργοποίηση πρόσθετων",
            "icon": "special://home/addons/plugin.program.downloader19/resources/media/enable.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/enable_addons.py"
        },
        {
            "label": "Update",
            "icon": "special://home/addons/plugin.program.downloader19/resources/media/update.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/Update.py"
        },
        {
            "label": "Backup",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/backup.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/backup.py"
        },
        {
            "label": "AdvancedSettings",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/QuickConfigureAdvancedSettings.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/Advanced_Settings.py"
        },
        {
            "label": "Skin Switcher",
            "icon": "special://home/addons/script.skinswitcher/icon.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/SkinSwitcher.py"
        },
        {
            "label": "Builds",
            "icon": "special://home/addons/plugin.program.G.K.N.Wizard/resources/art/builds.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/Builds.py"
        },
        {
            "label": "System Information",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/SysInfo.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/SystemInformation.py"
        },
        {
            "label": "Keymap Editor",
            "icon": "special://home/addons/plugin.image.World/resources/media/addonset foto/Keymap.png",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/KeymapEditor.py"
        }
    ]

    # 2. Δημιουργούμε τη λίστα με τα αντικείμενα (Kodi List Items) για να φαίνονται τα εικονίδια
    list_items = []
    for item in menu_items:
        list_item = xbmcgui.ListItem(label=item["label"])
        list_item.setArt({"icon": item["icon"], "thumb": item["icon"]})
        list_items.append(list_item)

    # 3. Ανοίγουμε το αναδυόμενο μενού επιλογής
    dialog = xbmcgui.Dialog()
    selection = dialog.select("[B][COLOR dodgerblue]Εργαλεία συστήματος[/COLOR][/B]", list_items)

    # 4. Αν ο χρήστης επιλέξει κάτι (και δεν πατήσει πίσω/άκυρο), εκτελούμε το αντίστοιχο py script
    if selection >= 0:
        selected_script = menu_items[selection]["script"]
        # Κλείνουμε τυχόν ανοιχτά παράθυρα για ασφάλεια πριν τρέξει το επόμενο script
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin(f'RunScript("{selected_script}")')

if __name__ == '__main__':
    show_tools_menu()
