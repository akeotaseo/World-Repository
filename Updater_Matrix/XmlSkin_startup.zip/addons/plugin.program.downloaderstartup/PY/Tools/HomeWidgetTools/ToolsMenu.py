﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def show_tools_menu():
    # 1. Ορίζουμε τις επιλογές του μενού (Όνομα, Υπότιτλος, Εικονίδιο, Περιγραφή, Script)
    menu_items = [
        {
            "label": "Ενεργοποίηση πρόσθετων",
            "subtitle": "Διαχείριση Addons",
            "icon": "special://home/addons/plugin.program.downloader19/resources/media/enable.png",
            "plot": "Εργαλείο για την μαζική ενεργοποίηση των απενεργοποιημένων πρόσθετων (addons) στο Kodi σας.",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/enable_addons.py"
        },
        {
            "label": "Update",
            "subtitle": "Ενημέρωση Συστήματος",
            "icon": "special://home/addons/plugin.program.downloader19/resources/media/update.png",
            "plot": "Έλεγχος και εγκατάσταση ενημερώσεων για το Build, τα πρόσθετα και τα αποθετήρια του συστήματος.",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/Update.py"
        },
        {
            "label": "Backup",
            "subtitle": "Αντίγραφο Ασφαλείας",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/backup.png",
            "plot": "Δημιουργία πλήρους αντιγράφου ασφαλείας των ρυθμίσεων και των δεδομένων του Kodi για εύκολη επαναφορά.",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/backup.py",
            # "notification": {"title": "Αντίγραφα Ασφαλείας", "msg": "...", "icon": "special://home/addons/plugin.program.downloader19/resources/media/backup.png"}
        },
        {
            "label": "AdvancedSettings",
            "subtitle": "Βελτιστοποίηση Cache",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/QuickConfigureAdvancedSettings.png",
            "plot": "Γρήγορη παραμετροποίηση του αρχείου advancedsettings.xml για βελτιστοποίηση της προσωρινής μνήμης (cache).",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/Advanced_Settings.py"
        },
        {
            "label": "Skin Switcher",
            "subtitle": "Αλλαγή Εμφάνισης",
            "icon": "special://home/addons/script.skinswitcher/icon.png",
            "plot": "Άμεση εναλλαγή μεταξύ των εγκατεστημένων εμφανίσεων (skins) του Kodi χωρίς πλοήγηση στα μενού ρυθμίσεων.",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/SkinSwitcher.py"
        },
        {
            "label": "Builds",
            "subtitle": "GrecoTM Wizard",
            "icon": "special://home/addons/plugin.program.G.K.N.Wizard/resources/art/builds.png",
            "plot": "Άνοιγμα του οδηγού εγκατάστασης έτοιμων Build (G.K.N. Wizard / GrecoTM Builds).",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/Builds.py"
        },
        {
            "label": "System Information",
            "subtitle": "Πληροφορίες Kodi",
            "icon": "special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/SysInfo.png",
            "plot": "Πληροφορίες συστήματος: Δείτε τη χρήση μνήμης RAM, τον ελεύθερο χώρο του δίσκου και την έκδοση του Kodi.",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/SystemInformation.py"
        },
        {
            "label": "Keymap Editor",
            "subtitle": "Ρύθμιση Πλήκτρων",
            "icon": "special://home/addons/plugin.image.World/resources/media/addonset foto/Keymap.png",
            "plot": "Επεξεργαστής πλήκτρων: Αλλάξτε τη λειτουργία των κουμπιών του τηλεκοντρόλ ή του πληκτρολογίου σας.",
            "script": "special://home/addons/plugin.program.downloaderstartup/PY/Tools/HomeWidgetTools/KeymapEditor.py"
        }
    ]

    # 2. Φτιάχνουμε τη λίστα με τα αντικείμενα (ListItems)
    movie_page = []
    for item in menu_items:
        selected_title = f"[B]{item['label']}[/B]  [COLOR blue]{item['subtitle']}[/COLOR]"
        liz = xbmcgui.ListItem(selected_title)
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        liz.setArt({'thumb': item["icon"], 'icon': item["icon"]})
        movie_page.append(liz)

    # 3. Καλούμε το select (useDetails=True για να εμφανίζεται το δεξί παράθυρο)
    ret = xbmcgui.Dialog().select('[B][COLOR=orange]Tools[/COLOR][/B]', movie_page, useDetails=True)

    # 4. Έξυπνη εκτέλεση ανάλογα με τον τύπο της επιλογής
    if ret >= 0:
        chosen = menu_items[ret]
        xbmc.sleep(300)
        
        # Έλεγχος αν υπάρχει ειδοποίηση προς εμφάνιση
        if "notification" in chosen:
            notif = chosen["notification"]
            xbmcgui.Dialog().notification(notif["title"], notif["msg"], sound=False, icon=notif["icon"])
        
        if "function" in chosen:
            # Εκτέλεση Python def
            chosen["function"]()
        elif "builtin" in chosen:
            # Εκτέλεση εντολής Kodi (ActivateWindow)
            xbmc.executebuiltin(chosen["builtin"])
        elif "script" in chosen:
            # Εκτέλεση εξωτερικού αρχείου .py (RunScript)
            xbmc.executebuiltin(f'RunScript("{chosen["script"]}")')


if __name__ == '__main__':
    show_tools_menu()



