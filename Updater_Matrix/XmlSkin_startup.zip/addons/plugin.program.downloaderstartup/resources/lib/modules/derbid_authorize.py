# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import webbrowser

def derbid_authorize():
    # 🎯 ΟΙ ΣΥΝΑΡΤΗΣΕΙΣ: Πλήρης, αυστηρή ευθυγράμμιση 1 προς 1 με τη σειρά του μενού
    funcs = (
        # 1️⃣ TORBOX
        action_web_tb_dev, # Index 0  -> Site TorBox DEVICE ACTIVATE
        action_web_tb,     # Index 1  -> Site TorBox ΚΕΝΤΡΙΚΟ
        action_6,          # Index 2  -> Authorize TB
        action_12,         # Index 3  -> Reset TB
        
        # 2️⃣ ALLDEBRID
        action_web_ad_dev, # Index 4  -> Site AllDebrid DEVICE ACTIVATE
        action_web_ad,     # Index 5  -> Site AllDebrid ΚΕΝΤΡΙΚΟ
        action_3,          # Index 6  -> Authorize AD
        action_8,          # Index 7  -> Reset AD
        
        # 3️⃣ REAL DEBRID
        action_web_rd_dev, # Index 8  -> Site Real-Debrid DEVICE ACTIVATE
        action_web_rd,     # Index 9  -> Site Real-Debrid ΚΕΝΤΡΙΚΟ
        action_1,          # Index 10 -> Authorize RD
        action_2,          # Index 11 -> Reset RD
        
        # 4️⃣ PREMIUMIZE.ME
        action_web_pm_dev, # Index 12 -> Site Premiumize DEVICE ACTIVATE
        action_web_pm,     # Index 13 -> Site Premiumize ΚΕΝΤΡΙΚΟ
        action_7,          # Index 14 -> Authorize PM
        action_9,          # Index 15 -> Reset PM
        
        # 5️⃣ ΤΑ ΥΠΟΛΟΙΠΑ
        action_4,          # Index 16 -> Authorize DL (Debrid-Link)
        action_5,          # Index 17 -> Authorize LS (Link Snappy)
        action_10,         # Index 18 -> Reset DL
        action_11          # Index 19 -> Reset LS
    )
    
    # 🎯 ΤΟ ΜΕΝΟΥ: Όλες οι υπηρεσίες με τη νέα σειρά που ζήτησες!
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]Εξουσιοδότηση - Επαναφορά Debrid[/COLOR][/B]', 
[
 # 1️⃣ TORBOX
 '[B][COLOR=mediumseagreen]TorBox [COLOR=white]activate[COLOR=grey] (Σύζευξη Συσκευής)[/COLOR][/B]',
 '[B][COLOR=mediumseagreen]TorBox[COLOR=white] Κεντρική Ιστοσελίδα[/COLOR][/B]',
 '[B][COLOR=mediumseagreen]TorBox[COLOR=lime] Authorize[/COLOR][/B]',
 '[B][COLOR=mediumseagreen]TorBox[COLOR=red] Reset[/COLOR][/B]',
 
 # 2️⃣ ALLDEBRID
 '[B][COLOR=gold]AllDebrid [COLOR=white]activate[COLOR=grey] (Σύζευξη Συσκευής)[/COLOR][/B]',
 '[B][COLOR=gold]AllDebrid[COLOR=white] Κεντρική Ιστοσελίδα[/COLOR][/B]',
 '[B][COLOR=gold]AllDebrid[COLOR=lime] Authorize[/COLOR][/B]',
 '[B][COLOR=gold]AllDebrid[COLOR=red] Reset[/COLOR][/B]',
 
 # 3️⃣ REAL DEBRID
 '[B][COLOR=aquamarine]Real Debrid [COLOR=white]activate[COLOR=grey] (Σύζευξη Συσκευής)[/COLOR][/B]',
 '[B][COLOR=aquamarine]Real Debrid[COLOR=white] Κεντρική Ιστοσελίδα[/COLOR][/B]',
 '[B][COLOR=aquamarine]Real-Debrid[COLOR=lime] Authorize[/COLOR][/B]',
 '[B][COLOR=aquamarine]Real-Debrid[COLOR=red] Reset[/COLOR][/B]',
 
 # 4️⃣ PREMIUMIZE.ME
 '[B][COLOR=firebrick]Premiumize.me [COLOR=white]activate[COLOR=grey] (Σύζευξη Συσκευής)[/COLOR][/B]',
 '[B][COLOR=firebrick]Premiumize.me[COLOR=white] Κεντρική Ιστοσελίδα[/COLOR][/B]',
 '[B][COLOR=firebrick]Premiumize.me[COLOR=lime] Authorize[/COLOR][/B]',
 '[B][COLOR=firebrick]Premiumize.me[COLOR=red] Reset[/COLOR][/B]',
 
 # 5️⃣ DEBRID-LINK & LINK SNAPPY
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Debrid-Link.fr[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Link Snappy[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Debrid-Link.fr[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Link Snappy[/COLOR][/B]'
])

    if selection:
        if selection < 0:
            return 
        # 🔒 Κρατάμε τα δικά σου εργοστασιακά μαθηματικά, κλειδωμένα στις 20 επιλογές!
        func = funcs[selection-20]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 

# =======================================================================
# 🌐 ΟΙ ΣΥΝΑΡΤΗΣΕΙΣ ΓΙΑ ΤΙΣ ΙΣΤΟΣΕΛΙΔΕΣ (ΚΕΝΤΡΙΚΑ & DEVICE LINKS)
# =======================================================================

# 1️⃣ REAL DEBRID LINKS
def action_web_rd_dev():
    open_url_platform("https://real-debrid.com/device")

def action_web_rd():
    open_url_platform("https://real-debrid.com")

# 2️⃣ TORBOX LINKS
def action_web_tb_dev():
    open_url_platform("https://torbox.app/oauth/device") # 🎯 Το σημείο για API/Device στο TorBox

def action_web_tb():
    open_url_platform("https://torbox.app")

# 3️⃣ ALLDEBRID LINKS
def action_web_ad_dev():
    open_url_platform("https://alldebrid.com/pin")

def action_web_ad():
    open_url_platform("https://alldebrid.com")

# 4️⃣ PREMIUMIZE LINKS
# 🎯 Το απευθείας device link του Premiumize
def action_web_pm_dev():
    open_url_platform("https://www.premiumize.me/device")

def action_web_pm():
    open_url_platform("https://premiumize.me")



# 🛠️ ΚΑΘΟΛΙΚΟΣ ΜΗΧΑΝΙΣΜΟΣ ΑΝΟΙΓΜΑΤΟΣ URL ΑΝΑ ΠΛΑΤΦΟΡΜΑ
def open_url_platform(url):
    myplatform = platform_check()
    if myplatform == 'android': 
        xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (url)) #
    else:
        webbrowser.open(url) #

def platform_check():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android' #
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux' #
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows' #
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx' #
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2' #
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios' #
    return 'unknown' #

# =======================================================================
# ⚙️ ΟΙ ΔΙΚΕΣ ΣΟΥ ΣΤΑΘΕΡΕΣ ΔΙΕΡΓΑΣΙΕΣ RESOLVEURL
# =======================================================================
def action_1():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)') #

def action_2():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_rd)') #

def action_3():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)') #

def action_4():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_dl)') #

def action_5():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ls)') #

def action_6():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_tb)') #

def action_7():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)') #

def action_8():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ad)') #

def action_9():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_pm)') #

def action_10():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_dl)') #

def action_11():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ls)') #

def action_12():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_tb)') #

# 🔥 ΕΚΤΕΛΕΣΗ
derbid_authorize() #
