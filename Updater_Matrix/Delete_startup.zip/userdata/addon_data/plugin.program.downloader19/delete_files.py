﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# ⚙️ ΑΡΧΙΚΗ ΡΥΘΜΙΣΗ ΜΗΝΥΜΑΤΟΣ (ΟΡΙΖΕΙΣ Ο,ΤΙ ΘΕΛΕΙΣ ΕΔΩ!)
sound_file = 'special://skin/sounds/monster.wav'
icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'

# =======================================================================
# 🗑️ ΛΙΣΤΑ Α: ΦΑΚΕΛΟΙ ΚΑΙ ΑΡΧΕΙΑ ΠΡΟΣ ΔΙΑΓΡΑΦΗ (Addons & Addon_Data)
# =======================================================================
delete_list = [
    'repository.test1', 'plugin.video.AliveGR', 'repository.diamondrepo', 
    'plugin.video.maneflix', 'script.module.accountmgr', 'repository.gwen84', 
    'repository.madforit', 'repository.greenball', 'repository.streamedez', 
    'service.audio.tmdb.sync', 'repository.test2', 'plugin.video.test',
    'MatrixFlix.Repo', 'repository.mrfixit2001', 'plugin.video.matrixflix',
    '__pycache__'
]

# =======================================================================
# 🗑️ ΛΙΣΤΑ Β: SUPER FAVOURITES ΦΑΚΕΛΟΙ ΠΡΟΣ ΔΙΑΓΡΑΦΗ
# =======================================================================
fav_delete_list = [
    'blackghostaddon', 'diggz Super Favourites - test', 
    'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
]

def clean_build_system():
    # 🧼 1. Διαγραφή μεμονωμένων αρχείων .py ή .xml
    xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
    xbmc.sleep(100)

    # 📥 Αρχικό γέμισμα Skin Strings για να ανοίξει το custom XML παράθυρο
    xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR grey]Προετοιμασία καθαρισμού...[/COLOR])')
    xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    xbmc.executebuiltin('ActivateWindow(4200)')
    xbmc.sleep(1500) # Λίγος χρόνος παραπάνω στην έναρξη

    # 🧼 2. ΟΛΙΚΟ ΚΑΘΑΡΙΣΤΗΡΙ (Addons & Addon_Data)
    addons_root = xbmcvfs.translatePath('special://home/addons')
    data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
    downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    for item in delete_list:
        paths_to_check = [
            os.path.join(addons_root, item),
            os.path.join(data_root, item),
            os.path.join(downloader_data, item)
        ]
        
        # 🔥 DYNAMIC LIVE TRACKER (ΑΡΓΗ ΡΟΗ): Ενημερώνουμε ξεκάθαρα την οθόνη
        display_name = "Προσωρινής μνήμης (cache)" if item == "__pycache__" else item
        xbmc.executebuiltin(f'Skin.SetString(NotifyMessage,[COLOR darkorange]Καθαρισμός: {display_name}[/COLOR])')
        xbmc.sleep(1200) # ⏱️ Διορθώθηκε σε 1.2 δευτερόλεπτα για άνετη ανάγνωση!

        for full_path in paths_to_check:
            if os.path.exists(full_path):
                try:
                    if os.path.isdir(full_path):
                        shutil.rmtree(full_path)
                    elif os.path.isfile(full_path):
                        os.remove(full_path)
                except:
                    pass

    # 🧼 3. ΚΑΘΑΡΙΣΜΟΣ SUPER FAVOURITES (Λίστα Β)
    fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
    
    if os.path.exists(fav_root):
        for fav_item in fav_delete_list:
            # 🔥 LIVE TRACKER ΓΙΑ ΤΑ SUPER FAVOURITES (ΑΡΓΗ ΡΟΗ)
            xbmc.executebuiltin(f'Skin.SetString(NotifyMessage,[COLOR lime]Fav: {fav_item}[/COLOR])')
            xbmc.sleep(1200) # ⏱️ Σταθερά 1.2 δευτερόλεπτα και εδώ

            full_fav_path = os.path.join(fav_root, fav_item)
            if os.path.exists(full_fav_path):
                try:
                    if os.path.isdir(full_fav_path):
                        shutil.rmtree(full_fav_path)
                except:
                    pass

    # 🎉 ΤΕΛΙΚΟ ΜΗΝΥΜΑ
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Ο καθαρισμός ολοκληρώθηκε![/COLOR])')
    xbmc.sleep(2500) # Δίνουμε 2.5 δευτερόλεπτα στο τέλος να φανεί η επιτυχία

# 🚀 Εκτέλεση του απόλυτου dynamic καθαρισμού
clean_build_system()
