﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# 🎯 ΟΡΙΣΜΟΣ ΚΑΙ ΔΗΜΟΥΡΓΙΑ ΤΟΥ LOCK ΑΡΧΕΙΟΥ
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
DELETE_LOCK_FILE = os.path.join(profile_dir, 'delete_lock.txt')

if not os.path.exists(profile_dir):
    os.makedirs(profile_dir)

with open(DELETE_LOCK_FILE, 'w') as f:
    f.write('RUNNING')

xbmc.log("[World_Updater] Δημιουργήθηκε το delete_lock.txt από το delete_files.py", xbmc.LOGINFO)

# ⚙️ ΑΡΧΙΚΗ ΡΥΘΜΙΣΗ ΜΗΝΥΜΑΤΟΣ
sound_file = 'special://skin/sounds/monster.wav'
icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'

delete_list = [
    'repository.test1', 'plugin.video.AliveGR', 'repository.diamondrepo', 
    'plugin.video.maneflix', 'script.module.accountmgr', 'repository.gwen84', 
    'repository.madforit', 'repository.greenball', 'repository.streamedez', 
    'repository.southpaw', 'repository.test2', 'plugin.video.test',
    'MatrixFlix.Repo', 'repository.mrfixit2001', 'plugin.video.matrixflix',
    '__pycache__'
]

fav_delete_list = [
    'blackghostaddon', 'diggz Super Favourites - test', 
    'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
]

def clean_build_system():
    xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
    xbmc.sleep(100)

    xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR grey]Γίνεται εκκαθάριση αρχείων...[/COLOR])')
    xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    xbmc.executebuiltin('ActivateWindow(4205)')
    xbmc.sleep(1500)

    addons_root = xbmcvfs.translatePath('special://home/addons')
    data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
    downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    for item in delete_list:
        paths_to_check = [
            os.path.join(addons_root, item),
            os.path.join(data_root, item),
            os.path.join(downloader_data, item)
        ]
        
        xbmc.sleep(1000) 

        for full_path in paths_to_check:
            if os.path.exists(full_path):
                try:
                    if os.path.isdir(full_path):
                        shutil.rmtree(full_path)
                    elif os.path.isfile(full_path):
                        os.remove(full_path)
                except:
                    pass

    fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
    
    if os.path.exists(fav_root):
        for fav_item in fav_delete_list:
            xbmc.sleep(1000) 

            full_fav_path = os.path.join(fav_root, fav_item)
            if os.path.exists(full_fav_path):
                try:
                    if os.path.isdir(full_fav_path):
                        shutil.rmtree(full_fav_path)
                except:
                    pass

    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Ο καθαρισμός ολοκληρώθηκε![/COLOR])')
    xbmc.sleep(2500)
    
    # 🤫 ΚΛΕΙΝΟΥΜΕ ΤΟ ΠΑΡΑΘΥΡΟ ΧΕΙΡΟΚΙΝΗΤΑ ΑΠΟ ΤΗΝ PYTHON
    xbmc.executebuiltin('Dialog.Close(4205)')
    xbmc.sleep(500) # Δίνουμε μισό δευτερόλεπτο να προλάβει το εφέ εξόδου (WindowClose)

    # 🧼 ΣΒΗΣΙΜΟ ΤΟΥ LOCK ΑΡΧΕΙΟΥ ΣΤΟ ΑΠΟΛΥΤΟ ΤΕΛΟΣ (Μέσα στη συνάρτηση!)
    if os.path.exists(DELETE_LOCK_FILE):
        try:
            os.remove(DELETE_LOCK_FILE)
            xbmc.log("[World_Updater] Το delete_lock.txt αφαιρέθηκε επιτυχώς αφού ολοκληρώθηκαν όλα.", xbmc.LOGINFO)
        except:
            pass

clean_build_system()

