﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# 🎯 ΟΡΙΣΜΟΣ ΚΑΙ ΔΗΜΟΥΡΓΙΑ ΤΟΥ LOCK ΑΡΧΕΙΟΥ
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
DELETE_LOCK_FILE = os.path.join(profile_dir, 'delete_lock.txt')

if not os.path.exists(profile_dir):
    os.makedirs(profile_dir)

with open(DELETE_LOCK_FILE, 'w') as f:
    f.write('RUNNING')

xbmc.log("[World_Updater] Δημιουργήθηκε το delete_lock.txt από το delete_files.py", xbmc.LOGINFO)

# ⚙️ ΑΡΧΙΚΗ ΡΥΘΜΙΣΗ ΜΗΝΥΜΑΤΟΣ
sound_file = 'special://skin/sounds/monster.wav'
icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'

delete_list = [
    'repository.test1', 'plugin.video.AliveGR', 'repository.diamondrepo', 
    'plugin.video.maneflix', 'script.module.accountmgr', 'repository.gwen84', 
    'repository.madforit', 'repository.greenball', 'repository.streamedez', 
    'repository.southpaw', 'repository.test2', 'plugin.video.test',
    'MatrixFlix.Repo', 'repository.mrfixit2001', 'plugin.video.matrixflix',
    '__pycache__'
]

fav_delete_list = [
    'blackghostaddon', 'diggz Super Favourites - test', 
    'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
]

def clean_build_system():
    # 🧼 ΣΒΗΣΙΜΟ ΠΑΛΙΩΝ ΚΑΤΑΛΟΙΠΩΝ (Εδώ μπαίνουν όλα!)
    xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
    
    # 🧹 1. Σβήνουμε το παλό zip2_lock.txt χρησιμοποιώντας το profile_dir που έχεις ορίσει πιο πάνω
    old_zip2_lock = os.path.join(profile_dir, 'zip2_lock.txt')
    if os.path.exists(old_zip2_lock):
        try:
            os.remove(old_zip2_lock)
            xbmc.log("[World_Updater] [Καθαρισμός] Το παλιό κατάλοιπο zip2_lock.txt διαγράφηκε.", xbmc.LOGINFO)
        except:
            pass

    # 🧹 Σβήνουμε το installation_lock.txt που ξέμεινε από παλιές δοκιμές
    old_install_lock = os.path.join(profile_dir, 'installation_lock.txt')
    if os.path.exists(old_install_lock):
        try:
            os.remove(old_install_lock)
            xbmc.log("[World_Updater] [Καθαρισμός] Το παλίο κατάλοιπο installation_lock.txt διαγράφηκε.", xbmc.LOGINFO)
        except:
            pass


    # 🎬 2. Σβήνουμε και τον παλιό player του TMDB Helper με xbmcvfs.delete όπως συζητήσαμε
    xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json')

    xbmc.sleep(100)
    
    # ⚙️ Από εδώ και κάτω ο κώδικάς σου συνεχίζει κανονικά...
    xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR grey]Γίνεται εκκαθάριση αρχείων...[/COLOR])')
    xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    xbmc.executebuiltin('ActivateWindow(4205)')
    xbmc.sleep(1500)

    addons_root = xbmcvfs.translatePath('special://home/addons')
    data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
    downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    for item in delete_list:
        paths_to_check = [
            os.path.join(addons_root, item),
            os.path.join(data_root, item),
            os.path.join(downloader_data, item)
        ]
        
        xbmc.sleep(100) 

        for full_path in paths_to_check:
            if os.path.exists(full_path):
                try:
                    if os.path.isdir(full_path):
                        shutil.rmtree(full_path)
                    elif os.path.isfile(full_path):
                        os.remove(full_path)
                except:
                    pass

    fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
    
    if os.path.exists(fav_root):
        for fav_item in fav_delete_list:
            xbmc.sleep(100) 

            full_fav_path = os.path.join(fav_root, fav_item)
            if os.path.exists(full_fav_path):
                try:
                    if os.path.isdir(full_fav_path):
                        shutil.rmtree(full_fav_path)
                except:
                    pass

    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Ο καθαρισμός ολοκληρώθηκε![/COLOR])')
    xbmc.sleep(1000)

    # 🧼 ΣΒΗΣΙΜΟ ΤΟΥ LOCK ΑΡΧΕΙΟΥ
    if os.path.exists(DELETE_LOCK_FILE):
        try:
            os.remove(DELETE_LOCK_FILE)
            xbmc.log("[World_Updater] Το delete_lock.txt αφαιρέθηκε. Παράδοση σκυτάλης στο επόμενο check.", xbmc.LOGINFO)
        except:
            pass

clean_build_system()

