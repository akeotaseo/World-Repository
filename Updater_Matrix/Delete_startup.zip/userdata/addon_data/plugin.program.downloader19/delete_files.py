﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
import json
from updatervar import *

# 🎯 ΟΡΙΣΜΟΣ ΚΑΙ ΔΗΜΙΟΥΡΓΙΑ ΤΟΥ LOCK ΑΡΧΕΙΟΥ
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
DELETE_LOCK_FILE = os.path.join(profile_dir, 'delete_lock.txt')

if not os.path.exists(profile_dir):
	os.makedirs(profile_dir)

with open(DELETE_LOCK_FILE, 'w') as f:
	f.write('RUNNING')

xbmc.log("[World_Updater] Δημιουργήθηκε το delete_lock.txt από το delete_files.py", xbmc.LOGINFO)
xbmc.sleep(2000)

# ⚙️ ΑΡΧΙΚΗ ΡΥΘΜΙΣΗ ΜΗΝΥΜΑΤΟΣ
sound_file = 'special://skin/sounds/monster.wav'
icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'

# 🎯 Η ΛΙΣΤΑ ΣΟΥ: Αφαιρέθηκε το διπλό All_Subs και διορθώθηκε ένα κόμμα στο τέλος
delete_list = [
	'repository.test1', 
	'MatrixFlix.Repo', 'repository.diamondrepo', 'repository.greenball', 'repository.gwen84', 'repository.madforit', 'repository.mrfixit2001', 'repository.rays.files', 'repository.sportsurge', 'repository.streamedez', 'repository.southpaw', 
	'plugin.video.maneflix', 'script.module.accountmgr', 
	'plugin.video.matrixflix', 
	'service.subtitles.All_Subs', 'service.subtitles.subscene', 'service.subtitles.subsource-net', 
	'repository.test2',
	'__pycache__'
]

fav_delete_list = [
	'blackghostaddon', 'diggz Super Favourites - test', 
	'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
]

def clean_build_system():
	# 🧼 ΣΒΗΣΙΜΟ ΠΑΛΙΩΝ ΚΑΤΑΛΟΙΠΩΝ
	xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
	
	old_zip2_lock = os.path.join(profile_dir, 'zip2_lock.txt')
	if os.path.exists(old_zip2_lock):
		try: os.remove(old_zip2_lock)
		except: pass

	old_install_lock = os.path.join(profile_dir, 'installation_lock.txt')
	if os.path.exists(old_install_lock):
		try: os.remove(old_install_lock)
		except: pass

	xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json')
	xbmc.sleep(100)
	
	# ⚙️ ΕΝΕΡΓΟΠΟΙΗΣΗ CUSTOM WINDOW
	xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
	xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR grey]Γίνεται εκκαθάριση αρχείων...[/COLOR])')
	xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
	xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
	xbmc.executebuiltin('ActivateWindow(4205)')
	xbmc.sleep(1500)

	addons_root = xbmcvfs.translatePath('special://home/addons')
	data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
	downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

	# 🔄 ΒΗΜΑ Α: ΔΙΑΓΡΑΦΗ ΤΗΣ delete_list ΜΕ ΕΞΥΠΝΑ NOTIFICATIONS & RAM LOCKS
	for item in delete_list:
		paths_to_check = [
			os.path.join(addons_root, item),
			os.path.join(data_root, item),
			os.path.join(downloader_data, item)
		]
		xbmc.sleep(100) 

		# 🔒 [ΘΩΡΑΚΙΣΜΕΝΟΣ ΕΛΕΓΧΟΣ ΜΕ XBMCVFS]
		# Αν το πρόσθετο όντως υπάρχει στον φάκελο addons του Kodi (πραγματικός έλεγχος)
		vfs_addon_path = f'special://home/addons/{item}'
		if xbmcvfs.exists(vfs_addon_path) and not item == '__pycache__':
			check_addon_folder = os.path.join(addons_root, item)
			current_icon = os.path.join(check_addon_folder, 'icon.png')
			
			xbmcgui.Dialog().notification(
				"[COLOR red]Απεγκατάσταση[/COLOR]", 
				f"του Πρόσθετου [B]{item}[/B]", 
				sound=False, 
				icon=current_icon if os.path.exists(current_icon) else icon_file
			)
			xbmc.sleep(1000)

			# JSON-RPC DISABLE: Απενεργοποίηση για να μην κρασάρει η RAM
			try:
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "' + item + '","enabled":false}}')
				xbmc.sleep(400)
			except:
				pass

		# Εκτέλεση της κλασικής διαγραφής αρχείων/φακέλων
		for full_path in paths_to_check:
			if os.path.exists(full_path):
				try:
					if os.path.isdir(full_path): shutil.rmtree(full_path)
					elif os.path.isfile(full_path): os.remove(full_path)
				except:
					pass

	# 🔄 ΒΗΜΑ Β: ΔΙΑΓΡΑΦΗ SUPER FAVOURITES
	fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
	if os.path.exists(fav_root):
		for fav_item in fav_delete_list:
			xbmc.sleep(100) 
			full_fav_path = os.path.join(fav_root, fav_item)
			if os.path.exists(full_fav_path):
				try:
					if os.path.isdir(full_fav_path): shutil.rmtree(full_fav_path)
				except:
					pass

	xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Ο καθαρισμός ολοκληρώθηκε![/COLOR])')
	xbmc.sleep(1000)

	# 🧼 ΣΒΗΣΙΜΟ ΤΟΥ LOCK ΑΡΧΕΙΟΥ
	if os.path.exists(DELETE_LOCK_FILE):
		try:
			os.remove(DELETE_LOCK_FILE)
			xbmc.log("[World_Updater] To delete_lock.txt αφαιρέθηκε. Παράδοση σκυτάλης στο επόμενο check.", xbmc.LOGINFO)
		except:
			pass

	# 🔄 Φρεσκάρισμα του συστήματος
	xbmc.executebuiltin('UpdateLocalAddons')

clean_build_system()
