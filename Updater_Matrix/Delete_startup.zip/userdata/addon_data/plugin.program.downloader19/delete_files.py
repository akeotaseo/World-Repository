﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# ⚙️ ΡΥΘΜΙΣΗ ΜΗΝΥΜΑΤΟΣ (ΟΡΙΖΕΙΣ Ο,ΤΙ ΘΕΛΕΙΣ ΕΔΩ!)
sound_file = 'special://skin/sounds/monster.wav'
icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'
msg_text   = '[COLOR grey]αχρείαστων αρχείων...[/COLOR]'

# 📥 DYNAMIC INJECTION: Γεμίζουμε τη μνήμη του Skin για το Custom XML παράθυρο
xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
xbmc.executebuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
xbmc.executebuiltin('ActivateWindow(4200)')

# =======================================================================
# 🗑️ ΛΙΣΤΑ Α: ΦΑΚΕΛΟΙ ΚΑΙ ΑΡΧΕΙΑ ΠΡΟΣ ΔΙΑΓΡΑΦΗ (Addons & Addon_Data)
# Εδώ βάζεις όνομα φακέλου ή αρχείου. Το script θα πάει και θα το σβήσει 
# ΑΥΤΟΜΑΤΑ και από το special://home/addons/ ΚΑΙ από το special://home/userdata/addon_data/ !
# =======================================================================
delete_list = [
    'repository.test1', 'plugin.video.AliveGR', 'repository.diamondrepo', 
    'plugin.video.maneflix', 'script.module.accountmgr', 'repository.gwen84', 
    'repository.madforit', 'repository.greenball', 'repository.streamedez', 
    'service.audio.tmdb.sync', 'repository.test2', 'plugin.video.test',
    'MatrixFlix.Repo', 'repository.mrfixit2001', 'plugin.video.matrixflix',
    '__pycache__'
]

# =======================================================================
# 🗑️ ΛΙΣΤΑ Β: SUPER FAVOURITES ΦΑΚΕΛΟΙ ΠΡΟΣ ΔΙΑΓΡΑΦΗ
# Φακέλοι που βρίσκονται μέσα στο mypreferences / Super Favourites
# =======================================================================
fav_delete_list = [
    'blackghostaddon', 'diggz Super Favourites - test', 
    'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
]

def clean_build_system():
    # 🧼 1. Διαγραφή μεμονωμένων αρχείων .py ή .xml
    # (Εδώ κρατάμε τις χειροκίνητες διαγραφές αρχείων που είχες)
    xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
    xbmc.sleep(100)

    # 🧼 2. ΟΛΙΚΟ ΚΑΘΑΡΙΣΤΗΡΙ (Addons & Addon_Data)
    # Μεταφράζουμε τις βασικές διαδρομές του Kodi
    addons_root = xbmcvfs.translatePath('special://home/addons')
    data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
    downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    for item in delete_list:
        # Ψάχνουμε dynamic σε 3 διαφορετικούς φακέλους για το κάθε item της λίστας
        paths_to_check = [
            os.path.join(addons_root, item),
            os.path.join(data_root, item),
            os.path.join(downloader_data, item) # Για το __pycache__ σου
        ]
        
        for full_path in paths_to_check:
            if os.path.exists(full_path):
                try:
                    if os.path.isdir(full_path):
                        shutil.rmtree(full_path)
                    elif os.path.isfile(full_path):
                        os.remove(full_path)
                except:
                    pass # Ασφάλεια για να μην κρασάρει αν κάποιο αρχείο είναι κλειδωμένο

    # 🧼 3. ΚΑΘΑΡΙΣΜΟΣ SUPER FAVOURITES (Λίστα Β)
    fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
    
    if os.path.exists(fav_root):
        for fav_item in fav_delete_list:
            full_fav_path = os.path.join(fav_root, fav_item)
            if os.path.exists(full_fav_path):
                try:
                    if os.path.isdir(full_fav_path):
                        shutil.rmtree(full_fav_path)
                except:
                    pass

# 🚀 Εκτέλεση του απόλυτου καθαρισμού
clean_build_system()
