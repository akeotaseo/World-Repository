﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# ⚙️ ΑΡΧΙΚΗ ΡΥΘΜΙΣΗ ΜΗΝΥΜΑΤΟΣ
sound_file = 'special://skin/sounds/monster.wav'
icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'

delete_list = [
    'repository.test1', 'plugin.video.AliveGR', 'repository.diamondrepo', 
    'plugin.video.maneflix', 'script.module.accountmgr', 'repository.gwen84', 
    'repository.madforit', 'repository.greenball', 'repository.streamedez', 
    'repository.southpaw', 'repository.test2', 'plugin.video.test',
    'MatrixFlix.Repo', 'repository.mrfixit2001', 'plugin.video.matrixflix',
    '__pycache__'
]

fav_delete_list = [
    'blackghostaddon', 'diggz Super Favourites - test', 
    'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
]

def clean_build_system():
    # 🎯 ΣΗΜΑΔΟΥΡΑ ΕΝΑΡΞΗΣ: Κλειδώνουμε την ουρά στην C++ του Kodi
    xbmc.executebuiltin('Skin.SetString(DeleteRunning,true)')
    
    # 🧼 1. Διαγραφή μεμονωμένων αρχείων .py ή .xml
    xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
    xbmc.sleep(100)

    # 📥 Αρχικό γέμισμα Skin Strings για το custom XML παράθυρο
    xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR grey]Προετοιμασία καθαρισμού...[/COLOR])')
    xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    xbmc.executebuiltin('ActivateWindow(4200)')
    xbmc.sleep(1500)

    # 🧼 2. ΟΛΙΚΟ ΚΑΘΑΡΙΣΤΗΡΙ (Addons & Addon_Data)
    addons_root = xbmcvfs.translatePath('special://home/addons')
    data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
    downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    # 🎯 ΣΤΑΘΕΡΟ ΜΗΝΥΜΑ: Αντί για live tracker, γράφουμε ένα γενικό μήνυμα στην οθόνη
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR darkorange]Εκκαθάριση αρχείων...[/COLOR])')

    for item in delete_list:
        paths_to_check = [
            os.path.join(addons_root, item),
            os.path.join(data_root, item),
            os.path.join(downloader_data, item)
        ]
        
        # ⏱️ Αργή ροή για ασφάλεια χωρίς να αλλάζει το κείμενο πάνω δεξιά
        xbmc.sleep(1200) 

        for full_path in paths_to_check:
            if os.path.exists(full_path):
                try:
                    if os.path.isdir(full_path):
                        shutil.rmtree(full_path)
                    elif os.path.isfile(full_path):
                        os.remove(full_path)
                except:
                    pass

    # 🧼 3. ΚΑΘΑΡΙΣΜΟΣ SUPER FAVOURITES
    fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
    
    if os.path.exists(fav_root):
        # 🎯 ΣΤΑΘΕΡΟ ΜΗΝΥΜΑ ΚΑΙ ΕΔΩ: Δεν δείχνουμε ονόματα
        xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Καθαρισμός Super Favourites...[/COLOR])')
        
        for fav_item in fav_delete_list:
            xbmc.sleep(1200) 

            full_fav_path = os.path.join(fav_root, fav_item)
            if os.path.exists(full_fav_path):
                try:
                    if os.path.isdir(full_fav_path):
                        shutil.rmtree(full_fav_path)
                except:
                    pass


    # 🎉 ΤΕΛΙΚΟ ΜΗΝΥΜΑ
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Ο καθαρισμός ολοκληρώθηκε![/COLOR])')
    xbmc.sleep(2500)
    
    # 🧼 ΣΒΗΣΙΜΟ ΣΗΜΑΔΟΥΡΑΣ: Ξεκλειδώνουμε την ουρά, τώρα μπορεί να ξεκινήσει το επόμενο Zip!
    xbmc.executebuiltin('Skin.ResetString(DeleteRunning)')

# 🚀 Εκτέλεση
clean_build_system()
