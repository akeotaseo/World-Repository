﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request

xbmcgui.Dialog().notification("[COLOR red]Απενεργοποίση του Πρόσθετου[/COLOR]", "[B][COLOR lime]The Loop[/COLOR][/B]", sound=False, icon='special://home/addons/plugin.video.the-loop/icon.png')

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.video.the-loop","enabled":false}}')
