import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, subprocess
import time  # 👈 ΠΡΟΣΘΕΣΕ ΑΥΤΗ ΤΗ ΓΡΑΜΜΗ ΣΤΗΝ ΚΟΡΥΦΗ ΤΟΥ check.py!
from updatervar import *
from xml.dom.minidom import parse
from resources.lib.GUIcontrol import notify
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_addonsrepos, get_xmlskin, get_players, get_set_setting, get_var
from resources.lib.GUIcontrol.txt_updater import get_addons_list_installation, get_delete_files, get_zip1, get_zip2, get_zip3, get_zip4, get_zip5
from resources.lib.GUIcontrol.txt_updater import get_pvr
from resources.lib.modules import addonsEnable
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons

addons_list_installation_version = get_addons_list_installation()
notify_version       = get_notifyversion()
addons_repos_version = get_addonsrepos()
xmlskin_version      = get_xmlskin()
players_version      = get_players()
set_setting_version  = get_set_setting()
delete_files_version = get_delete_files()
var_version          = get_var()
zip1_version         = get_zip1()
zip2_version         = get_zip2()
zip3_version         = get_zip3()
zip4_version         = get_zip4()
zip5_version         = get_zip5()
pvr_version          = get_pvr()
dialog = xbmcgui.Dialog()
settings_path = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/')
homeset_path = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/')


def autoenable():
    if setting('autoenable') == 'true':
        addonsEnable.enable_addons()
        setting_set('autoenable','false')
        dialog.notification(Dialog_enable_on, Dialog_enable, icon_Build, sound=False)


def notifyT():
    if not setting('firstrunNotify')=='false':
        if notify_version > int(setting('notifyversion')):
            setting_set('notifyversion', str(notify_version))
            d=notify.notify()
            d.doModal()
            del d
            BG.create(Dialog_U8, Dialog_U6)
            xbmc.sleep(5000)
            BG.close()
# ----------------------------------------------------------------------
# 🎯 Ο ΕΞΥΠΝΟΣ ΕΛΕΓΧΟΣ ΑΝΑΜΟΝΗΣ ΠΟΥ ΣΥΖΗΤΗΣΑΜΕ
# ----------------------------------------------------------------------
def wait_for_kodi(label_name="Διαδικασία"):
    xbmc.sleep(1000)
    xbmc.log(f"[Master_Build] Έλεγχος background για: {label_name}", xbmc.LOGINFO)
    
    while (
        xbmc.getCondVisibility("Window.IsActive(busydialog)") or 
        xbmc.getCondVisibility("Window.IsActive(infodialog)") or
        xbmc.getCondVisibility("Window.IsActive(progressdialog)") or
        xbmc.getCondVisibility("Library.IsScanningVideo")
    ):
        xbmc.log(f"[Master_Build] Αναμονή 1.5s για το βήμα: {label_name}...", xbmc.LOGINFO)
        xbmc.sleep(1500) 
        
    xbmc.log(f"[Master_Build] [ΚΑΘΑΡΟ ΠΕΔΙΟ] Προχωράμε στο: {label_name}", xbmc.LOGINFO)
    xbmc.sleep(500)






def run_delete_files():
    sound_file = 'special://skin/sounds/monster.wav'
    icon_file  = 'special://home/addons/plugin.program.downloader19/resources/media/delete.png'
    title_text = '[COLOR white]Πραγματοποιείται διαγραφή[/COLOR]'

    delete_list = [
        'repository.test1', 
        'MatrixFlix.Repo', 'repository.diamondrepo', 'repository.greenball', 'repository.gwen84', 'repository.madforit', 'repository.mrfixit2001', 'repository.rays.files', 'repository.sportsurge', 'repository.streamedez', 'repository.southpaw', 'repository.kodimate', 
        'script.kodimate', 
        'plugin.video.maneflix', 'script.module.accountmgr', 'context.subtitlesdialog.contextmenu', 
        'plugin.video.matrixflix', 
        'service.subtitles.All_Subs', 'service.subtitles.subscene', 'service.subtitles.subsource-net', 'service.subtitles.opensubtitles_by_opensubtitles_dualsub', 
        'plugin.video.romyTVlist', 
        'repository.test2',
        '__pycache__'
    ]

    fav_delete_list = [
        'blackghostaddon', 'diggz Super Favourites - test', 
        'EX -Simple Favourites', 'GR', 'Remote x-treme codes', 'Subscription Addons'
    ]

    # Σβήσιμο παλιών καταλοίπων
    xbmcvfs.delete('special://home/addons/plugin.program.downloader19/Database_Addons33_Enable.py')
    xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json')
    xbmc.sleep(100)
    
    # Ενεργοποίηση Custom Window (κλείνει αυτόματα στα 6 δευτερόλεπτα)
    xbmc.executebuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR grey]Γίνεται εκκαθάριση αρχείων...[/COLOR])')
    xbmc.executebuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbmc.executebuiltin(f'Skin.SetString(NotifySound,{sound_file})')
    xbmc.executebuiltin('ActivateWindow(4205)')
    xbmc.sleep(1500)

    addons_root = xbmcvfs.translatePath('special://home/addons')
    data_root = xbmcvfs.translatePath('special://home/userdata/addon_data')
    downloader_data = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    # Βήμα Α: Διαγραφή της delete_list
    for item in delete_list:
        paths_to_check = [
            os.path.join(addons_root, item),
            os.path.join(data_root, item),
            os.path.join(downloader_data, item)
        ]
        xbmc.sleep(100) 

        vfs_addon_path = f'special://home/addons/{item}'
        if xbmc.getCondVisibility(f'System.HasAddon({item})') or (os.path.exists(os.path.join(addons_root, item)) and item != '__pycache__'):
            check_addon_folder = os.path.join(addons_root, item)
            current_icon = os.path.join(check_addon_folder, 'icon.png')
            
            xbmcgui.Dialog().notification(
                "[COLOR red]Απεγκατάσταση[/COLOR]", 
                f"του Πρόσθετου [B]{item}[/B]", 
                sound=False, 
                icon=current_icon if os.path.exists(current_icon) else icon_file
            )
            xbmc.sleep(1000)

            try:
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "' + item + '","enabled":false}}')
                xbmc.sleep(400)
            except:
                pass

        for full_path in paths_to_check:
            if os.path.exists(full_path):
                try:
                    if os.path.isdir(full_path): shutil.rmtree(full_path)
                    elif os.path.isfile(full_path): os.remove(full_path)
                except:
                    pass

    # Βήμα Β: Διαγραφή Super Favourites
    fav_root = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.mypreferences/Super Favourites')
    if os.path.exists(fav_root):
        for fav_item in fav_delete_list:
            xbmc.sleep(100) 
            full_fav_path = os.path.join(fav_root, fav_item)
            if os.path.exists(full_fav_path):
                try:
                    if os.path.isdir(full_fav_path): shutil.rmtree(full_fav_path)
                except:
                    pass

    xbmc.executebuiltin('Skin.SetString(NotifyMessage,[COLOR lime]Ο καθαρισμός ολοκληρώθηκε![/COLOR])')
    xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateLocalAddons')





# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ DELETE (The Smart Timing Shift)
# ----------------------------------------------------------------------
def delete():
    if delete_files_version > int(setting('deleteversion')):
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py')
        
        BG.create(Dialog_U2, Dialog_U11)
        xbmc.sleep(1000)
        BG.update(33, Dialog_U2, Dialog_U11)
        
        # Εκτέλεση της αυτόνομης συνάρτησης διαγραφής
        run_delete_files()
        
        BG.update(80, Dialog_U2, Dialog_U10)
        xbmc.sleep(1500)
        
        setting_set('deleteversion', str(delete_files_version))
        BG.update(100, Dialog_U12, Dialog_U2)
        xbmc.sleep(1500)
        BG.close()
        
        # Περιμένουμε να κλείσει το παράθυρο 4205 (6s) και να ολοκληρωθεί το UpdateLocalAddons
        wait_for_kodi("Διαγραφή Αρχείων (Delete)")






# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP2 (Περιμένει να κάτσει η database και τα addons)
# ----------------------------------------------------------------------
def zip2():
    if zip2_version > int(setting('zip2version')):
        
        wait_for_kodi("Προετοιμασία Zip2 (Zip2 Pre-Check)")
            
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        
        xbmc.executebuiltin(Zip2_startup)
        xbmc.sleep(2000) 
        BG.update(25, Dialog_U12, 'Zip2')
        
        BG.update(25, Dialog_U12, Dialog_U3)
        setting_set('zip2version', str(zip2_version))
        
        BG.update(35, Dialog_U12, 'Γίνεται αποσυμπίεση αρχείων... (1/3)')
        xbmc.sleep(3000)
        BG.update(55, Dialog_U12, 'Γίνεται αντιγραφή αρχείων... (2/3)')
        xbmc.sleep(3000)
        BG.update(75, Dialog_U12, 'Παρακαλώ περιμένετε... (3/3)')
        xbmc.sleep(3000)

                # 🧼 ΔΙΟΡΘΩΜΕΝΟ LABEL: Τώρα λέει ακριβώς τι συμβαίνει εκείνη τη στιγμή!
        BG.update(85, Dialog_U12, 'Μαζική ενεργοποίηση προσθέτων...')

        
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2000) 
        
        # 🔥 ΕΔΩ ΕΙΝΑΙ Η ΑΛΛΑΓΗ: Καλούμε τη δική μας turbo συνάρτηση!
        turbo_enable_addons_zip2()
        xbmc.sleep(1000) 
        
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
        BG.close()
        
        wait_for_kodi("Εγκατάσταση Zip2 Addons")





def run_addons_installation():
    xbmcgui.Dialog().notification("Εγκατάσταση προσθέτων", "Έλεγχος λίστας...", icon='special://home/addons/plugin.program.downloader19/resources/media/install.png', sound=False)
    
    addons_list_installation = [
        'repository.World', 'service.audio.tmdb.sync', 'script.subterra', 
        'repository.giaitri', 'repository.rdplayer', 
        'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 
        'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 
        'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 
        'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 
        'repository.wetdreams69', 'repository.seriesly', 
        'repository.thetallone', 'repository.starfleet', 'repository.opencode', 
        'repository.sniper', 'repository.vortex', 'repository.Worldrepo'
    ]

    addons_root = xbmcvfs.translatePath('special://home/addons')
    def _is_installed(aid):
        if os.path.exists(os.path.join(addons_root, aid)):
            return True
        return xbmc.getCondVisibility(f'System.HasAddon({aid})')

    total_addons = len(addons_list_installation)

    for index, addon_id in enumerate(addons_list_installation):
        if _is_installed(addon_id):
            continue

        perc = int(20 + (75 * (index + 1) / total_addons))
        clean_message = f'[COLOR orange]Γίνεται εγκατάσταση... ({index+1}/{total_addons})[/COLOR]'
        BG.update(perc, Dialog_U12, f'Εγκατάσταση: {addon_id} ({index+1}/{total_addons})')
        xbmc.executebuiltin(f'Skin.SetString(NotifyMessage,{clean_message})')
        xbmc.log(f"[Master_Build] [INSTALL] Λήψη προσθέτου: {addon_id}", xbmc.LOGINFO)

        try:
            xbmc.executebuiltin(f'InstallAddon({addon_id})')
            xbmc.sleep(800)
            xbmc.executebuiltin('SendClick(11)')
        except:
            pass

        timeout_counter = 0
        while not _is_installed(addon_id) and timeout_counter < 12:
            xbmc.sleep(500)
            timeout_counter += 1
            if timeout_counter % 5 == 0:
                try: xbmc.executebuiltin('SendClick(11)')
                except: pass

    xbmc.executebuiltin('Skin.ResetString(NotifyMessage)')

def installation():
    if addons_list_installation_version > int(setting('installationversion')):
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py')
        
        BG.create(Dialog_U12, Dialog_U6)
        BG.update(15, Dialog_U12, 'Έλεγχος εγκατεστημένων προσθέτων...')
        
        setting_set('installationversion', str(addons_list_installation_version))
        run_addons_installation()
        
        BG.update(100, Dialog_U12, 'Η εγκατάσταση ολοκληρώθηκε!')
        xbmc.sleep(1000)
        BG.close()
        wait_for_kodi("Ολοκλήρωση Εγκατάστασης Addons")


def var():
    if var_version > int(setting('varversion')):
        
        # 🎯 ΦΡΕΝΟ ΣΤΗΝ ΕΝΑΡΞΗ: Περιμένουμε να καθαρίσει το Kodi από προηγούμενες διαγραφές ή notify
        wait_for_kodi("Προετοιμασία Μεταβλητών (Var Pre-Check)")
        
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        
        # Εκτέλεση των startup scripts του skin
        xbmc.executebuiltin(Var_startup)
        xbmc.sleep(1000)
        xbmc.executebuiltin(XmlSkin_startup)
        xbmc.sleep(1000)
        
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('varversion', str(var_version))
        BG.update(55, Dialog_U12, '[COLOR green]Var...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(75, Dialog_U12, '[COLOR green]Var...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔄 Ανανέωση του Skin ΜΟΝΟ αν δεν εκκρεμεί ενημέρωση στο xmlskin()
        has_xmlskin_update = (not setting('xmlskinversion') == 'false') and (xmlskin_version > int(setting('xmlskinversion')))
        
        if not has_xmlskin_update:
            xbmc.executebuiltin("ReloadSkin()")
            xbmc.sleep(3000)
            wait_for_kodi("Ανανέωση Skin (Var Reload)")
        else:
            xbmc.log("[Master_Build] Παράκαμψη ReloadSkin στο var() επειδή ακολουθεί ενημέρωση στο xmlskin().", xbmc.LOGINFO)


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ PLAYERS (Περιμένει αν γίνει εγκατάσταση/ενημέρωση)
# ----------------------------------------------------------------------
def players():
    if players_version > int(setting('playersversion')):
        BG.create(Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(5, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_Players)
        xbmc.executebuiltin(Players_startup)
        xbmc.sleep(1500)
        BG.update(25, Dialog_U12, Dialog_Players)
        xbmc.sleep(500)
        setting_set('playersversion', str(players_version))
        BG.update(55, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(75, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για την εγκατάσταση των Core Players
        wait_for_kodi("Εγκατάσταση Players")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP1
# ----------------------------------------------------------------------
def zip1():
    if zip1_version > int(setting('zip1version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip1_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('zip1version', str(zip1_version))
        BG.update(55, Dialog_U12, '[COLOR green]Zip1...[/COLOR]')
        xbmc.sleep(500)
        BG.update(75, Dialog_U12, '[COLOR green]Zip1...[/COLOR]')
        xbmc.sleep(500)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για την αποσυμπίεση του Zip1
        wait_for_kodi("Εγκατάσταση Zip1")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP3
# ----------------------------------------------------------------------
def zip3():
    if zip3_version > int(setting('zip3version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Zip3_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        setting_set('zip3version', str(zip3_version))
        BG.update(55, Dialog_U12, 'addon_data')
        xbmc.sleep(1000)
        BG.update(75, Dialog_U12, 'addon_data')
        xbmc.sleep(1000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για τη μεταφορά αρχείων addon_data
        wait_for_kodi("Εγκατάσταση Zip3 (Addon Data)")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP4
# ----------------------------------------------------------------------
def zip4():
    if zip4_version > int(setting('zip4version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip4_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, '[COLOR ornge]Zip 4[/COLOR]')
        xbmc.sleep(500)
        setting_set('zip4version', str(zip4_version))
        BG.update(55, Dialog_U12, '[COLOR ornge]Zip 4[/COLOR]')
        xbmc.sleep(200)
        BG.update(75, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για το Zip4
        wait_for_kodi("Εγκατάσταση Zip4")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP5
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP5 (Αλλάζει την τιμή και περιμένει να τελειώσει το background fix)
# ----------------------------------------------------------------------
def zip5():
    if zip5_version > int(setting('zip5version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        
        # 🚀 Εκκίνηση του background script για τα fixes/updates των addons
        xbmc.executebuiltin(Zip5_startup)
        xbmc.sleep(1000)
        
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        
        # 🎯 ΕΓΓΡΑΦΗ ΤΗΣ ΝΕΑΣ ΕΚΔΟΣΗΣ: Γράφεται κανονικά τώρα
        setting_set('zip5version', str(zip5_version))
        
        BG.update(40, Dialog_U12, '[COLOR green]manually update addons...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(50, Dialog_U12, '[COLOR lime]manually fix addons...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(60, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(500)
        BG.update(70, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        BG.update(80, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΤΟ ΚΛΕΙΔΙ: Περιμένουμε να ολοκληρωθούν όλες οι χειροκίνητες διορθώσεις των addons
        # στο παρασκήνιο, ώστε να προλάβει το Kodi να αποθηκεύσει και τη νέα τιμή στα settings!
        wait_for_kodi("Χειροκίνητες Διορθώσεις Addons (Zip5)")



# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ PVR (Πολύ σημαντικό γιατί πειράζει clients και mac_list)
# ----------------------------------------------------------------------
def pvr():
    if pvr_version > int(setting('pvrversion')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Pvr_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12,'IPTV Simple Client')
        xbmc.sleep(1000)
        BG.update(35, Dialog_U12,'Stalker Client')
        xbmc.sleep(1000)
        BG.update(45, Dialog_U12,'mac_list')
        xbmc.sleep(1000)
        setting_set('pvrversion', str(pvr_version))
        BG.update(50, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        BG.update(60, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(70, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(80, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(90, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για τη ρύθμιση των PVR Clients
        wait_for_kodi("Ρύθμιση PVR")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ SETSETTING
# ----------------------------------------------------------------------
def run_set_setting():
    xbmcgui.Dialog().notification("Ρυθμίσεις", "addon_data", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png', sound=False)

    # Blacklodge
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.blacklodge)'):
        addon_bl = xbmcaddon.Addon('plugin.video.blacklodge')
        addon_bl.setSetting('items.per.page', '60')
        addon_bl.setSetting('movie.download.path', 'special://home/media/Downloads/Blacklodge/')
        addon_bl.setSetting('tv.download.path', 'special://home/media/Downloads/Blacklodge/')
        addon_bl.setSetting('subtitles.lang.1', 'Greek')
        addon_bl.setSetting('subtitles.lang.2', 'English')
        addon_bl.setSetting('remove.keywords', 'Dublado,Dubbed,Dub,Dual,Latino,LATiNO,KORSUB,Hindi,HC,HDCAM,HDTC,HDRip,3D,3d,h264rus,iTA,Ita,iTALiAN,FRENCH,HDTS,HD.TS,CAM,HDCAM')

    # TmdbMovies
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.tmdbmovies)'):
        addon_tmdbmovies = xbmcaddon.Addon('plugin.video.tmdbmovies')
        if not addon_tmdbmovies.getSetting('use_osv3_subs') == 'true':
            addon_tmdbmovies.setSetting('use_osv3_subs', 'true')
        addon_tmdbmovies.setSetting('plot_language', 'el,en')

    # DaddyLive
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.daddylive)'):
        addon_daddylive = xbmcaddon.Addon('plugin.video.daddylive')
        if not addon_daddylive.getSetting('time_format') == '1':
            addon_daddylive.setSetting('time_format', '1')
        if not addon_daddylive.getSetting('mode') == '1':
            addon_daddylive.setSetting('mode', '1')

    # F4mTester
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.f4mTester)'):
        addon_f4mTester = xbmcaddon.Addon('plugin.video.f4mTester')
        if addon_f4mTester.getSetting('ask') == 'false':
            addon_f4mTester.setSetting('ask', 'true')
        if addon_f4mTester.getSetting('player_type') == '1':
            addon_f4mTester.setSetting('player_type', '0')

    # Scrapee
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.scrapee)'):
        addon_scrapee = xbmcaddon.Addon('plugin.video.scrapee')
        if addon_scrapee.getSetting('movie_download_directory') == 'special://profile/addon_data/plugin.video.scrapee/Movies Downloads/':
            addon_scrapee.setSetting('movie_download_directory', 'special://home/media/Downloads/Scrapee')
        if addon_scrapee.getSetting('tvshow_download_directory') == 'special://profile/addon_data/plugin.video.scrapee/TV Show Downloads/':
            addon_scrapee.setSetting('tvshow_download_directory', 'special://home/media/Downloads/Scrapee')
        if addon_scrapee.getSetting('premium_download_directory') == 'special://profile/addon_data/plugin.video.scrapee/Premium Downloads/':
            addon_scrapee.setSetting('premium_download_directory', 'special://home/media/Downloads/Scrapee')
        if addon_scrapee.getSetting('image_download_directory') == 'special://profile/addon_data/plugin.video.scrapee/Image Downloads/':
            addon_scrapee.setSetting('image_download_directory', 'special://home/media/Downloads/Scrapee')

def setsetting():
    if set_setting_version > int(setting('setsettingversion')):
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/set_setting.py')
        
        BG.create(Dialog_U1, Dialog_U3)
        BG.update(30, Dialog_U1, Dialog_U3)
        
        run_set_setting()
        setting_set('setsettingversion', str(set_setting_version))
        
        BG.update(100, Dialog_U1, Dialog_U4)
        xbmc.sleep(1000)
        BG.close()
        wait_for_kodi("Ενημέρωση Ρυθμίσεων (SetSetting)")






def run_database_addons33():
    xbmcgui.Dialog().notification("Database", "Addons33", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)
    
    Database_Addons33 = [
        ('repository.World', 'repository.World'),
        ('repository.Worldolympic', 'repository.World'),
        ('repository.Worldrepo', 'repository.World'),
        ('repository.WorldNexus', 'repository.World'),
        ('repository.WorldOmega', 'repository.World'),

        ('plugin.video.playlistloaderworld', 'repository.World'),
        ('plugin.switchback', 'repository.WorldNexus'),
        ('plugin.video.kodikaraoke', 'repository.WorldNexus'),
        # ('plugin.video.ytlite', 'repository.WorldNexus'),
        # ('script.module.youtube.dl', 'repository.World'),

        ('plugin.program.downloaderstartup', 'repository.Worldolympic'),
        ('skin.19MatrixWorld', 'repository.Worldolympic'),
        ('plugin.program.myselect', 'repository.Worldolympic'),
        ('plugin.program.simple.favourites', 'repository.Worldolympic'),
        ('service.autoexec', 'repository.Worldolympic'),
        ('service.subtitles.All_Subs', 'repository.Worldolympic'),
        ('script.RealDebrid.vpn', 'repository.Worldolympic'),
        # ('plugin.video.duffyou', 'Worldolympic'),
        ('context.subtitles.autosniper', 'repository.Worldolympic'),

        # scrubsv2
        # ('plugin.video.scrubsv2', 'repository.WorldNexus'),
        # ('plugin.video.scrubsv2', 'repository.jewrepo'),
        # ('plugin.video.scrubsv2', 'repository.WorldOmega'),
        # ('plugin.video.scrubsv2', 'repository.redwizard'),
        ('plugin.video.scrubsv2', 'Bee-Queen'),

        ('script.embuary.info', 'repository.Worldolympic'),
        # ('plugin.video.watchnixtoons2', 'repository.Worldolympic'),
        ('plugin.video.macvod', 'repository.Worldolympic'),
        # ('plugin.video.rumble', 'repository.Worldolympic'),
        ('plugin.video.scrapee', 'repository.Worldolympic'),
        ('service.world.build', 'repository.Worldolympic'),

        ('plugin.video.cristalazul', 'repository.World'),
        ('script.kelebek', 'repository.World'),
        ('script.luar', 'repository.World'),
        ('plugin.video.stalker', 'repository.World'),

        ('repository.oliver', 'repository.Worldrepo'),
        # ('script.black.bars.never', 'repository.World'),
        ('script.black.bars.never', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

        ('plugin.video.90phuttv', 'repository.World'),
        ('plugin.video.thethao', 'repository.World'),
        ('plugin.video.vnmedia', 'repository.World'),
        ('plugin.video.thapcam', 'repository.World'),
        ('plugin.video.avdb', 'repository.World'),

        ('plugin.video.iptvxc', 'repository.Worldolympic'),
        ('plugin.audio.dashradio', 'repository.World'),
        ('plugin.audio.mixcloud', 'repository.World'),
        ('plugin.video.dracarys', 'repository.World'),
        ('plugin.audio.radio_de_light', 'repository.World'),
        ('plugin.video.whiskeyblues', 'repository.WorldOmega'),

        # resolveurl
        ('script.module.resolveurl', 'repository.resolveurl'),

        # sportsdevil
        ('plugin.video.sportsdevil', 'repository.World'),
        ('script.module.streamlink', 'repository.World'),
        ('script.module.pycountry', 'repository.World'),
        # ('script.module.isodate', 'repository.gkobu'),
        # ('script.module.pysocks', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('script.module.slproxy', 'repository.World'),
        ('script.module.slproxy', 'repository.gujal'),

        # gkobu
        # ('inputstream.adaptive', 'repository.gkobu'),
        # ('pvr.stalker', 'repository.gkobu'),
        ('script.extendedinfo', 'repository.gkobu'),
        ('script.module.pysubs2', 'repository.gkobu'),
        ('script.module.horus', 'repository.gkobu'),
        ('plugin.video.duffyou', 'repository.gkobu'),
        ('plugin.video.f4mTester', 'repository.gkobu'),
        ('script.video.F4mProxy', 'repository.gkobu'),
        ('plugin.video.live.streamspro', 'repository.gkobu'),
        ('plugin.video.sporthdme', 'repository.gkobu'),
        ('plugin.video.cartoonsgr', 'repository.gkobu'),
        ('plugin.video.fmoviesto', 'repository.gkobu'),
        ('plugin.video.gratis', 'repository.gkobu'),
        ('plugin.video.lookmovietomb', 'repository.gkobu'),
        ('plugin.video.thetvapp', 'repository.gkobu'),
        ('plugin.video.fen', 'repository.gkobu'),
        ('service.subtitles.subsource-net', 'repository.gkobu'),
        ('service.subtitles.subscene', 'repository.gkobu'),
        ('service.subtitles.subdl-com', 'repository.gkobu'),
        # ('service.subtitles.a4ksubtitles', 'repository.gkobu'),
        ('script.module.thetvdb', 'repository.gkobu'),
        ('script.skin.helper.skinbackup', 'repository.gkobu'),
        ('script.module.metadatautils', 'repository.gkobu'),
        ('script.skin.helper.service', 'repository.gkobu'),
        ('script.module.nemzzy', 'repository.gkobu'),
        ('script.module.autocompletion', 'repository.gkobu'),
        ('script.module.microjenscrapers', 'repository.gkobu'),
        # ('script.module.microjenscrapers', 'repository.cMaNWizard'),
        ('script.module.pyairtable', 'repository.gkobu'),
        ('service.subtitles.localsubtitle', 'repository.gkobu'),
        ('script.module.iso639', 'repository.gkobu'),
        # ('plugin.video.seren', 'repository.gkobu'),
        ('context.seren', 'repository.gkobu'),
        ('plugin.video.ert.gr', 'repository.gkobu'),
        # ('plugin.video.alphatv.gr', 'repository.gkobu'),
        # ('plugin.video.antenna.gr', 'repository.gkobu'),
        # ('plugin.video.skai.gr', 'repository.gkobu'),
        # ('plugin.video.star.gr', 'repository.gkobu'),
        # ('plugin.audio.eradio.gr', 'repository.gkobu'),

        # manalab
        ('repository.manalab19', 'repository.manalab19'),
        ('plugin.video.manalab', 'repository.manalab19'),
        ('plugin.video.forecastweather', 'repository.manalab19'),
        ('service.audio.tmdb.sync', 'repository.manalab19'),
        ('plugin.video.dailymotion_com', 'repository.manalab19'),
        # ('plugin.video.dailymotion_com', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('plugin.video.earthtv', 'repository.manalab19'),
        ('plugin.video.antenna.gr', 'repository.manalab19'),
        # ('plugin.video.ert.gr', 'repository.manalab19'),
        ('service.subtitles.a4ksubtitles', 'repository.manalab19'),
        ('script.subterra', 'repository.manalab19'),
        # ('://fashiontv.com', 'repository.manalab19'),
        # ('plugin.audio.eradio.gr', 'repository.manalab19'),
        ('plugin.video.seren', 'repository.manalab19'),

        # bugatsinho
        # ('plugin.video.cartoonsgr', 'repository.bugatsinho'),
        # ('plugin.video.sporthdme', 'repository.bugatsinho'),
        ('script.module.t0mm0.common', 'repository.bugatsinho'),

        # twilight0
        ('repository.twilight0', 'repository.twilight0'),
        ('plugin.video.alivegr', 'repository.twilight0'),
        ('script.module.tulip', 'repository.twilight0'),
        ('plugin.video.alphatv.gr', 'repository.twilight0'),
        ('plugin.video.antenna.gr', 'repository.twilight0'),
        # ('plugin.video.ert.gr', 'repository.twilight0'),
        ('://fashiontv.com', 'repository.twilight0'),
        ('plugin.video.skai.gr', 'repository.twilight0'),
        ('plugin.video.star.gr', 'repository.twilight0'),
        ('plugin.audio.eradio.gr', 'repository.twilight0'),
        ('://megatv.com', 'repository.twilight0'),

        # HermesGR
        ('repository.seriesly', 'repository.seriesly'),
        ('plugin.video.seriesly', 'repository.seriesly'),

        # thecrew
        ('repository.thecrew', 'repository.thecrew'),
        ('plugin.video.thecrew', 'repository.thecrew'),
        ('script.module.thecrew', 'repository.thecrew'),
        ('script.thecrew.artwork', 'repository.thecrew'),
        # ('repository.thecrew.alpha', 'repository.thecrew.alpha'),
        # ('plugin.video.thecrew', 'repository.thecrew.alpha'),
        # ('script.module.thecrew', 'repository.thecrew.alpha'),
        # ('script.thecrew.artwork', 'repository.thecrew.alpha'),

        # autowidget
        ('plugin.program.autowidget', 'repository.autowidget'),
        ('repository.autowidget', 'repository.autowidget'),

        # zeltorix
        ('repository.zeltorix', 'repository.zeltorix'),
        ('plugin.video.zeltorix.worldcams.tv', 'repository.zeltorix'),
        ('script.module.zeltorix.packages', 'repository.zeltorix'),
        ('script.module.zeltorix.utilitys', 'repository.zeltorix'),
        # ('script.module.zeltorix.utilitys', 'repository.World'),

        # jurialmunkey
        # ('script.module.infotagger', 'repository.newdiamond'),
        ('script.module.infotagger', 'repository.jurialmunkey'),
        ('plugin.video.themoviedb.helper', 'repository.jurialmunkey'),
        # ('plugin.video.themoviedb.helper', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.jurialmunkey', 'repository.jurialmunkey'),
        ('script.skinvariables', 'repository.jurialmunkey'),
        # ('plugin.video.themoviedb.helper', 'repository.gkobu'),

        ('script.speedtester', 'repository.redwizard'),

        # inputstreamhelper
        ('script.module.inputstreamhelper', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('script.module.inputstreamhelper', 'repository.aliunde'),
        # ('script.module.inputstreamhelper', 'repository.slyguy.inputstreamhelper'),
        # ('repository.slyguy.inputstreamhelper', 'repository.slyguy'),

        # youtube
        # ('plugin.video.youtube', 'repository.redwizard'),
        # ('plugin.video.youtube', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('plugin.video.youtube', 'repository.xbmc.org'),
        # ('plugin.video.youtube', 'repository.cMaNWizard'),
        # ('plugin.video.youtube', 'repository.gkobu'),

        # xbmc.org
        ('inputstream.adaptive', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('inputstream.ffmpegdirect', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('inputstream.rtmp', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('vfs.libarchive', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('vfs.rar.inputstreamhelper', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('vfs.sftp', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('script.module.infotagger', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('pvr.stalker', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.xbmcswift2', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('peripheral.joystick', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.requests', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.pyqrcode', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('pvr.stalker', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.simplejson', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.dateutil', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('plugin.audio.radio_de', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('weather.gismeteo', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.myconnpy', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.clouddrive.common', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('metadata.themoviedb.org.python', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.htmlement', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.pysocks', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.idna', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.beautifulsoup4', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.certifi', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.chardet', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('script.module.codequick', 'repository.WorldNexus'),
        ('script.module.codequick', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.pyparsing', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.six', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.soupsieve', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.urllib3', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.websocket', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.requests-toolbelt', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.unidecode', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('script.speedtester', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.youtube.dl', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.module.bottle', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        ('script.radioparadise', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),
        # ('script.radioparadise', 'repository.xbmc.org'),
        ('resource.images.studios.white', 'b6a50484-93a0-4afb-a01c-8d17e059feda'),

        ('repository.giaitri', 'repository.giaitri'),
        ('plugin.video.xembongda', 'repository.giaitri'),

        # kentestvn NEW
        ('kentestvn', 'kentestvn'),
        # ('script.module.requests', 'kentestvn'),
        # ('script.module.urllib3', 'kentestvn'),
        # ('script.module.six', 'kentestvn'),
        # ('script.module.pysocks', 'kentestvn'),
        # ('script.module.chardet', 'kentestvn'),
        # ('script.module.certifi', 'kentestvn'),
        # ('script.module.bottle', 'kentestvn'),

        # vnmedia off
        # ('plugin.video.vnmedia', 'repovnmedia'),
        ('repovnmedia', 'repovnmedia'),

        # kentestvn off
        # ('plugin.video.90phuttv', 'kodivietnam'),
        ('kodivietnam', 'kodivietnam'),

        # arrownegra - repository.dregs
        # ('repository.arrownegra', 'repository.arrownegra'),
        # ('repository.dregs', 'repository.dregs'),
        ('plugin.video.aguia_de_ouro', 'repository.dregs'),
        ('plugin.video.fenix-mac', 'repository.dregs'),
        ('repository.arrownegra', 'repository.Worldrepo'),
        ('repository.dregs', 'repository.Worldrepo'),

        # RD account // 709
        ('repository.709', 'repository.709'),
        # ('script.module.accountmgr', 'repository.709'),
        ('script.module.acctview', 'repository.709'),
        ('script.module.debridmgr', 'repository.709'),
        ('script.module.dbview', 'repository.709'),

        # daddylive
        # ('plugin.video.daddylive', 'repository.Worldolympic'),
        ('plugin.video.daddylive', 'repository.thecrew'),
        # ('plugin.video.daddylive', 'repository.aliunde'),
        # ('plugin.video.daddylive', 'repository.dexe'),
        # ('plugin.video.daddylive', 'repository.gwen84'),

        # Netflix
        ('repository.castagnait', 'repository.castagnait'),
        ('plugin.video.netflix', 'repository.castagnait'),

        # funstersplace
        ('plugin.video.gratis', 'repository.gkobu'),
        ('repository.funstersplace', 'repository.funstersplace'),

        # dexe
        ('repository.roooar', 'repository.roooar'),
        # ('repository.dexe', 'repository.roooar'),
        ('plugin.video.BauBauVavoo', 'repository.dexe'),
        ('plugin.video.GreenKlikPremium', 'repository.dexe'),
        # ('plugin.video.fen', 'repository.dexe'),
        # ('repository.dexe', 'Worldrepo'),
        ('repository.dexe', 'repository.dexe'),
        # ('plugin.video.free99', 'repository.dexe'),
        ('script.free99.artwork', 'repository.dexe'),
        # ('plugin.video.playlistbee', 'repository.dexe'),

        # diggz
        ('repository.diggz', 'repository.diggz'),
        # ('plugin.video.free99', 'repository.diggz'),
        # ('script.free99.artwork', 'repository.diggz'),

        # cMaNWizard / Mad For It Repo
        ('repository.cMaNWizard', 'repository.cMaNWizard'),
        ('plugin.video.quicksilver', 'repository.cMaNWizard'),
        ('script.module.quicksilverscrapers', 'repository.cMaNWizard'),
        ('script.quicksilver.artwork', 'repository.cMaNWizard'),
        ('plugin.video.halcyon', 'repository.madforit'),
        ('plugin.video.neo_flix', 'repository.madforit'),
        ('plugin.video.tvfree', 'repository.cMaNWizardt'),

        # homelander
        ('repository.chainsrepo', 'repository.chainsrepo'),
        ('plugin.video.homelander', 'repository.chainsrepo'),
        ('script.module.homelanderscrapers', 'repository.chainsrepo'),
        ('script.homelander.artwork', 'repository.chainsrepo'),

        # gigoro33-addon
        ('repository.gigoro33-addon', 'repository.World'),
        ('plugin.video.latinsports', 'repository.gigoro33-addon'),

        # repository.mrfixit2001
        ('repository.mrfixit2001', 'repository.mrfixit2001'),
        # ('plugin.video.kodikaraoke', 'repository.mrfixit2001'),
        ('plugin.video.ytlite', 'repository.mrfixit2001'),

        # gearheads2
        ('repository.gearheads2', 'repository.Worldrepo'),
        # ('repository.gearheads2', 'repository.gearheads2'),
        ('plugin.video.torquelite', 'repository.gearheads2'),
        # ('plugin.video.torquelive', 'repository.thelab'),

        # REST
        ('script.module.jetextractors', 'repository.loop'),
        ('plugin.video.fen', 'repository.redwizard'),
        ('repository.KODIvertiDO_TEAM', 'repository.KODIvertiDO_TEAM'),
        # ('plugin.video.KODIvertiDO', 'repository.KODIvertiDO_TEAM'),
        ('plugin.video.KODIvertiDO', 'repository.World'),
        ('plugin.video.vavooto', 'repository.michaz'),
        # ('plugin.video.vavooto', 'Bee-Queen'),
        ('repository.jellyfin.kodi', 'repository.jellyfin.kodi'),
        ('plugin.video.thethunder', 'One.repo'),
        ('repository.alado.tv', 'repository.Worldrepo'),
        # ('repository.alado.tv', 'repository.alado.tv'),
        ('plugin.video.train.mac.again', 'repository.alado.tv'),
        ('repository.cocoscrapers', 'repository.cocoscrapers'),
        ('script.module.cocoscrapers', 'repository.cocoscrapers'),
        ('repository.lekma', 'repository.lekma'),
        # ('plugin.video.invidious', 'repository.lekma'),
        ('repository.rays.files', 'repository.rays.files'),
        ('plugin.video.everstream', 'repository.rays.files'),
        ('repository.Parrot', 'repository.Parrot'),
        ('repository.subskip', 'repository.subskip'),
        ('repository.kodifitzwell', 'repository.kodifitzwell'),
        ('repository.azzyaddons', 'repository.azzyaddons'),
        ('plugin.video.rumble', 'repository.azzyaddons'),
        ('repository.animaniac', 'repository.animaniac'),
        ('plugin.video.watchnixtoons2', 'repository.animaniac'),
        ('repository.LostSoul', 'repository.LostSoul'),
        ('repository.redwizard', 'repository.redwizard'),
        ('repository.NarcacistWizard', 'repository.Worldrepo'),
        ('repository.lattsrepo', 'repository.lattsrepo'),
        # ('resource.images.studios.white', 'repository.lattsrepo'),
        # ('plugin.video.jetproxy', 'repository.loop'),
        ('plugin.video.jetproxy', 'repository.Magnetic'),
        ('MatrixFlix.Repo', 'MatrixFlix.Repo'),
        ('plugin.video.matrixflix', 'MatrixFlix.Repo'),
        ('repository.madforit', 'repository.madforit'),
        ('repository.twistednutz', 'repository.twistednutz'),
        # ('plugin.audio.radio_de_light', 'repository.kodinerds'),
        ('plugin.video.playlistloader', 'repository.kodinerds'),
        # ('script.module.youtube.dl', 'repository.kodinerds'),
        ('plugin.video.earthtv', 'repository.kodinerds'),
        ('plugin.video.vavooto', 'repository.michaz'),
        ('repository.github', 'repository.github'),
        ('plugin.video.torrest', 'repository.github'),
        # ('script.module.futures', 'repository.github'),
        # ('script.module.futures', 'repository.sarsaila'),
        ('script.module.futures', 'repository.twilight0'),
        ('repository.BrazucaPlay', 'repository.BrazucaPlay'),
        ('plugin.video.BrazucaPlay.Matrix', 'repository.BrazucaPlay'),
        ('repository.fubuz', 'repository.fubuz'),
        ('plugin.video.daddylivehd', 'repository.fubuz'),
        ('repository.thelab', 'repository.thelab'),
        ('plugin.video.dream1click', 'repository.thelab'),
        ('plugin.video.dreamtv', 'repository.thelab'),
        ('repository.diamondrepo', 'repository.diamondrepo'),
        ('repository.rdplayer', 'repository.Worldrepo'),
        # ('repository.rdplayer', 'repository.rdplayer'),
        ('plugin.program.rdtplayer', 'repository.rdplayer'),
        ('repository.EzzerMacsWizard', 'repository.EzzerMacsWizard'),
        ('repository.zero', 'repository.zero'),
        ('plugin.video.f1rewind', 'repository.zero'),
        ('plugin.video.fod', 'repository.zero'),
        ('plugin.video.wrestlingrewind', 'repository.zero'),
        ('plugin.video.z3r0cinema', 'repository.zero'),
        ('plugin.video.acestream_channels', 'repository.acestream-channels'),
        ('repository.acestream-channels', 'repository.acestream-channels'),

        # repository.arkane14 DLTV
        ('repository.arkane14', 'repository.arkane14'),
        ('plugin.video.dltv', 'repository.arkane14'),
        # ('plugin.video.dltv', 'repository.Bee-Queen'),

        # RO
        ('repository.derzis', 'repository.derzis'),
        ('plugin.video.filmzie', 'repository.derzis'),
        ('plugin.video.rdslive', 'repository.derzis'),
        ('plugin.video.pandamoviespw', 'repository.derzis'),
        ('plugin.video.sport', 'repository.derzis'),
        # ('plugin.video.sport', 'repository.Bee-Queen'),
        ('repository.hub', 'repository.hub'),
        # ('plugin.video.vixmovie', 'repository.hub'),
        # ('plugin.video.vixmovie', 'repository.angelitto'),
        ('plugin.video.vixmovie', 'Bee-Queen'),
        ('plugin.video.hub', 'repository.hub'),
        # ('plugin.video.hub', 'repository.angelitto'),
        ('plugin.video.tmdbmovies', 'repository.angelitto'),
        ('plugin.video.hublive', 'repository.hub'),
        # ('plugin.video.hublive', 'Bee-Queen'),
        ('plugin.video.free99', 'Bee-Queen'),
        ('plugin.video.hubstream', 'repository.hub'),
        ('repository.luc_repo', 'repository.Worldrepo'),
        ('plugin.video.luc_kodi', 'repository.luc_repo'),
        ('repository.derzis', 'repository.derzis'),
        ('repository.angelitto', 'repository.angelitto'),
        ('plugin.video.romanianpack', 'repository.angelitto'),
        ('Bee-Queen', 'Bee-Queen'),
        ('plugin.video.playlistbee', 'Bee-Queen'),
        ('plugin.video.romyTVlist', 'Bee-Queen'),
        ('plugin.video.rotv123', 'Bee-Queen'),

        ('repository.cbtv', 'repository.cbtv'),
        ('plugin.video.cbtv', 'repository.cbtv'),
        ('repository.zeus768', 'repository.zeus768'),
        ('repository.kodi.media', 'repository.kodi.media'),
        # ('repository.oldsalt', 'repository.oldsalt'),
        ('repository.oldsalt', 'repository.Worldrepo'),
        # repository.arkane14 DLTV
        ('repository.arkane14', 'repository.arkane14'),
        ('plugin.video.dltv', 'repository.arkane14'),
        # ('plugin.video.dltv', 'repository.Bee-Queen'),

        # RO
        ('repository.derzis', 'repository.derzis'),
        ('plugin.video.filmzie', 'repository.derzis'),
        ('plugin.video.rdslive', 'repository.derzis'),
        ('plugin.video.pandamoviespw', 'repository.derzis'),
        ('plugin.video.sport', 'repository.derzis'),
        # ('plugin.video.sport', 'repository.Bee-Queen'),
        ('repository.hub', 'repository.hub'),
        # ('plugin.video.vixmovie', 'repository.hub'),
        # ('plugin.video.vixmovie', 'repository.angelitto'),
        ('plugin.video.vixmovie', 'Bee-Queen'),
        ('plugin.video.hub', 'repository.hub'),
        # ('plugin.video.hub', 'repository.angelitto'),
        ('plugin.video.tmdbmovies', 'repository.angelitto'),
        ('plugin.video.hublive', 'repository.hub'),
        # ('plugin.video.hublive', 'Bee-Queen'),
        ('plugin.video.free99', 'Bee-Queen'),
        ('plugin.video.hubstream', 'repository.hub'),
        ('repository.luc_repo', 'repository.Worldrepo'),
        ('plugin.video.luc_kodi', 'repository.luc_repo'),
        ('repository.derzis', 'repository.derzis'),
        ('repository.angelitto', 'repository.angelitto'),
        ('plugin.video.romanianpack', 'repository.angelitto'),
        ('Bee-Queen', 'Bee-Queen'),
        ('plugin.video.playlistbee', 'Bee-Queen'),
        ('plugin.video.romyTVlist', 'Bee-Queen'),
        ('plugin.video.rotv123', 'Bee-Queen'),

        ('repository.cbtv', 'repository.cbtv'),
        ('plugin.video.cbtv', 'repository.cbtv'),
        ('repository.zeus768', 'repository.zeus768'),
        ('repository.kodi.media', 'repository.kodi.media'),
        # ('repository.oldsalt', 'repository.oldsalt'),
        ('repository.oldsalt', 'repository.Worldrepo'),
        ('repository.adulthideout', 'repository.adulthideout'),
        ('plugin.video.adulthideout', 'repository.adulthideout'),
        ('repository.enigmawiz', 'repository.enigmawiz'),
        ('repository.opencode', 'repository.opencode'),
        ('repository.greekporn', 'repository.greekporn'),
        ('repository.remod', 'repository.remod'),
        ('repository.wetdreams69', 'repository.wetdreams69'),
        ('repository.fivebanger', 'repository.fivebanger'),
        ('repository.zombi', 'repository.zombi'),
        ('repository.sportsurge', 'repository.sportsurge'),
        ('repository.thetallone', 'repository.thetallone'),
        ('repository.kodimate', 'repository.kodimate'),
        ('plugin.video.vstream', 'repository.vstream')
    ]

    xbmc.executebuiltin('Skin.SetString(DatabaseRunning,true)')

    # Εγγραφή στον πίνακα origins μέσω του db module
    db.addon_database(Database_Addons33, 1, True)

    # Καθαρισμός και συμπίεση της Addons33.db
    import sqlite3
    addons_db_path = os.path.join(xbmcvfs.translatePath('special://database'), 'Addons33.db')
    try:
        con = sqlite3.connect(addons_db_path)
        cursor = con.cursor()
        cursor.execute('DELETE FROM package;')
        cursor.execute('DELETE FROM update_rules;')
        con.commit()
        cursor.execute('VACUUM;')
        con.commit()
        con.close()
    except Exception as e:
        xbmc.log(f'[Master_Build] Database SQL error: {str(e)}', xbmc.LOGERROR)

    xbmc.sleep(1000)
    xbmcgui.Dialog().notification("Database", "[COLOR cornflowerblue]Addons33[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/database.webp', sound=False)
    xbmc.sleep(1000)
    xbmc.executebuiltin('Skin.ResetString(DatabaseRunning)')













def database():
    if addons_repos_version > int(setting('addonsreposversion')):
        wait_for_kodi("Προετοιμασία Βάσης Δεδομένων (Database Pre-Check)")
        
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/Database_Addons33.py')
        xbmc.sleep(1000)
        
        BG.create(Dialog_U8, Dialog_Database)
        xbmc.sleep(1000)
        BG.update(33, Dialog_U8, Dialog_Database)
        
        # Εκτέλεση της αυτόνομης συνάρτησης (αντί για εξωτερικό αρχείο)
        run_database_addons33()
        
        BG.update(76, Dialog_U12, Dialog_Database)
        xbmc.sleep(1000)
        
        # Ενεργοποίηση των Repositories
        addonsEnable.enable_addons()
        
        BG.update(85, Dialog_U12, '[COLOR lime]enable_addons...[/COLOR]')
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        setting_set('addonsreposversion', str(addons_repos_version))
        xbmc.sleep(1000)
        BG.update(100, Dialog_U1, '[B][COLOR red]Περιμένετε χωρίς να πατήσετε κάτι...[/COLOR][/B]')
        xbmc.sleep(1500)
        BG.update(95, Dialog_U9, Dialog_U2)
        xbmc.sleep(1000)
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False) 
        xbmc.sleep(1000)
        BG.close()
        
        xbmc.log("[Master_Build] [ΚΑΘΑΡΟ ΠΕΔΙΟ] Η βάση δεδομένων ολοκληρώθηκε πλήρως!", xbmc.LOGINFO)
        xbmc.sleep(1000)



def xmlskin():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            # 🔒 ΚΛΕΙΔΩΜΑ: Απαγορεύουμε στο Kodi να κατεβάσει ενημερώσεις όσο αλλάζει το skin!
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":1},"id":1}')

            
            target_xml = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
            
            # 1. Μετάβαση στο skin.estuary ΠΡΩΤΑ, ώστε να ελευθερωθεί το settings.xml από τη RAM του Kodi
            xbmc.log("[Master_Build] 1η Αλλαγή: Μετάβαση στο skin.estuary...", xbmc.LOGINFO)
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.estuary"},"id":1}')
            
            confirm_estuary = 0
            while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and confirm_estuary < 50:
                xbmc.sleep(100)
                confirm_estuary += 1
                
            if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
                xbmc.sleep(1000)
                xbmc.log("[Master_Build] Επιβεβαίωση Estuary...", xbmc.LOGINFO)
                xbmc.executebuiltin('SendClick(yesnodialog, 11)')
                xbmc.executebuiltin('Action(Select)')

            # ⏳ Περιμένουμε μέχρι το Kodi να επιβεβαιώσει ότι ενεργοποιήθηκε όντως το Estuary
            skin_wait = 0
            while xbmc.getSkinDir() != 'skin.estuary' and skin_wait < 40:
                xbmc.sleep(200)
                skin_wait += 1
            
            # Δίνουμε 2.5 δευτερόλεπτα στο Android Box να ολοκληρώσει το flush των παλιών ρυθμίσεων
            xbmc.sleep(2500)

            # 2. ΤΩΡΑ που είμαστε καθαρά στο Estuary, σβήνουμε το παλιό settings.xml!
            if os.path.exists(target_xml):
                try:
                    os.remove(target_xml)
                    xbmc.log("[Master_Build] Το παλιό settings.xml διαγράφηκε επιτυχώς μέσα από το Estuary.", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Master_Build] Αποτυχία διαγραφής settings.xml: {str(e)}", xbmc.LOGWARNING)
            
            xbmc.sleep(500)

            # 3. Μπάρα προόδου και λήψη του νέου Zip
            BG.create(Dialog_U12, Dialog_Xml_Skin)
            BG.update(10, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(500)
            
            xbmc.executebuiltin(XmlSkin_startup)
            
            # Περιμένουμε όσο κατεβαίνει το zip
            while xbmc.getCondVisibility('Window.IsActive(progressdialog)') or xbmc.getCondVisibility('Window.IsVisible(progressdialog)'):
                xbmc.sleep(1000)
                
            # 4. Έλεγχος ότι το νέο settings.xml γράφτηκε ΟΛΟΚΛΗΡΟ (μέγεθος > 500 bytes, όχι 0 bytes)
            write_timeout = 0
            while write_timeout < 25:
                if os.path.exists(target_xml):
                    try:
                        if os.path.getsize(target_xml) > 500:
                            break
                    except:
                        pass
                xbmc.log("[Master_Build] Αναμονή πλήρους εγγραφής του νέου settings.xml...", xbmc.LOGINFO)
                xbmc.sleep(1000)
                write_timeout += 1
                
            # Γενναίο sleep 3.5 δευτερολέπτων για τη NAND/eMMC μνήμη του Android TV Box
            xbmc.sleep(3500)
            
            BG.update(60, Dialog_U12, Dialog_Xml_Skin)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.update(85, Dialog_U12, Dialog_U9)
            xbmc.sleep(1000)

            BG.update(95, Dialog_U4, 'Εφαρμογή αλλαγών και επιστροφή...')
            xbmc.sleep(1000)
            
            # 5. Επιστροφή στο skin.19MatrixWorld (θα διαβάσει πλέον το φρέσκο settings.xml από τον δίσκο)
            xbmc.log("[Master_Build] 2η Αλλαγή: Επιστροφή στο skin.19MatrixWorld...", xbmc.LOGINFO)
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.19MatrixWorld"},"id":1}')
            
            confirm_matrix = 0
            while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and confirm_matrix < 60:
                xbmc.sleep(100)
                confirm_matrix += 1

            if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
                xbmc.sleep(1200)
                xbmc.log("[Master_Build] Επιβεβαίωση MatrixWorld...", xbmc.LOGINFO)
                xbmc.executebuiltin('SendClick(yesnodialog, 10)')
                xbmc.executebuiltin('SendClick(yesnodialog, 11)')
                xbmc.executebuiltin('Action(Select)')
                
                xbmc.sleep(1000)
                # 🚀 ΑΚΑΡΙΑΙΟ ΚΛΕΙΔΩΜΑ WIDGETS ΠΡΙΝ ΠΡΟΛΑΒΟΥΝ ΝΑ ΖΩΓΡΑΦΙΣΤΟΥΝ
                try:
                    b_widgets = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/widgets_backup.json')
                    if os.path.exists(b_widgets):
                        os.remove(b_widgets)
                    import World_widget_OnOff as w_mgr
                    w_mgr.backup_and_disable_widgets(keep_weather=True, do_reload=True)
                    xbmc.log("[Master_Build] Τα Widgets ξανακλείδωσαν ακαριαία στην επιστροφή από Estuary.", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Master_Build] Σφάλμα στο κλείδωμα widgets μετά το xmlskin: {str(e)}", xbmc.LOGERROR)
            
            BG.update(100, Dialog_U4, 'Ολοκληρώθηκε!')
            xbmc.sleep(1000)
            BG.close()

            


# def xmlskin():  Exit
    # if not setting('xmlskinversion') == 'false':
        # if xmlskin_version > int(setting('xmlskinversion')):
            # xbmcvfs.delete('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
            # xbmc.sleep(500)
            # 🎯 Σωστό άνοιγμα του Progress Bar με τις δικές σου μεταβλητές
            # BG.create(Dialog_U12, Dialog_Xml_Skin)
            # BG.update(5, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(500)
            # BG.update(15, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(100)
            
            # 🚀 Εκκίνηση της λήψης του νέου βελτιστοποιημένου Zip
            # xbmc.log("[Master_Build] Έναρξη λήψης βελτιστοποιημένου XML Skin...", xbmc.LOGINFO)
            # xbmc.executebuiltin(XmlSkin_startup)
            
            # ⏳ ΤΟ ΕΞΥΠΝΟ ΧΡΟΝΟΜΕΤΡΗΜΕΝΟ ΦΡΕΝΟ (12 ΔΕΥΤΕΡΟΛΕΠΤΑ)
            # Κρατάμε σταθερά τις δικές σου μεταβλητές (Dialog_U12, Dialog_Xml_Skin) για να μην μπερδεύεται η οθόνη
            # for i in range(25, 81, 6):
                # BG.update(i, Dialog_U12, Dialog_Xml_Skin)
                # xbmc.sleep(1200) # 10 βήματα x 1.2 δευτερόλεπτα = 12 δευτερόλεπτα συνολική αναμονή
            
            # xbmc.log("[Master_Build] [OK] Ο χρόνος αναμονής ολοκληρώθηκε.", xbmc.LOGINFO)
            
            # 🎯 Κλείδωμα της έκδοσης στα settings
            # setting_set('xmlskinversion', str(xmlskin_version))
            # BG.update(100, Dialog_U12, 'Η μεταφορά μενού ολοκληρώθηκε.')
            # xbmc.sleep(5000)
            # BG.close()
            
            # xbmc.sleep(500)
            # user_choice = xbmcgui.Dialog().yesno(
                # '[B][COLOR cornflowerblue]Skin World[/COLOR][/B]', 
                # 'Οι αλλαγές στο [COLOR orange]HOME MENU[/COLOR] θα εμφανιστούν στην επόμενη εκκίνηση του build.[CR]Θέλετε να κλείσετε το Kodi τώρα;'
            # )
            
            # if user_choice:
                # xbmc.log("[Master_Build] Ο χρήστης επέλεξε άμεσο κλείσιμο. Ακαριαίο os._exit...", xbmc.LOGINFO)
                # os._exit(1)
                # return False 
            # else:
                # xbmc.log("[Master_Build] Ο χρήστης πάτησε ΟΧΙ. Επιστροφή True για συνέχεια ροής.", xbmc.LOGINFO)
                # xbmcgui.Dialog().notification('[B][COLOR orange]Skin World[/COLOR][/B]', 'Οι αλλαγές θα εφαρμοστούν στο επόμενο boot!', icon_Build, sound=False)
                # xbmc.sleep(2000)
                # return True # 👈 Πράσινο φως για να τρέξει το UpdateAddonRepos()
                
    # return True # Αν δεν υπήρχε update, επιστρέφει True για να γίνουν κανονικά τα υπόλοιπα updates προσθέτων





# def xmlskin(): LoadProfile
    # if not setting('xmlskinversion') == 'false':
        # if xmlskin_version > int(setting('xmlskinversion')):
            # BG.create(Dialog_U12, Dialog_Xml_Skin)
            # BG.update(5, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(200)
            # BG.update(15, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(200)
            # xbmc.executebuiltin(XmlSkin_startup)
            # xbmc.sleep(1000)
            # BG.update(25, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(500)
            # setting_set('xmlskinversion', str(xmlskin_version))
            # BG.update(55, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(200)
            # BG.update(75, Dialog_U12, Dialog_Xml_Skin)
            # xbmc.sleep(200)
            # BG.update(80, Dialog_U12, Dialog_U9)
            # xbmc.sleep(1000)

            # BG.update(90, Dialog_U1, 'Ενημέρωση μενού skin.')
            # xbmc.sleep(5000)
            # BG.update(95, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
            # xbmc.sleep(3000)
            # BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
            # dialog.notification('[B][COLOR orange]Reload Profile[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_reloadprofile, sound=False)
            # xbmc.sleep(4000)
            # xbmc.executebuiltin("LoadProfile(Master user)")
            # BG.close()




#TEST
def xmlskinTest():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            BG.create(Dialog_U12, Dialog_Xml_Skin)
            BG.update(5, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(15, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            xbmc.executebuiltin(XmlSkin_startup)
            xbmc.sleep(1000)
            BG.update(25, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(500)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.update(55, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(1000)
            BG.update(75, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(2000)
            BG.update(80, Dialog_U12, Dialog_U9)
            xbmc.sleep(3000)
            BG.update(90, Dialog_U1, '   ')
            xbmc.sleep(4000)
            BG.update(95, 'Ενημέρωση μενού skin' '   ')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, '   ')
            # dialog.notification('[B][COLOR orange]Reload Profile[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_reloadprofile, sound=False)
            xbmc.sleep(5000)
            # xbmc.executebuiltin("LoadProfile(Master user)")
            BG.close()
            xbmc.executebuiltin("ReloadSkin()")
            # xbmcgui.Dialog().ok('Skin World', 'Για να εφαρμοστούν οι αλλαγές, το Kodi πρέπει να κλείσει.')
            # xbmc.sleep(15000)
            # os._exit(1)
            


def xmlskin3():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            BG.create('Skin World', 'Αντιγραφή.')
            xbmc.sleep(500)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.close()
            xbmcgui.Dialog().ok('Skin World', 'Για να εφαρμοστούν οι αλλαγές, το Kodi πρέπει να κλείσει.')
            os._exit(1)



def Backup_Skin_Set():
    src_settings = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
    dst_settings = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/settings.xml')
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    # setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='2046':
        xbmc.sleep(500)
        # setting_set_downloader19('xmlskinversion', '2046')
        shutil.copyfile(src_settings, dst_settings)


def Backup_Home_Set():
    src_homeset = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/Home.xml')
    dst_homeset = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/Home.xml')
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    # setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='2046':
        xbmc.sleep(500)
        # setting_set_downloader19('xmlskinversion', '2046')
        shutil.copyfile(src_homeset, dst_homeset)




# ----------------------------------------------------------------------
# 🎯 ΕΝΙΑΙΟ DEF: ΟΛΟΙ ΟΙ ΚΑΘΑΡΙΣΜΟΙ ΚΑΙ ΤΑ FIXES ΣΕ ΣΕΙΡΑ (ΜΕ ΧΕΙΡΟΦΡΕΝΟ)
# ----------------------------------------------------------------------
def run_pre_update_fixes():
    xbmc.log("[Master_Build] Έναρξη run_pre_update_fixes...", xbmc.LOGINFO)

    # === [ΜΕΡΟΣ Α: ΟΙ ΚΑΘΑΡΙΣΜΟΙ (Πρώην clean_house)] ===
    try:
        # Διαγραφή cache του MyIPTV
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')
        
        # Αφαίρεση service του vnmedia αν υπάρχει
        vn_service = xbmcvfs.translatePath('special://home/addons/plugin.video.vnmedia/service.py')
        if os.path.exists(vn_service):
            try: os.remove(vn_service)
            except: pass

        # Καθαρισμός Artist Slideshow που βαραίνει τη RAM
        base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')
        for folder_name in ["ArtistInformation", "ArtistSlideshow"]:
            target_path = os.path.join(base_path, folder_name)
            if os.path.exists(target_path) and os.path.isdir(target_path):
                try: shutil.rmtree(target_path)
                except: pass
                
        xbmc.log("[Master_Build] Οι αρχικοί καθαρισμοί ολοκληρώθηκαν επιτυχώς.", xbmc.LOGINFO)
        xbmc.sleep(500)
    except Exception as e:
        xbmc.log(f"[Master_Build] Σφάλμα στους αρχικούς καθαρισμούς: {str(e)}", xbmc.LOGERROR)


    # === [ΜΕΡΟΣ Β: ΤΑ FIXES ΣΟΥ (100% ΑΠΑΡΑΛΛΑΚΤΑ ΜΕ ΤΙΣ ΔΙΕΣΕΙΣ ΤΟΥΣ)] ===

    """ fix1. Απενεργοποίηση του Πρόσθετου --->   The Loop    """
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix1.py")')
    # except: pass
    # xbmc.sleep(500)

    """ fix2. Απενεργοποίηση service --->   plugin.video.the-loop: "8.3"  &  plugin.video.madtitansports: "2.0.45"     """
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix2.py")')
    # except: pass
    # xbmc.sleep(500)

    """ fix2_on. Ενεργοποίηση service --->   plugin.video.the-loop:   &  plugin.video.madtitansports:     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix2_on.py")')
    except: pass
    xbmc.sleep(500)

    """ fix3. Διαγραφή του Πρόσθετου --->   plugin.video.whiskeyblues     """ 
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix3.py")')
    # except: pass
    # xbmc.sleep(2000)

    """ fix4. Διαγραφή του Πρόσθετου --->   plugin.video.AliveGR  έκδοση "2.99.99" (και κάτω)     """
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix4.py")')
    # except: pass
    # xbmc.sleep(2000)

    """ fix5. Διαγραφή settings του Πρόσθετου --->   plugin.video.themoviedb.helper  ( <setting id="language">12</setting> )     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix5.py")')
    except: pass
    xbmc.sleep(500)

    """ fix6. Διαγραφή settings του Πρόσθετου --->   plugin.video.atlas     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix6.py")')
    except: pass
    xbmc.sleep(500)

    """ fix7. Διαγραφή/Ρυθμίσεις settings του Πρόσθετου --->   weather.gismeteo     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix7.py")')
    except: pass
    xbmc.sleep(500)


    xbmc.log("[Master_Build] [OK] Και τα Pre-Update Fixes ολοκληρώθηκαν!", xbmc.LOGINFO)

    # 🛑 ΤΟ ΑΠΑΡΑΒΑΤΟ ΧΕΙΡΟΦΡΕΝΟ:
    # Παγώνει το thread και περιμένει να κάτσουν όλες οι αλλαγές των settings, 
    # οι διαγραφές και τα background tasks, ΠΡΙΝ προχωρήσει η ροή στα επόμενα βήματα!
    wait_for_kodi("Αρχικοί Καθαρισμοί & Ρυθμίσεις Fixes")





# ----------------------------------------------------------------------
# ⚙️ Η ΚΕΝΤΡΙΚΗ ΣΥΝΑΡΤΗΣΗ ΕΝΗΜΕΡΩΣΕΩΝ (ΑΚΡΙΒΩΣ ΑΠΟ ΚΑΤΩ)
# ----------------------------------------------------------------------
def UpdateAddonRepos():
    xbmc.sleep(200)
    
    # 🛡️ 1. 🎯 ΔΙΚΛΕΙΔΑ ΑΣΦΑΛΕΙΑΣ: Εκτελείται ο καθαρισμός και τα fixes από το check.py 
    # πρώτη-πρώτη, και το thread παγώνει εκεί με το wait_for_kodi μέχρι να ολοκληρωθούν όλα!
    run_pre_update_fixes()


    # ⚙️ 2. Μόλις λυθεί το χειρόφρενο, γυρνάει ο διακόπτης του Kodi Core
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')

    xbmc.sleep(200)
    xbmcgui.Dialog().notification("Add-ons Updates...", "[COLOR green]Enable[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/auto5.png', sound=False)
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("Check...", "Ελεγχος για ενημερώσεις προσθέτων", icon='special://home/addons/plugin.program.downloader19/resources/media/auto3.png', sound=False)
    xbmc.sleep(2000)
    xbmc.log("[Master_Build] Έλεγχος background διεργασιών πριν το UpdateAddonRepos...", xbmc.LOGINFO)
    
    # 🎯 Τελικός έλεγχος για να σιγουρευτούμε ότι δεν ξέμεινε τίποτα
    wait_for_kodi("Τελικός Έλεγχος Updater")

    while xbmc.getCondVisibility('Window.IsActive(yesnodialog)') or xbmc.getCondVisibility('Window.IsActive(progressdialog)'):
        xbmc.sleep(1000)
        
    xbmc.log("[Master_Build] [RELEASE] Όλα καθαρά! Εκκίνηση του Updater.", xbmc.LOGINFO)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/addonupdatesprog.py")')
    xbmc.sleep(20000)
    Backup_Skin_Set()
    Backup_Home_Set()



def turbo_enable_addons_zip2():
    import sqlite3
    xbmc.log("[Master_Build] Έναρξη turbo ενεργοποίησης προσθέτων για το Zip2...", xbmc.LOGINFO)
    
    addons_path = xbmcvfs.translatePath('special://home/addons')
    addons_db = xbmcvfs.translatePath('special://database/Addons33.db')
    
    addon_xmls = []
    for name in glob.glob(os.path.join(addons_path,'*/addon.xml')):
        addon_xmls.append(name)
    addon_xmls.sort()
    
    addon_ids = []
    for xml in addon_xmls:
        try:
            root = parse(xml) # ⚠️ Αν σου βγάλει error εδώ στο parse, άλλαξέ το σε: from xml.dom.minidom import parse
            tag = root.documentElement
            _id = tag.getAttribute('id')
            addon_ids.append(_id)
        except:
            pass
            
    disabled = []
    for x in addon_ids:
        try:
            xbmcaddon.Addon(id = x)
        except:
            disabled.append(x)
            
    if not disabled:
        return

    try:
        conn = sqlite3.connect(addons_db)
        c = conn.cursor()
        c.execute("PRAGMA synchronous = OFF")
        c.execute("PRAGMA journal_mode = MEMORY")
        
        # Παίρνουμε τη σημερινή ημερομηνία για το installDate
        from datetime import datetime
        installed_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        for y in disabled:
            try:
                c.execute("SELECT id FROM installed WHERE addonID = ?", (y,))
                if c.fetchone() is None:
                    c.execute('INSERT INTO installed (addonID, enabled, installDate) VALUES (?,?,?)', (y, '1', installed_date))
                else:
                    c.execute('UPDATE installed SET enabled = 1 WHERE addonID = ?', (y,))
            except:
                pass
                
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log(f'[Master_Build] SQL Error στο Zip2: {str(e)}', xbmc.LOGERROR)


    # else: dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
    

    # xbmc.executebuiltin('ActivateWindow(2139)')
    #xbmc.executebuiltin('PlayMedia("special://home/media/Bamako.mp4")')
    # xbmc.executebuiltin('PlayMedia("special://home/media/Join_file.mp4")')
    # xbmc.sleep(12000)
        
    # xbmc.executebuiltin('ActivateWindow(2139)')
    # xbmc.sleep(4000)
    # UpdatesStatus()
    
    
    



    # xbmc.executebuiltin('UpdateLocalAddons()')
    # xbmc.sleep(4000)
    # xbmc.executebuiltin('UpdateAddonRepos()')

