﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request, socket

# ⚡ ΑΝΑΓΚΑΣΤΙΚΟ IPv4 & 6s TIMEOUT
socket.setdefaulttimeout(6)
if not getattr(socket, '_ipv4_patched', False):
	_orig_getaddrinfo = socket.getaddrinfo
	def _ipv4_only_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
		return _orig_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
	socket.getaddrinfo = _ipv4_only_getaddrinfo
	socket._ipv4_patched = True


# 🛑 1. ΤΟ ΑΚΑΡΙΑΙΟ ΜΠΛΟΚΑΡΙΣΜΑ (Όταν το downloader19 ενημερώνεται εν ώρα λειτουργίας):
if xbmc.getCondVisibility('Window.IsActive(10040)') or xbmc.getCondVisibility('Window.IsActive(2139)'):
	xbmc.log("[World_Updater] Εντοπίστηκε ανοιχτό παράθυρο ενημερώσεων. Ακαριαίο μπλοκάρισμα.", xbmc.LOGINFO)
	sys.exit()

# 🛡️ THE GLOBAL DYNAMIC BOOT SHIELD
monitor = xbmc.Monitor()
boot_timeout = 8
elapsed_time = 0

while not xbmc.getCondVisibility('Window.IsVisible(home)') and elapsed_time < boot_timeout and not monitor.abortRequested():
	xbmc.sleep(500)
	elapsed_time += 0.5

xbmc.log(f"[World_Updater] Η αρχική οθόνη φορτώθηκε σε {elapsed_time}s. Έναρξη Updater...", xbmc.LOGINFO)

# 🚀 1. ΠΑΥΣΗ ΒΑΡΕΩΝ ΡΥΘΜΙΣΕΩΝ (ΜΕΤΑ ΤΟ HOME ΓΙΑ ΝΑ ΜΗΝ ΚΛΕΙΔΩΝΕΙ ΤΟ CAddonSettings ΤΟΥ KODI 21)
try:
	import addon_optimizer as a_opt
	a_opt.pause_heavy_settings()
except Exception as e:
	xbmc.log(f"[World_Updater] Σφάλμα στο addon_optimizer: {str(e)}", xbmc.LOGERROR)

# 🚀 2. ΠΡΟΣΩΡΙΝΗ ΠΑΥΣΗ WIDGETS
try:
	import World_widget_OnOff as w_mgr
	w_mgr.backup_and_disable_widgets(keep_weather=True, do_reload=False)
	xbmc.log("[World_Updater] Τα Widgets απενεργοποιήθηκαν επιτυχώς!", xbmc.LOGINFO)
except Exception as e:
	xbmc.log(f"[World_Updater] Σφάλμα στο World_widget_OnOff: {str(e)}", xbmc.LOGERROR)


# 🌐 ΕΞΥΠΝΗ ΑΝΑΜΟΝΗ ΔΙΚΤΥΟΥ & DNS
net_wait = 0.0
while net_wait < 20.0 and not monitor.abortRequested():
	try:
		socket.gethostbyname("google.com")
		xbmc.log(f"[World_Updater] Το δίκτυο και το DNS επιβεβαιώθηκαν σε {net_wait}s.", xbmc.LOGINFO)
		break
	except:
		xbmc.sleep(500)
		net_wait += 0.5

profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
addons_dir = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19')

def disable_screensaver():
	""" 🔒 ΑΠΕΝΕΡΓΟΠΟΙΗΣΗ SCREENSAVER """
	try:
		if not os.path.exists(profile_dir):
			os.makedirs(profile_dir)

		backup_file = os.path.join(profile_dir, 'screensaver_backup.txt')
		req_get = '{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"screensaver.mode"},"id":1}'
		res_get = json.loads(xbmc.executeJSONRPC(req_get))
		current_ss = res_get['result']['value']
		
		if not os.path.exists(backup_file):
			with open(backup_file, 'w', encoding='utf-8') as f:
				f.write(current_ss)
				
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":""},"id":1}')
		xbmc.log(f"[World_Updater] Ο screensaver απενεργοποιήθηκε. Backup: {current_ss}", xbmc.LOGINFO)
	except Exception as e:
		xbmc.log(f"[World_Updater] Αποτυχία διαχείρισης screensaver: {str(e)}", xbmc.LOGERROR)

disable_screensaver()

xbmc.sleep(200) 
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')
xbmc.sleep(1000) 
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

from resources.lib.modules import check
from updatervar import *

if __name__ == '__main__':


	if setting('notifyversion') == '0':
		xbmcgui.Dialog().ok('[B][COLOR blue]Πρώτη Εγκατάσταση[/COLOR][/B]', 'Περιμένετε να ολοκληρωθούν [COLOR lime]οι ενημερώσεις των Προσθέτων[/COLOR][CR]και η Εγκατάσταση των [B]binary add-ons[/B].')
		check.notifyT()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":0},"id":1}')
		xbmc.sleep(500)
		check.UpdateAddonRepos()
	else:
		check.zip1()
		external_script = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19/check_build_updates.py')
		
		if os.path.exists(external_script):
			xbmc.log("[World_Updater] Το check_build_updates.py βρέθηκε. Εκτέλεση...", xbmc.LOGINFO)
			xbmc.sleep(1000)
			xbmc.executebuiltin(f'RunScript("{external_script}")')
		elif not setting('updaterversion') == 'false':
			xbmc.log("[World_Updater] Δεν βρέθηκε check_build_updates.py. Έναρξη καθημερινού ελέγχου...", xbmc.LOGINFO)
			check.UpdateAddonRepos()
		else:
			xbmc.log("[World_Updater] Αυτόματες ενημερώσεις απενεργοποιημένες.", xbmc.LOGINFO)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":0},"id":1}')
			xbmc.sleep(200)
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.executebuiltin('UpdateAddonRepos()')
			try:
				import addon_optimizer as a_opt
				a_opt.restore_heavy_settings()
			except:
				pass

			try:
				import World_widget_OnOff as w_mgr
				w_mgr.restore_widgets(do_reload=True)
			except:
				pass

	# 🔄 ΟΜΑΔΟΠΟΙΗΜΕΝΟ TRACKER LOOP (ΠΟΥΠΟΥΛΟ)
	update_interval = 2 * 60 * 60  
	time_counter = 0

	skin_strings_to_reset = [
		'HubFromWidget', 'TrailerCheckID', 'HubMovieTitle', 'HubMoviePlot', 
		'HubMovieCast', 'HubMovieDirector', 'HubMovieWriter', 'HubMovieGenre', 
		'HubMovieYear', 'HubMovieRating', 'HubMovieStudio', 'HubMovieCountry', 
		'HubMoviePoster', 'HubMovieFanart', 'HubMovieTagLine', 'HubMovieDuration', 'HubMovieEndTime'
	]

	while not monitor.abortRequested():
		if monitor.waitForAbort(1.0):
			break

		if xbmc.getCondVisibility('Window.IsVisible(home)') and not xbmc.getCondVisibility('Window.IsVisible(6199)'):
			if xbmc.getInfoLabel('Skin.String(TrailerCheckID)') != '':
				for skin_str in skin_strings_to_reset:
					xbmc.executebuiltin(f'Skin.ResetString({skin_str})')

		time_counter += 1 
		if time_counter >= update_interval:
			time_counter = 0 
			xbmcgui.Dialog().notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
			xbmc.executebuiltin('UpdateAddonRepos()')
