# -*- coding: utf-8 -*-
"""
================================================================================
📦 WORLD BUILD - ADDON OPTIMIZER & NETWORK SHIELD (addon_optimizer.py)
================================================================================
Τι κάνει αυτό το αρχείο:
1. Προσωρινή Παύση & Καθαρισμός Εκκίνησης (pause_heavy_settings):
   - Καθαρίζει παλιά lock files (delete_lock, database_lock, install_lock).
   - Εφαρμόζει τις βασικές ρυθμίσεις προστασίας (απενεργοποίηση PVR/versioncheck).
   - Αποθηκεύει τις ρυθμίσεις βαριών προσθέτων (thegroove360, YouTube, TMDb Helper)
     και τις απενεργοποιεί προσωρινά κατά τις ενημερώσεις.
2. Αυτόματη Επαναφορά (restore_heavy_settings):
   - Επαναφέρει τις ρυθμίσεις των προσθέτων στην αρχική επιλογή του χρήστη.
   - Ανεβάζει το context.subtitles.autosniper στην κορυφή του Context Menu.
   - Καθαρίζει τη μνήμη DNS/Socket της Python.
================================================================================
"""

import os
import json
import socket
import importlib
import xbmc
import xbmcaddon
import xbmcvfs

PROFILE_DIR = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/')
BACKUP_FILE = os.path.join(PROFILE_DIR, 'optimizer_backup.json')

def pause_heavy_settings():
	""" 🛡️ Καθαρισμός παλιών lock files & προσωρινή παύση βαριών ρυθμίσεων """
	try:
		if not os.path.exists(PROFILE_DIR):
			os.makedirs(PROFILE_DIR)

		# 1. Καθαρισμός παλιών lock files (Δικλείδα ασφαλείας)
		for lock_name in ['delete_lock.txt', 'database_lock.txt', 'install_lock.txt', 'zip2_lock.txt']:
			full_lock_path = os.path.join(PROFILE_DIR, lock_name)
			if os.path.exists(full_lock_path):
				try:
					os.remove(full_lock_path)
					xbmc.log(f"[Addon_Optimizer] Σβήστηκε παλιό lock file: {lock_name}", xbmc.LOGINFO)
				except:
					pass

		# 2. Βασικές JSON-RPC ρυθμίσεις προστασίας εκκίνησης
		json_commands = [
			'{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.stalker","enabled":false},"id":1}',
			'{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":false},"id":1}',
			'{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"service.xbmc.versioncheck","enabled":false},"id":1}',
			'{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"addons.updatemode","value":1},"id":1}',
			'{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":1},"id":1}',
			'{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"videoscreen.fakefullscreen","value":false},"id":1}'
		]
		for cmd in json_commands:
			xbmc.executeJSONRPC(cmd)

		# 3. Backup & προσωρινή παύση βαριών ρυθμίσεων προσθέτων
		backup_data = {}
		if os.path.exists(BACKUP_FILE):
			try:
				with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
					backup_data = json.load(f)
			except:
				backup_data = {}

		# thegroove360
		if xbmc.getCondVisibility('System.HasAddon(plugin.video.thegroove360)'):
			try:
				tg_addon = xbmcaddon.Addon('plugin.video.thegroove360')
				if 'thegroove360' not in backup_data:
					backup_data['thegroove360'] = {
						'use_bypass_dns': tg_addon.getSetting('use_bypass_dns') or 'true',
						'p2p_enabled': tg_addon.getSetting('p2p_enabled') or 'true',
						'use_doh_requests': tg_addon.getSetting('use_doh_requests') or 'false'
					}
				tg_addon.setSetting('use_bypass_dns', 'false')
				tg_addon.setSetting('p2p_enabled', 'false')
				tg_addon.setSetting('use_doh_requests', 'false')
			except Exception as e:
				xbmc.log(f"[Addon_Optimizer] Σφάλμα στο thegroove360: {str(e)}", xbmc.LOGERROR)

		# YouTube HTTP Server
		if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
			try:
				yt_addon = xbmcaddon.Addon('plugin.video.youtube')
				if 'youtube' not in backup_data:
					backup_data['youtube'] = {
						'youtube.http.server': yt_addon.getSetting('youtube.http.server') or 'false'
					}
				yt_addon.setSetting('youtube.http.server', 'false')
			except Exception as e:
				xbmc.log(f"[Addon_Optimizer] Σφάλμα στο YouTube: {str(e)}", xbmc.LOGERROR)

		# TMDb Helper Trakt Startup
		if xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
			try:
				tmdb_addon = xbmcaddon.Addon('plugin.video.themoviedb.helper')
				if 'tmdb' not in backup_data:
					backup_data['tmdb'] = {
						'trakt_startup': tmdb_addon.getSetting('trakt_startup') or 'false'
					}
				tmdb_addon.setSetting('trakt_startup', 'false')
			except Exception as e:
				xbmc.log(f"[Addon_Optimizer] Σφάλμα στο TMDb Helper: {str(e)}", xbmc.LOGERROR)

		if backup_data:
			with open(BACKUP_FILE, 'w', encoding='utf-8') as f:
				json.dump(backup_data, f, ensure_ascii=False, indent=2)
			xbmc.log("[Addon_Optimizer] Η παύση και ο καθαρισμός ολοκληρώθηκαν.", xbmc.LOGINFO)

	except Exception as e:
		xbmc.log(f"[Addon_Optimizer] Γενικό σφάλμα pause: {str(e)}", xbmc.LOGERROR)


def restore_heavy_settings():
	""" 🔄 Επαναφορά ρυθμίσεων προσθέτων, ταξινόμηση Context Menu & καθαρισμός DNS/Socket """
	try:
		if os.path.exists(BACKUP_FILE):
			with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
				backup_data = json.load(f)

			if 'thegroove360' in backup_data and xbmc.getCondVisibility('System.HasAddon(plugin.video.thegroove360)'):
				try:
					tg_addon = xbmcaddon.Addon('plugin.video.thegroove360')
					tg_saved = backup_data['thegroove360']
					tg_addon.setSetting('use_bypass_dns', tg_saved.get('use_bypass_dns', 'true'))
					tg_addon.setSetting('p2p_enabled', tg_saved.get('p2p_enabled', 'true'))
					tg_addon.setSetting('use_doh_requests', tg_saved.get('use_doh_requests', 'false'))
				except Exception as e:
					xbmc.log(f"[Addon_Optimizer] Σφάλμα επαναφοράς thegroove360: {str(e)}", xbmc.LOGERROR)

			if 'youtube' in backup_data and xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
				try:
					yt_addon = xbmcaddon.Addon('plugin.video.youtube')
					yt_saved = backup_data['youtube']
					yt_addon.setSetting('youtube.http.server', yt_saved.get('youtube.http.server', 'false'))
				except Exception as e:
					xbmc.log(f"[Addon_Optimizer] Σφάλμα επαναφοράς YouTube: {str(e)}", xbmc.LOGERROR)

			if 'tmdb' in backup_data and xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
				try:
					tmdb_addon = xbmcaddon.Addon('plugin.video.themoviedb.helper')
					tmdb_saved = backup_data['tmdb']
					tmdb_addon.setSetting('trakt_startup', tmdb_saved.get('trakt_startup', 'false'))
				except Exception as e:
					xbmc.log(f"[Addon_Optimizer] Σφάλμα επαναφοράς TMDb Helper: {str(e)}", xbmc.LOGERROR)

			os.remove(BACKUP_FILE)
			xbmc.log("[Addon_Optimizer] Όλες οι ρυθμίσεις επαναφέρθηκαν επιτυχώς.", xbmc.LOGINFO)

		# 📌 Επαναφορά του Subtitles Auto Sniper ψηλά στο Context Menu (Addons33.db)
		try:
			import sqlite3
			db_path = xbmcvfs.translatePath('special://database/Addons33.db')
			if os.path.exists(db_path):
				conn = sqlite3.connect(db_path)
				cur = conn.cursor()
				cur.execute("SELECT id, addonID FROM installed WHERE addonID LIKE 'context.%' ORDER BY id ASC")
				rows = cur.fetchall()
				if len(rows) > 1:
					top_row = rows.pop(0)
					top_id, top_name = top_row
					my_id = 0
					for r in rows:
						r_id, r_name = r
						if r_name == 'context.subtitles.autosniper':
							my_id = r_id
							break
					if my_id and my_id != top_id:
						cur.execute("UPDATE installed SET id = 999999 WHERE id = ?", (my_id,))
						cur.execute("UPDATE installed SET id = ? WHERE id = ?", (my_id, top_id))
						cur.execute("UPDATE installed SET id = ? WHERE id = 999999", (top_id,))
						conn.commit()
						xbmc.log("[Addon_Optimizer] Το context.subtitles.autosniper ανέβηκε στην κορυφή του Context Menu.", xbmc.LOGINFO)
				conn.close()
		except Exception as e:
			xbmc.log(f"[Addon_Optimizer] Σφάλμα ταξινόμησης context menu: {str(e)}", xbmc.LOGERROR)

		# Καθαρισμός DNS/Socket της Python
		importlib.reload(socket)
		socket.setdefaulttimeout(6)
		xbmc.log("[Addon_Optimizer] Το Socket/DNS καθαρίστηκε επιτυχώς.", xbmc.LOGINFO)

	except Exception as e:
		xbmc.log(f"[Addon_Optimizer] Γενικό σφάλμα restore: {str(e)}", xbmc.LOGERROR)
