﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon
from threading import Thread
# 🟢 Ο ΑΥΘΕΝΤΙΚΟΣ ΣΟΥ ΚΩΔΙΚΑΣ (100% ΚΑΘΑΡΟΣ & ΕΛΑΦΡΥΣ)
xbmc.sleep(200)


dp = xbmcgui.DialogProgressBG()

HOME           = xbmcvfs.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
ADDONPATH      = os.path.join(ADDONS, 'plugin.program.downloader19')
FANART         = os.path.join(ADDONPATH, 'fanart.jpg')
ICON           = os.path.join(ADDONPATH, 'icon.png')
SKINFOLD       = os.path.join(ADDONPATH, 'resources', 'skins', 'DefaultSkin', 'media')
ADDONTITLE     = '[B]World Υπηρεσία Ενημέρωσης[/B]'

class MainMonitor(xbmc.Monitor):
    def __init__(self):
        super(MainMonitor, self).__init__()

monitor = MainMonitor()

ACTION_PREVIOUS_MENU            =  10   ## ESC action
ACTION_NAV_BACK                 =  92   ## Backspace action
ACTION_MOVE_LEFT                =   1   ## Left arrow key
ACTION_MOVE_RIGHT               =   2   ## Right arrow key
ACTION_MOVE_UP                  =   3   ## Up arrow key
ACTION_MOVE_DOWN                =   4   ## Down arrow key
ACTION_MOUSE_WHEEL_UP           = 104   ## Mouse wheel up
ACTION_MOVE_MOUSE               = 107   ## Down arrow key
ACTION_SELECT_ITEM              =   7   ## Number Pad Enter
ACTION_BACKSPACE                = 110   ## ?
ACTION_MOUSE_LEFT_CLICK         = 100
ACTION_MOUSE_LONG_CLICK         = 108


##########################
### Converted to XML
##########################

def progress(msg="", t=1, image=ICON, dw='Progress.xml'):
        class MyWindow(xbmcgui.WindowXMLDialog):
            def __init__(self, *args, **kwargs):
                if monitor.waitForAbort(0.5):
                    sys.exit()
                # xbmc.sleep(500)
                self.title = '[COLOR white]%s[/COLOR]' % ADDONTITLE
                self.image = image
                if "ERROR" in kwargs["msg"]:
                    self.image = os.path.join(SKINFOLD, 'Icons', 'defaulticonerror.png')
                self.fanart = FANART
                self.msg = '[COLOR darkorange]%s[/COLOR]' % kwargs["msg"]
                if "ERROR" in kwargs["msg"]:
                    self.msg = '[COLOR red]%s[/COLOR]' % kwargs["msg"]


            def onInit(self):
                self.fanartimage = 101
                self.titlebox = 102
                self.imagecontrol = 103
                self.textbox = 104
                self.showdialog()

            def showdialog(self):
                self.getControl(self.imagecontrol).setImage(self.image)
                self.getControl(self.fanartimage).setImage(os.path.join(SKINFOLD, 'Background', 'progress-dialog-bg.png'))
                self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
                self.getControl(self.textbox).setText(self.msg)
                self.getControl(self.titlebox).setLabel(self.title)
                w_id = str(xbmcgui.getCurrentWindowDialogId())
                x_ = 0
                while x_ < t and xbmc.getCondVisibility("Window.isVisible({})".format(w_id)) and not monitor.abortRequested():
                    x_ += 1
                    if monitor.waitForAbort(1):
                        sys.exit()
                self.close()
                
            def onAction(self,action):
                if   action == ACTION_PREVIOUS_MENU: self.close()
                elif action == ACTION_NAV_BACK: self.close()

        cw = MyWindow( dw , ADDONPATH, 'DefaultSkin', title=ADDONTITLE, fanart=FANART, image=image, msg='[B]'+msg+'[/B]', t=t)
        cw.doModal()
        del cw

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def UpdatesStatus():
    request='{"jsonrpc":"2.0","method":"XBMC.GetInfoLabels","params":{"labels": ["System.AddonUpdateCount"] },"id":1}'
    response = xbmc.executeJSONRPC(request)
    response_result = json.loads(response)
    num = response_result['result']['System.AddonUpdateCount']
    return num

def updateprogress():
    # 🚀 1. Ανοίγουμε το επίσημο παράθυρο των ενημερώσεων
    xbmc.executebuiltin('ActivateWindow(2139)')
    progress('Παρακαλώ περιμένετε!', t=2)
    # 2. Ενημερώνουμε τα Repositories και τα τοπικά πρόσθετα
    xbmc.executebuiltin('UpdateAddonRepos')   
    xbmc.executebuiltin('UpdateLocalAddons')  
    
    while not UpdatesStatus() >= '0':
        if monitor.waitForAbort(1):
            xbmc.executebuiltin('Dialog.Close(all,true)')
            sys.exit()
            
    totalupdates = int(UpdatesStatus())
    free_mem = int(re.sub(r'\D', '', xbmc.getInfoLabel('System.FreeMemory')))
    
    if UpdatesStatus() > '0':
        if free_mem > 200:
            xbmc.executebuiltin('Dialog.Close(all,true)')
            if monitor.waitForAbort(0.5):
                sys.exit()

            # 🚀 Ανοίγουμε το παράθυρο των ξεπερασμένων πρόσθετων
            xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')
            
            # ⏱️ DYNAMIC WAIT LOCK (CHECKMATE V2):
            waiting_time = 0
            while not xbmc.getCondVisibility('Window.IsActive(10040)'):
                xbmc.sleep(100)
                waiting_time += 100
                if waiting_time >= 5000:
                    xbmc.log("[Master_Build] Το παράθυρο 10040 δεν άνοιξε ποτέ. Timeout.", xbmc.LOGWARNING)
                    break
                    
            if xbmc.getCondVisibility('Window.IsActive(10040)'):
                xbmc.sleep(600)
                
                # 🎯 ΚΛΕΙΔΩΝΟΥΜΕ ΤΟ FOCUS ΣΤΗ ΛΙΣΤΑ (ID: 50) ΠΡΙΝ ΤΑ ACTIONS
                xbmc.executebuiltin('Control.SetFocus(50)')
                xbmc.sleep(150)
                
                try:
                    current_updates = int(UpdatesStatus())
                except:
                    current_updates = 0
                    
                if current_updates > 5:
                    xbmc.log(f"[Master_Build] Βρέθηκαν {current_updates} ενημερώσεις (>5). Εκτέλεση Click Bypass.", xbmc.LOGINFO)
                    xbmc.executebuiltin('Action(Down)')
                    xbmc.sleep(250)
                    xbmc.executebuiltin('Action(Select)')
                    xbmc.sleep(500)
                else:
                    xbmc.log(f"[Master_Build] Βρέθηκαν {current_updates} ενημερώσεις (<=3). Παράκαμψη Click Bypass.", xbmc.LOGINFO)

            # 🚀 ΑΦΗΝΟΥΜΕ ΤΑ PROGRESS ΝΑ ΕΜΦΑΝΙΣΤΟΥΝ ΕΛΕΥΘΕΡΑ
            if UpdatesStatus() > '0':
                progress('Υπάρχουν %s [CR]ενημερώσεις' % UpdatesStatus())
                dp.create('Ενημερώσεις προσθέτων', 'Διαθέσιμες %s ενημερώσεις' % UpdatesStatus())
                Thread(target=progress_notification, daemon=True).start()
            else:
                dp.create('Ενημερώσεις προσθέτων', 'Οι ενημερώσεις ολοκληρώθηκαν')
                if monitor.waitForAbort(2):
                    dp.close()
                    sys.exit()
                dp.close()
                
                # 🎯 1η ΚΑΘΥΣΤΕΡΗΣΗ (ΕΞΥΠΝΟ ΦΡΕΝΟ)
                while xbmc.getCondVisibility('Window.IsActive(notification)'):
                    xbmc.sleep(500)
                    if monitor.waitForAbort(0.5):
                        sys.exit()
                        
                if xbmc.getCondVisibility("Window.isVisible(10040)"):
                    xbmc.executebuiltin('Action(Back)')
                    
                if monitor.waitForAbort(0.5):
                    sys.exit()
                    
                # 🎯 2η ΚΑΘΥΣΤΕΡΗΣΗ (ΕΞΥΠΝΟ ΦΡΕΝΟ)
                while xbmc.getCondVisibility('Window.IsActive(notification)'):
                    xbmc.sleep(500)
                    if monitor.waitForAbort(0.5):
                        sys.exit()
                        
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.executebuiltin('ActivateWindow(10000)')
                xbmc.sleep(4000)
                xbmcgui.Dialog().notification("To Build φαίνεται ενημερωμένο...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/ok3.png', sound=False)
                xbmc.sleep(4000)
                xbmcgui.Dialog().notification("Για να δούμε τι θα  δούμε...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/thinking_face.png', sound=False)
                xbmc.sleep(4000)
                return True

            if monitor.waitForAbort(2):
                dp.close()
                sys.exit()

            x = 0
            dismiss = 1080  # Ο χρόνος σου
            zero_count = 0  # Ο μετρητής επιβεβαίωσης για το πραγματικό μηδέν
            
            while x < dismiss and not monitor.abortRequested():
                current_rem = UpdatesStatus()
                
                # 🔥 ΤΟ ΕΞΥΠΝΟ ΦΡΕΝΟ: Αν δείξει '0', μην σπάσεις αμέσως. Περίμενε να σιγουρευτείς.
                if current_rem == '0' or current_rem == 0:
                    zero_count += 1
                    if zero_count >= 4:  # Αν μείνει στο μηδέν για 4 συνεχόμενα δευτερόλεπτα, τότε όντως τέλος!
                        break
                else:
                    zero_count = 0  # Αν ο αριθμός είναι πάνω από 0, μηδένισε τον μετρητή ασφαλείας
                
                x += 1
                msg1 = 'Εκκρεμούν %s ενημερώσεις προσθέτων - κλείνω σε %s' % (str(current_rem), str(dismiss-x))
                msg2 = 'Επιστρέφετε με το πλήκτρο back - κλείνω σε %s' % str(dismiss-x)
                if (x % 2) == 0:
                    msg = msg1
                else:
                    msg = msg2
                
                try:
                    updateperc = int(percentage(int(current_rem), totalupdates))
                except:
                    updateperc = 100
                    
                dp.update(updateperc, 'Ενημερώσεις προσθέτων', msg)
                
                if monitor.waitForAbort(1):
                    dp.close()
                    break

            
            # 🎯 ΕΔΩ ΕΙΝΑΙ ΤΟ ΣΗΜΕΙΟ ΤΗΣ ΕΙΚΟΝΑΣ ΣΟΥ: Τακτοποιημένο και καθαρό
            if UpdatesStatus() == '0':
                dp.update(0, 'Ενημερώσεις προσθέτων', 'Οι ενημερώσεις ολοκληρώθηκαν')
                if monitor.waitForAbort(4):
                    dp.close()
                    sys.exit()
                dp.close()
                
                # 🎯 [ΤΟ ΕΞΥΠΝΟ ΦΡΕΝΟ ΣΤΟ LOOP]
                xbmc.log("[Master_Build] (Loop End) Αναμονή για ολοκλήρωση ειδοποιήσεων πρόσθετων...", xbmc.LOGINFO)
                while xbmc.getCondVisibility('Window.IsActive(notification)'):
                    xbmc.sleep(500)
                    if monitor.waitForAbort(0.5):
                        sys.exit()

                if xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    xbmc.executebuiltin('Action(Back)')
                    if monitor.waitForAbort(0.5):
                        sys.exit()
            elif x == 1080:
                dp.update(0, 'Ενημερώσεις προσθέτων', 'Λήξη χρόνου, οι ενημερώσεις δεν έχουν ολοκληρωθει')
                if monitor.waitForAbort(2):
                    dp.close()
                    sys.exit()
                if xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    xbmc.executebuiltin('Action(Back)')
                    if monitor.waitForAbort(0.5):
                        sys.exit()
                dp.close()
            else:
                dp.update(0, 'Ενημερώσεις προσθέτων', 'Οι ενημερώσεις θα συνεχιστούν στο background')
                if not xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    if monitor.waitForAbort(2):
                        dp.close()
                        sys.exit()
                    dp.close()
                    sys.exit()
                elif xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    if monitor.waitForAbort(2):
                        dp.close()
                        sys.exit()
                    xbmc.executebuiltin('Action(Back)')
                    if monitor.waitForAbort(0.5):
                        sys.exit()
                        
            # 🎯 [ΕΞΥΠΝΟ ΦΡΕΝΟ ΠΡΙΝ ΤΗΝ ΤΕΛΙΚΗ ΕΞΟΔΟ]
            while xbmc.getCondVisibility('Window.IsActive(notification)'):
                xbmc.sleep(500)
                if monitor.waitForAbort(0.5):
                    sys.exit()
                    
            if xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                xbmc.executebuiltin('Action(Back)')
                if monitor.waitForAbort(0.5):
                    sys.exit()
            if xbmc.getCondVisibility("Window.isVisible(10040)"):
                xbmc.executebuiltin('Action(Back)')
            if monitor.waitForAbort(0.5):
                sys.exit()
                
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.executebuiltin('ActivateWindow(10000)')
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("To Build φαίνεται ενημερωμένο...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/ok3.png', sound=False)
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("Για να δούμε τι θα  δούμε...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/thinking_face.png', sound=False)
            xbmc.sleep(4000)
            return True
    else:
        progress('Δεν υπάρχουν[CR]ενημερώσεις προσθέτων', t=2)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(2000)
        xbmcgui.Dialog().notification("To Build είναι ενημερωμένο...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/ok.gif', sound=False)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification("Καλή διασκέδαση!", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/hi.gif', sound=False)
        return False

def progress_notification():
	progress('Περιμένετε να ολοκληρωθούν[CR]οι ενημερώσεις προσθέτων', t=1080, dw='Progress2.xml')

def clean_house():
	""" 🧹 ΕΝΟΤΗΤΑ ΚΑΘΑΡΙΣΜΟΥ & ΑΥΤΟΚΑΘΑΡΙΣΜΟΥ (DOUBLE LOCK DEFENSE) """
	try:
		profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/Installation_lock.txt')
		lock_file = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/installation_lock.txt')
		if os.path.exists(lock_file):
			os.remove(lock_file)
			xbmc.log("[Master_Build] Το installation_lock.txt εξαφανίστηκε οριστικά.", xbmc.LOGINFO)

		lock_file_zip2 = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/zip2_lock.txt')
		if os.path.exists(lock_file_zip2):
			os.remove(lock_file_zip2)
			xbmc.log("[Master_Build] Το zip2_lock.txt εξαφανίστηκε οριστικά από τον δίσκο.", xbmc.LOGINFO)

		vn_service = xbmcvfs.translatePath('special://home/addons/plugin.video.vnmedia/service.py')
		if os.path.exists(vn_service):
			os.remove(vn_service)
		xbmc.sleep(1000)

		pack = xbmcvfs.translatePath('special://home/addons/packages')
		if not os.path.exists(pack):
			os.makedirs(pack)

		base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')
		for folder_name in ["ArtistInformation", "ArtistSlideshow"]:
			target_path = os.path.join(base_path, folder_name)
			if os.path.exists(target_path) and os.path.isdir(target_path):
				shutil.rmtree(target_path)

		# 🧼 🎯 ΑΥΤΟΚΑΘΑΡΙΣΜΟΣ DYNAMIC UPDATE ΑΡΧΕΙΩΝ (THE CLEANUP)
		addons_dir = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19')
		
		# 1. Σβήνουμε τη σημαία .txt αν έχει απομείνει
		trigger_file = os.path.join(addons_dir, 'build_update_trigger.txt')
		if os.path.exists(trigger_file):
			os.remove(trigger_file)
			xbmc.log("[Master_Build] Η σημαία build_update_trigger.txt καθαρίστηκε επιτυχώς.", xbmc.LOGINFO)
			
		# 2. Σβήνουμε το εξωτερικό py script
		dynamic_script = os.path.join(addons_dir, 'check_build_updates.py')
		if os.path.exists(dynamic_script):
			os.remove(dynamic_script)
			xbmc.log("[Master_Build] Το script check_build_updates.py καθαρίστηκε επιτυχώς.", xbmc.LOGINFO)

	except Exception as e:
		xbmc.log(f"[Master_Build] Σφάλμα στην clean_house: {str(e)}", xbmc.LOGERROR)




# ----------------------------------------------------------------------
# 🎯 ΑΠΛΟΠΟΙΗΜΕΝΟ DEF: ΟΛΑ ΤΑ FIXES ΣΕ ΣΕΙΡΑ (ΑΠΟΛΥΤΑ ΑΥΤΟΝΟΜΑ)
# ----------------------------------------------------------------------
def run_pre_update_fixes():
    xbmc.log("[Master_Build] Έναρξη run_pre_update_fixes...", xbmc.LOGINFO)
    xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')

    """ fix1. Απενεργοποίηση του Πρόσθετου --->   The Loop    """
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix1.py")')
    # except: pass
    # xbmc.sleep(500)

    """ fix2. Απενεργοποίηση service --->   plugin.video.the-loop: "8.3"  &  plugin.video.madtitansports: "2.0.45"     """
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix2.py")')
    # except: pass
    # xbmc.sleep(500)

    """ fix2_on. Ενεργοποίηση service --->   plugin.video.the-loop:   &  plugin.video.madtitansports:     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix2_on.py")')
    except: pass
    xbmc.sleep(500)

    """ fix3. Διαγραφή του Πρόσθετου --->   plugin.video.whiskeyblues     """ 
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix3.py")')
    # except: pass
    # xbmc.sleep(2000)

    """ fix4. Διαγραφή του Πρόσθετου --->   plugin.video.AliveGR  έκδοση "2.99.99" (και κάτω)     """
    # try:
    #     xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix4.py")')
    # except: pass
    # xbmc.sleep(2000)

    """ fix5. Διαγραφή settings του Πρόσθετου --->   plugin.video.themoviedb.helper  ( <setting id="language">12</setting> )     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix5.py")')
    except: pass
    xbmc.sleep(500)

    """ fix6. Διαγραφή settings του Πρόσθετου --->   plugin.video.atlas     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix6.py")')
    except: pass
    xbmc.sleep(500)

    """ fix7. Διαγραφή/Ρυθμίσεις settings του Πρόσθετου --->   weather.gismeteo     """
    try:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Fixes/fix7.py")')
    except: pass
    xbmc.sleep(500)


    xbmc.log("[Master_Build] [OK] Και τα 6 Pre-Update Fixes ολοκληρώθηκαν!", xbmc.LOGINFO)


# 🔥 ΕΝΙΑΙΟ ENTRY POINT
if __name__ == '__main__':
	updateprogress()
	clean_house()
	run_pre_update_fixes()
	xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')


	try:
		p_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
		b_file = os.path.join(p_dir, 'screensaver_backup.txt')
		
		if os.path.exists(b_file):
			with open(b_file, 'r', encoding='utf-8') as f:
				saved_ss = f.read().strip()
			
			if not saved_ss: 
				saved_ss = "screensaver.xbmc.builtin.dim"
				
			req_res = '{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":"' + saved_ss + '"},"id":1}'
			xbmc.executeJSONRPC(req_res)
			os.remove(b_file)
			xbmc.log(f"[Master_Build] Ο screensaver επαναφέρθηκε επιτυχώς στο: {saved_ss}", xbmc.LOGINFO)
		else:
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":"screensaver.xbmc.builtin.dim"},"id":1}')
			xbmc.log("[Master_Build] Δεν βρέθηκε αρχείο backup. Ενεργοποίηση fallback screensaver (dim).", xbmc.LOGINFO)
	except Exception as e:
		xbmc.log(f"[Master_Build] Αποτυχία επαναφοράς screensaver στο τέλος: {str(e)}", xbmc.LOGERROR)
