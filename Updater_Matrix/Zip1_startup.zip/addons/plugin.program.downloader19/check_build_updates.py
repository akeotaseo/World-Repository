﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui
from resources.lib.modules import check
from updatervar import *

# 🎯 ΔΥΝΑΜΙΚΟ BLOCK ΕΛΕΓΧΩΝ (ΜΕ ΔΙΚΛΕΙΔΑ ΑΣΦΑΛΕΙΑΣ ΓΙΑ ΤΟ LOAD PROFILE)
if not setting('updaterversion') == 'false':
	xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
	check.notifyT()
	check.autoenable()
	check.var()
	check.delete()
	check.installation()
	check.zip2() 
	check.players()
	# check.zip1()
	check.zip3()
	check.zip4()
	check.zip5()
	check.pvr()
	check.setsetting()
	check.database()
	
	from resources.lib.modules.check import wait_for_kodi
	wait_for_kodi("Ενημέρωση Αποθετηρίων Database")
	
	# 🛑 [ΕΞΥΠΝΟ ΦΡΕΝΟ ΓΙΑ ΤΟ SKIN REBOOT]
	# Ελέγχουμε αν η online έκδοση του skin είναι μεγαλύτερη από αυτή που έχει αποθηκευμένη ο χρήστης
	if not setting('xmlskinversion') == 'false' and check.xmlskin_version > int(setting('xmlskinversion')):
		xbmc.log("[Master_Build] Ανιχνεύτηκε update στο Skin. Εκτέλεση xmlskin() και διακοπή της ροής για αποφυγή διπλού update.", xbmc.LOGINFO)
		check.xmlskin()
		# ⚠️ ΣΤΑΜΑΤΑΜΕ ΕΔΩ! Δεν αφήνουμε τον κώδικα να πάει παρακάτω στο UpdateAddonRepos().
		# Το check.xmlskin() θα κάνει LoadProfile(Master user) και ο updater θα ξαναξεκινήσει καθαρός στο επόμενο boot.
	else:
		# ✅ Αν ΔΕΝ υπάρχει ενημέρωση στο skin, η ροή συνεχίζει κανονικά όπως παλιά
		xbmc.log("[Master_Build] Δεν υπάρχει ενημέρωση στο Skin. Συνέχεια στο UpdateAddonRepos...", xbmc.LOGINFO)
		check.xmlskin() # Θα γίνει bypass γρήγορα αφού οι εκδόσεις είναι ίδιες
		check.UpdateAddonRepos()

else:
	xbmcgui.Dialog().notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
	xbmc.sleep(2000)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":0}}')
	xbmc.sleep(2000)
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
