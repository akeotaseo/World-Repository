﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, sys, os, xbmcvfs
import socket
socket.setdefaulttimeout(6)
if not getattr(socket, '_ipv4_patched', False):
	_orig_getaddrinfo = socket.getaddrinfo
	def _ipv4_only_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
		return _orig_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
	socket.getaddrinfo = _ipv4_only_getaddrinfo
	socket._ipv4_patched = True


from resources.lib.modules import check
from updatervar import *

if not setting('updaterversion') == 'false':

	xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
	check.notifyT()
	check.autoenable()
	check.var()
	check.delete()
	check.installation()
	check.zip2() 
	check.players()
	check.zip3()
	check.zip4()
	check.zip5()
	check.pvr()
	check.setsetting()
	check.database()
	
	from resources.lib.modules.check import wait_for_kodi
	wait_for_kodi("Ενημέρωση Αποθετηρίων Database")

	# 1. Έλεγχος μενού skin
	check.xmlskin() 

	check.UpdateAddonRepos()

else:
	xbmcgui.Dialog().notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
	xbmc.sleep(2000)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":0},"id":1}')
	xbmc.sleep(2000)
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.executebuiltin('UpdateAddonRepos()')

	# 1. 🔒 ΕΠΑΝΑΦΟΡΑ ΤΟΥ SCREENSAVER
	try:
		p_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
		b_file = os.path.join(p_dir, 'screensaver_backup.txt')
		if os.path.exists(b_file):
			with open(b_file, 'r', encoding='utf-8') as f:
				saved_ss = f.read().strip()
			if not saved_ss:
				saved_ss = "screensaver.xbmc.builtin.dim"
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":"' + saved_ss + '"},"id":1}')
			os.remove(b_file)
		else:
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":"screensaver.xbmc.builtin.dim"},"id":1}')
	except:
		pass

	# 2. 🌐 ΕΠΑΝΑΦΟΡΑ OPTIMIZER & ΚΑΘΑΡΙΣΜΟΣ SOCKET
	try:
		import addon_optimizer as a_opt
		a_opt.restore_heavy_settings()
	except:
		pass

	# 3. 🔄 ΕΠΑΝΑΦΟΡΑ WIDGETS
	try:
		import World_widget_OnOff as w_mgr
		w_mgr.restore_widgets(do_reload=True)
	except:
		pass
