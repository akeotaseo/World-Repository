﻿# -*- coding: utf-8 -*-
from updatervar import *
import xbmc
import xbmcgui
import xbmcvfs
import os
import json

# 🔥 1. CORE SKIN LOCK: Ανάβουμε τη σημαία στην C++ του Kodi
try:
    xbmc.executebuiltin('Skin.SetString(InstallationRunning,true)')
except:
    pass

dialog = xbmcgui.Dialog()

addons_list_installation = [
    'repository.World', 'service.audio.tmdb.sync', 'script.subterra', 
    'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 
    'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 
    'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 
    'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 
    'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 
    'repository.wetdreams69', 'repository.sportsurge', 'repository.kodimate', 
    'repository.thetallone', 'repository.starfleet', 'repository.opencode', 
    'repository.sniper', 'repository.vortex', 'repository.Worldrepo'
]

def is_addon_installed(addon_id):
    """ Ελέγχει ακαριαία μέσω JSON-RPC αν το πρόσθετο είναι ήδη εγκατεστημένο στη RAM του Kodi """
    query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"%s"},"id":1}' % addon_id
    try:
        response = xbmc.executeJSONRPC(query)
        if response:
            response_json = json.loads(response)
            if 'result' in response_json and 'addon' in response_json['result']:
                return True
    except:
        pass
    return False

def check_addons_list():
    pDialog = xbmcgui.DialogProgressBG()
    try:
        # 🎯 ΣΤΑΘΕΡΟ ΜΗΝΥΜΑ: Αρχικό γενικό κείμενο στην οθόνη χωρίς ονόματα
        pDialog.create('World Updater', 'Έλεγχος και συγχρονισμός συστήματος...')
    except:
        pass
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        try:
            percent = int(((index) / float(total_addons)) * 100)
            # 🎯 ΣΤΑΘΕΡΟ ΜΗΝΥΜΑ: Δείχνει μόνο τον αριθμό (π.χ. 1/27) για να ξέρει ο χρήστης την πρόοδο
            pDialog.update(percent, 'World Updater', f'Παρακαλώ περιμένετε... ({index+1}/{total_addons})')
        except:
            pass
        
        # 🎯 FAST BYPASS: Αν το πρόσθετο είναι ήδη εγκατεστημένο, το προσπερνάμε ΑΚΑΡΙΑΙΑ
        if is_addon_installed(addon_id):
            continue
            
        # 🚀 ΑΘΟΡΥΒΗ ΕΓΚΑΤΑΣΤΑΣΗ: Χρησιμοποιούμε JSON-RPC αντί για InstallAddon() για να μην βγει ΠΟΤΕ notification
        xbmc.log(f"[Master_Build] [INSTALL] Ενεργοποίηση προσθέτου στη σειρά στο παρασκήνιο...", xbmc.LOGINFO)
        try:
            json_query = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":true}}' % addon_id
            xbmc.executeJSONRPC(json_query)
        except:
            pass
        
        # Αναμονή εγκατάστασης με δικλείδα ασφαλείας
        timeout_counter = 0
        while not is_addon_installed(addon_id) and timeout_counter < 10:
            xbmc.sleep(500)
            timeout_counter += 1
                    
    try:
        pDialog.update(100, 'World Updater', 'Ο έλεγχος ολοκληρώθηκε!')
        xbmc.sleep(500)
        pDialog.close()
    except:
        pass
    
    # 🔓 2. ΑΠΑΣΦΑΛΙΣΗ: Σβήνουμε τη σημαία στη C++ και απελευθερώνουμε την ουρά
    try:
        xbmc.executebuiltin('Skin.ResetString(InstallationRunning)')
        xbmc.log("[Master_Build] To InstallationRunning σβήστηκε. Η ουρά προχωράει!", xbmc.LOGINFO)
    except:
        pass

# Εκτέλεση του ελέγχου
if __name__ == '__main__':
    check_addons_list()

