﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# 🎯 ΟΡΙΣΜΟΣ ΤΟΥ INSTALL LOCK ΑΡΧΕΙΟΥ
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
INSTALL_LOCK_FILE = os.path.join(profile_dir, 'install_lock.txt')

# 🎯 Η ΛΙΣΤΑ ΣΟΥ ΜΕ ΤΑ REPOSITORIES / ADDONS
addons_list_installation = [
    'repository.Worldolympic', 'repository.Worldrepo', 'repository.World', 
    'repository.WorldNexus', 'repository.WorldOmega', 'repository.resolveurl', 
    'repository.thecrew.alpha', 'repository.twilight0', 'repository.RedWizard', 
    'repository.gkobu', 'repository.manalab19', 'repository.chainsrepo', 
    'repository.autowidget', 'repository.zeltorix', 'repository.jurialmunkey', 
    'repository.diggz', 'repository.cMaNWizard', 'repository.EzzerMacsWizard', 
    'repository.loop', 'repository.Xbmc.org', 'repository.bugatsinho', 
    'repository.castagnait', 'repository.funstersplace', 'repository.roooar', 
    'repository.dexe', 'repository.Magnetic', 'repository.vstream'
]

def is_addon_installed(addon_id):
    """Ελέγχει αν το πρόσθετο είναι ήδη εγκατεστημένο στο Kodi"""
    return xbmc.getCondVisibility('System.HasAddon(%s)' % (addon_id))

def check_addons_list():
    # ----------------------------------------------------------------------
    # 🎯 ΑΚΑΡΙΑΙΑ ΔΗΜΙΟΥΡΓΙΑ ΤΟΥ INSTALL LOCK
    # ----------------------------------------------------------------------
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)

    with open(INSTALL_LOCK_FILE, 'w') as f:
        f.write('RUNNING')

    xbmc.log("[World_Updater] Δημιουργήθηκε το install_lock.txt από το addons_list_installation.py", xbmc.LOGINFO)
    # ----------------------------------------------------------------------

    pDialog = xbmcgui.DialogProgressBG()
    try:
        pDialog.create('World Updater', 'Έλεγχος και συγχρονισμός συστήματος...')
    except:
        pass
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        try:
            percent = int(((index) / float(total_addons)) * 100)
            pDialog.update(percent, 'World Updater', f'Παρακαλώ περιμένετε... ({index+1}/{total_addons})')
        except:
            pass
        
        if is_addon_installed(addon_id):
            continue
            
        xbmc.log(f"[Master_Build] [INSTALL] Λήψη και εγκατάσταση προσθέτου: {addon_id}", xbmc.LOGINFO)
        try:
            xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
            xbmc.sleep(800)
            xbmc.executebuiltin('SendClick(11)')
        except:
            pass
        
        timeout_counter = 0
        while not is_addon_installed(addon_id) and timeout_counter < 40:
            xbmc.sleep(500)
            timeout_counter += 1
            if timeout_counter % 10 == 0:
                try: xbmc.executebuiltin('SendClick(11)')
                except: pass
                    
    try:
        pDialog.update(100, 'World Updater', 'Ο έλεγχος ολοκληρώθηκε!')
        xbmc.sleep(500)
        pDialog.close()
    except:
        pass

    # ----------------------------------------------------------------------
    # 🧼 ΣΒΗΣΙΜΟ ΤΟΥ INSTALL LOCK ΣΤΟ ΑΠΟΛΥΤΟ ΤΕΛΟΣ
    # ----------------------------------------------------------------------
    if os.path.exists(INSTALL_LOCK_FILE):
        try:
            os.remove(INSTALL_LOCK_FILE)
            xbmc.log("[World_Updater] Το install_lock.txt αφαιρέθηκε. Η εγκατάσταση των Repos ολοκληρώθηκε.", xbmc.LOGINFO)
        except:
            pass
    # ----------------------------------------------------------------------

# Αυτόματη εκτέλεση αν το script κληθεί αυτόνομα
if __name__ == '__main__':
    check_addons_list()
