﻿# -*- coding: utf-8 -*-
import os
import glob
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import shutil
from updatervar import *

# 🎯 ΟΡΙΣΜΟΣ ΤΟΥ INSTALL LOCK ΑΡΧΕΙΟΥ
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
INSTALL_LOCK_FILE = os.path.join(profile_dir, 'install_lock.txt')

# 🎯 Η ΛΙΣΤΑ ΣΟΥ ΜΕ ΤΑ REPOSITORIES / ADDONS
addons_list_installation = [
    'repository.World', 'service.audio.tmdb.sync', 'script.subterra', 
    'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 
    'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 
    'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 
    'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 
    'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 
    'repository.wetdreams69', 'repository.kodimate', 'repository.seriesly', 
    'repository.thetallone', 'repository.starfleet', 'repository.opencode', 
    'repository.sniper', 'repository.vortex', 'repository.Worldrepo'
]

def is_addon_installed(addon_id):
    """🎯 ΜΠΕΤΟΝ ΑΡΜΕ ΕΛΕΓΧΟΣ: Κοιτάει κατευθείαν στον δίσκο αν υπάρχει ο φάκελος"""
    addons_root = xbmcvfs.translatePath('special://home/addons')
    full_addon_path = os.path.join(addons_root, addon_id)
    
    # Αν ο φάκελος υπάρχει ήδη, επιστρέφει True ακαριαία για να γίνει continue
    if os.path.exists(full_addon_path):
        return True
        
    # Εναλλακτική δικλείδα ασφαλείας στο σύστημα του Kodi
    return xbmc.getCondVisibility('System.HasAddon(%s)' % (addon_id))

def check_addons_list():
    # ----------------------------------------------------------------------
    # 🎯 ΑΚΑΡΙΑΙΑ ΔΗΜΙΟΥΡΓΙΑ ΤΟΥ INSTALL LOCK
    # ----------------------------------------------------------------------
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)

    with open(INSTALL_LOCK_FILE, 'w') as f:
        f.write('RUNNING')

    xbmc.log("[World_Updater] Δημιουργήθηκε το install_lock.txt από το addons_list_installation.py", xbmc.LOGINFO)
    # ----------------------------------------------------------------------
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        
        # 🔥 Αν το πρόσθετο υπάρχει ήδη στον δίσκο, το προσπερνάει ακαριαία χωρίς να αγγίξει το GUI!
        if is_addon_installed(addon_id):
            continue
            
        # 📝 ΕΝΗΜΕΡΩΣΗ ΚΕΙΜΕΝΟΥ: Στέλνουμε τις πληροφορίες (π.χ. 2/27) να φαίνονται στο build notification
        clean_message = f'[COLOR orange]Γίνεται εγκατάσταση... ({index+1}/{total_addons})[/COLOR]'
        xbmc.executebuiltin(f'Skin.SetString(NotifyMessage,{clean_message})')
        
        xbmc.log(f"[Master_Build] [INSTALL] Λήψη και εγκατάσταση προσθέτου: {addon_id}", xbmc.LOGINFO)
        try:
            # 🚀 Η εντολή του Kodi που ανοίγει το μεγάλο κεντρικό παράθυρο της φωτογραφίας σου
            xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
            xbmc.sleep(800)
            xbmc.executebuiltin('SendClick(11)')
        except:
            pass
        
        timeout_counter = 0
        # ⚡ Γρήγορο timeout για να μην κολλάει η ροή αν κάποιο repo έχει πέσει
        while not is_addon_installed(addon_id) and timeout_counter < 10:
            xbmc.sleep(500)
            timeout_counter += 1
            if timeout_counter % 5 == 0:
                try: xbmc.executebuiltin('SendClick(11)')
                except: pass
                    
    # Καθαρίζουμε το string του μηνύματος στο τέλος
    xbmc.executebuiltin('Skin.ResetString(NotifyMessage)')

    # ----------------------------------------------------------------------
    # 🧼 ΣΒΗΣΙΜΟ ΤΟΥ INSTALL LOCK ΣΤΟ ΑΠΟΛΥΤΟ ΤΕΛΟΣ
    # ----------------------------------------------------------------------
    xbmc.sleep(1000) # Δίνουμε 1" χρόνο στο σύστημα να ξεκλειδώσει το αρχείο
    if os.path.exists(INSTALL_LOCK_FILE):
        try:
            os.remove(INSTALL_LOCK_FILE)
            xbmc.log("[World_Updater] To install_lock.txt αφαιρέθηκε. Η εγκατάσταση ολοκληρώθηκε.", xbmc.LOGINFO)
        except:
            pass
    # ----------------------------------------------------------------------

    # ----------------------------------------------------------------------

# Αυτόματη εκτέλεση αν το script κληθεί αυτόνομα
if __name__ == '__main__':
    check_addons_list()

