﻿### 📥 2. Το Σταθερό `addons_list_installation.py` (Για τα `addon_data` σου)

# Αυτό είναι το εξωτερικό script. Έχει ρυθμιστεί ως **πλήρης κατάσκοπος**. Επειδή τα δύο αυτά addons λείπουν, η `is_addon_installed` θα επιστρέψει αμέσως `False`, οπότε το Kodi θα εκτελέσει την `InstallAddon` **μόνο** γι' αυτά τα δύο, ενώ τα υπόλοιπα 18 που υπάρχουν ήδη στο σύστημα θα τα προσπεράσει **σε λιγότερο από μισό δευτερόλεπτο**!

# ```python
# -*- coding: utf-8 -*-
from updatervar import *
import xbmc
import xbmcgui
import xbmcvfs
import os
import json

# 🔥 1. CORE SKIN LOCK: Ανάβουμε τη σημαία στη μνήμη της C++ του Kodi
try:
    xbmc.executebuiltin('Skin.SetString(InstallationRunning,true)')
except:
    pass

dialog = xbmcgui.Dialog()

addons_list_installation = [
    'repository.World', 'service.audio.tmdb.sync', 'script.subterra', 
    'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 
    'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 
    'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 
    'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 
    'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 
    'repository.wetdreams69', 'repository.sportsurge', 'repository.kodimate', 
    'repository.thetallone', 'repository.starfleet', 'repository.opencode', 
    'repository.sniper', 'repository.vortex', 'repository.Worldrepo'
]

def is_addon_installed(addon_id):
    """ Ελέγχει ακαριαία μέσω JSON-RPC αν το πρόσθετο είναι ήδη εγκατεστημένο στη RAM του Kodi """
    query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"%s"},"id":1}' % addon_id
    try:
        response = xbmc.executeJSONRPC(query)
        if response:
            response_json = json.loads(response)
            if 'result' in response_json and 'addon' in response_json['result']:
                return True
    except:
        pass
    return False

def check_addons_list():
    pDialog = xbmcgui.DialogProgressBG()
    try:
        pDialog.create('World Updater', 'Έλεγχος κατάστασης προσθέτων...')
    except:
        pass
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        try:
            percent = int(((index) / float(total_addons)) * 100)
            pDialog.update(percent, 'World Updater', f'Έλεγχος: {addon_id} ({index+1}/{total_addons})')
        except:
            pass
        
        # 🎯 FAST BYPASS: Αν το πρόσθετο είναι ήδη εγκατεστημένο, το προσπερνάμε ΑΚΑΡΙΑΙΑ
        if is_addon_installed(addon_id):
            continue
            
        # 🚀 Μόνο αν το πρόσθετο ΛΕΙΠΕΙ (όπως τα δύο που διέγραψες), τότε το εγκαθιστούμε
        xbmc.log(f"[Master_Build] [INSTALL] Το {addon_id} λείπει. Έναρξη εγκατάστασης...", xbmc.LOGINFO)
        try:
            xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
            xbmc.sleep(800)
            xbmc.executebuiltin('SendClick(11)')
        except:
            pass
        
        # Αναμονή εγκατάστασης με δικλείδα ασφαλείας (timeout)
        timeout_counter = 0
        while not is_addon_installed(addon_id) and timeout_counter < 40:
            xbmc.sleep(500)
            timeout_counter += 1
            if timeout_counter % 10 == 0:
                try: xbmc.executebuiltin('SendClick(11)')
                except: pass
                    
    try:
        pDialog.update(100, 'World Updater', 'Ο έλεγχος ολοκληρώθηκε!')
        xbmc.sleep(500)
        pDialog.close()
    except:
        pass
    
    # 🧼 ΔΙΑΓΡΑΦΗ ΣΗΜΑΔΟΥΡΑΣ: Σβήνουμε το αρχείο κειμένου για να ελευθερώσουμε αμέσως τις ενημερώσεις
    lock_file = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/installation_lock.txt')
    if os.path.exists(lock_file):
        try:
            os.remove(lock_file)
            xbmc.log("[Master_Build] To installation_lock.txt καθαρίστηκε επιτυχώς.", xbmc.LOGINFO)
        except:
            pass
    
    # 🔓 2. ΑΠΑΣΦΑΛΙΣΗ: Σβήνουμε τη σημαία στη C++
    try:
        xbmc.executebuiltin('Skin.ResetString(InstallationRunning)')
    except:
        pass

# Εκτέλεση του ελέγχου
if __name__ == '__main__':
    check_addons_list()