﻿# -*- coding: utf-8 -*-
from updatervar import *
import xbmc
import xbmcgui
import xbmcvfs
import os
import json  # 🎯 Απαραίτητο για τον ακαριαίο έλεγχο

# 🔥 1. CORE SKIN LOCK: Ανάβουμε τη σημαία στη μνήμη της C++ του Kodi!
xbmc.executebuiltin('Skin.SetString(InstallationRunning,true)')

dialog = xbmcgui.Dialog()
dialog.notification('Εγκατάσταση αρχείων...', 'Έναρξη λήψης νέων πρόσθετων', icon_install, sound=False)
xbmc.sleep(500) 

addons_list_installation = [
    'repository.World', 'service.audio.tmdb.sync', 'script.subterra', 
    'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 
    'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 
    'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 
    'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 
    'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 
    'repository.wetdreams69', 'repository.Worldrepo'
]

def is_addon_installed(addon_id):
    """ Ελέγχει ακαριαία μέσω JSON-RPC αν το πρόσθετο είναι ήδη εγκατεστημένο στο Kodi """
    query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"%s"},"id":1}' % addon_id
    response = xbmc.executeJSONRPC(query)
    if response:
        response_json = json.loads(response)
        if 'result' in response_json and 'addon' in response_json['result']:
            return True
    return False

def check_addons_list():
    pDialog = xbmcgui.DialogProgressBG()
    pDialog.create('World Updater', 'Εγκατάσταση νέων προσθέτων...')
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        percent = int(((index) / float(total_addons)) * 100)
        pDialog.update(percent, 'World Updater', f'Έλεγχος / Λήψη: {addon_id} ({index+1}/{total_addons})')
        
        # 🎯 ΤΟ ΑΠΟΛΥΤΟ ΦΡΕΝΟ: Αν το πρόσθετο είναι ήδη εγκατεστημένο,
        # το προσπερνάμε ΑΜΕΣΩΣ χωρίς να καλέσουμε ΠΟΤΕ την InstallAddon!
        if is_addon_installed(addon_id):
            xbmc.log(f"[Master_Build] [JSON-SKIP] Το {addon_id} είναι ήδη εγκατεστημένο. Προσπεράστηκε ακαριαία.", xbmc.LOGINFO)
            continue # Πάει σφαίρα στο επόμενο addon της λίστας
            
        # 🚀 Αν ΔΕΝ υπάρχει, τότε μόνο ξεκινάει η πραγματική εγκατάσταση από το Repo
        xbmc.log(f"[Master_Build] [INSTALL] Το {addon_id} ΔΕΝ βρέθηκε. Έναρξη εγκατάστασης...", xbmc.LOGINFO)
        
        # Στέλνουμε την εντολή εγκατάστασης στο Kodi
        xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
        xbmc.sleep(1000)
        xbmc.executebuiltin('SendClick(11)') # Πρώτο κλικ επιβεβαίωσης
        
        # ⏱️ ΕΣΩΤΕΡΙΚΗ ΑΝΑΜΟΝΗ: Περιμένουμε έως ότου το JSON-RPC επιβεβαιώσει την εγκατάσταση
        timeout_counter = 0
        while not is_addon_installed(addon_id) and timeout_counter < 90:
            xbmc.sleep(500)
            timeout_counter += 1
            if timeout_counter % 10 == 0:
                xbmc.executebuiltin('SendClick(11)')
                    
        # ... (όλος ο υπόλοιπος κώδικας του check_addons_list() σου) ...
                    
    pDialog.update(100, 'World Updater', 'Όλα τα πρόσθετα εγκαταστάθηκαν επιτυχώς!')
    xbmc.sleep(1000)
    pDialog.close()
    
    # 🧼 ΔΙΑΓΡΑΦΗ ΣΗΜΑΔΟΥΡΑΣ: Σβήνουμε το αρχείο κειμένου για να ελευθερώσουμε τις ενημερώσεις!
    lock_file = 'special://home/userdata/addon_data/plugin.program.downloader19/installation_lock.txt'
    if xbmcvfs.exists(lock_file):
        xbmcvfs.delete(lock_file)
        xbmc.log("[Master_Build] Το installation_lock.txt διαγράφτηκε επιτυχώς.", xbmc.LOGINFO)
    
    # 🔓 2. ΑΠΑΣΦΑΛΙΣΗ: Σβήνουμε τη σημαία ακαριαία!
    xbmc.executebuiltin('Skin.ResetString(InstallationRunning)')


# Εκτέλεση του ελέγχου
check_addons_list()
