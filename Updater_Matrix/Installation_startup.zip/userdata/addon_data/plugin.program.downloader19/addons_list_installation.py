﻿# -*- coding: utf-8 -*-
from updatervar import *
import xbmc, xbmcgui, xbmcvfs, os

# 🔥 1. CORE SKIN LOCK: Ανάβουμε τη σημαία στη μνήμη της C++ του Kodi!
xbmc.executebuiltin('Skin.SetString(InstallationRunning,true)')

dialog = xbmcgui.Dialog()
dialog.notification('Εγκατάσταση αρχείων...', 'Έναρξη λήψης νέων πρόσθετων', icon_install, sound=False)
xbmc.sleep(500) 

# ... (όλος ο υπόλοιπος κλασικός κώδικας της check_addons_list() με τη λίστα σου) ...

    pDialog.update(100, 'World Updater', 'Όλα τα πρόσθετα εγκαταστάθηκαν επιτυχώς!')
    xbmc.sleep(1000)
    pDialog.close()
    
    # 🔓 2. ΑΠΑΣΦΑΛΙΣΗ: Σβήνουμε τη σημαία ακαριαία!
    xbmc.executebuiltin('Skin.ResetString(InstallationRunning)')

check_addons_list()
