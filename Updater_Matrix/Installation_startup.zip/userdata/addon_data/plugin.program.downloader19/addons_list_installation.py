﻿# -*- coding: utf-8 -*-
from updatervar import *
import xbmc
import xbmcgui
import xbmcvfs
import os
import json

addons_list_installation = [
    'repository.World', 'service.audio.tmdb.sync', 'script.subterra', 
    'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 
    'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 
    'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 
    'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 
    'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 
    'repository.wetdreams69', 'repository.sportsurge', 'repository.kodimate', 
    'repository.thetallone', 'repository.starfleet', 'repository.opencode', 
    'repository.sniper', 'repository.vortex', 'repository.Worldrepo'
]

def is_addon_installed(addon_id):
    query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"%s"},"id":1}' % addon_id
    try:
        response = xbmc.executeJSONRPC(query)
        if response:
            response_json = json.loads(response)
            if 'result' in response_json and 'addon' in response_json['result']:
                return True
    except:
        pass
    return False

def check_addons_list():
    pDialog = xbmcgui.DialogProgressBG()
    try:
        pDialog.create('World Updater', 'Έλεγχος και συγχρονισμός συστήματος...')
    except:
        pass
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        try:
            percent = int(((index) / float(total_addons)) * 100)
            pDialog.update(percent, 'World Updater', f'Παρακαλώ περιμένετε... ({index+1}/{total_addons})')
        except:
            pass
        
        if is_addon_installed(addon_id):
            continue
            
        xbmc.log(f"[Master_Build] [INSTALL] Ενεργοποίηση προσθέτου στη σειρά στο παρασκήνιο...", xbmc.LOGINFO)
        try:
            json_query = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":true}}' % addon_id
            xbmc.executeJSONRPC(json_query)
        except:
            pass
        
        timeout_counter = 0
        while not is_addon_installed(addon_id) and timeout_counter < 10:
            xbmc.sleep(500)
            timeout_counter += 1
                    
    try:
        pDialog.update(100, 'World Updater', 'Ο έλεγχος ολοκληρώθηκε!')
        xbmc.sleep(500)
        pDialog.close()
    except:
        pass

# 🎯 ΠΡΟΣΟΧΗ: Αφαιρέθηκε το "if __name__ == '__main__':" για να εκτελείται ΜΟΝΟ όταν το καλούμε εμείς!
