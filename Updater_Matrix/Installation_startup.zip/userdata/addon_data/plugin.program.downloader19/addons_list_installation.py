﻿# -*- coding: utf-8 -*-
from updatervar import *
import xbmc
import xbmcgui
import xbmcvfs
import os

# 📂 Ορίζουμε τη διαδρομή για το προσωρινό αρχείο-κλειδί (Lock File)
lock_file = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/install.lock')

# 🔥 CORE LOCK: Δημιουργούμε το αρχείο-κλειδί για να πατήσει φρένο το σύστημα!
try:
    with open(lock_file, 'w') as f:
        f.write('running')
except:
    pass

dialog = xbmcgui.Dialog()
dialog.notification('Εγκατάσταση αρχείων...', 'Έναρξη λήψης νέων πρόσθετων', icon_install, sound=False)
xbmc.sleep(500) 

addons_list_installation = ['repository.World', 'service.audio.tmdb.sync', 'script.subterra', 'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 'repository.wetdreams69', 'repository.Worldrepo']

def check_addons_list():
    pDialog = xbmcgui.DialogProgressBG()
    pDialog.create('World Updater', 'Εγκατάσταση νέων προσθέτων...')
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        percent = int(((index) / float(total_addons)) * 100)
        pDialog.update(percent, 'World Updater', f'Λήψη: {addon_id} ({index+1}/{total_addons})')
        
        full_addon_path = xbmcvfs.translatePath(os.path.join(addons_path, addon_id))
        
        # Αν το πρόσθετο ΔΕΝ υπάρχει πραγματικά στον δίσκο, το στέλνουμε για εγκατάσταση
        if not os.path.exists(full_addon_path):
            xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
            xbmc.sleep(1000)
            xbmc.executebuiltin('SendClick(11)')
            
            # ⏱️ ΕΣΩΤΕΡΙΚΗ ΑΝΑΜΟΝΗ: Περιμένουμε έως 45 δευτερόλεπτα (90 loops * 500ms) ανά πρόσθετο
            timeout_counter = 0
            while not os.path.exists(full_addon_path) and timeout_counter < 90:
                xbmc.sleep(500)
                timeout_counter += 1
                if timeout_counter % 10 == 0:
                    xbmc.executebuiltin('SendClick(11)')
                    
    pDialog.update(100, 'World Updater', 'Όλα τα πρόσθετα εγκαταστάθηκαν επιτυχώς!')
    xbmc.sleep(2000)
    pDialog.close()
    
    # 🔓 ΑΠΑΣΦΑΛΙΣΗ: Τελειώσαμε, σβήνουμε το αρχείο-κλειδί για να ελευθερωθεί η ουρά!
    if os.path.exists(lock_file):
        try: os.remove(lock_file)
        except: pass

# Εκτέλεση του ελέγχου
check_addons_list()

