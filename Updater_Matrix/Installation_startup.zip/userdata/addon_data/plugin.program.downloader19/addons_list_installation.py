﻿from updatervar import *
import xbmc
import os

dialog.notification('Εγκατάσταση αρχείων...', 'Έναρξη λήψης νέων πρόσθετων', icon_install, sound=False)
xbmc.sleep(500) 

addons_list_installation = ['repository.test', 'service.audio.tmdb.sync', 'script.subterra', 'repository.fivebanger', 'repository.giaitri', 'repository.rdplayer', 'repository.angelitto', 'Bee-Queen', 'repository.fanvodpl', 'repository.thecrew.alpha', 'repository.arkane14', 'repository.cbtv', 'repository.kodi.media', 'repository.remod', 'repository.enigmawiz', 'repository.zeus768', 'repository.fivebanger', 'repository.adulthideout', 'repository.wetdreams69', 'repository.test2']

def check_addons_list():
    # 🎯 Δημιουργούμε ένα Background Progress Dialog για να βλέπει ο χρήστης την πραγματική πρόοδο
    pDialog = xbmcgui.DialogProgressBG()
    pDialog.create('World Updater', 'Εγκατάσταση νέων προσθέτων...')
    
    total_addons = len(addons_list_installation)
    
    for index, addon_id in enumerate(addons_list_installation):
        # Υπολογισμός ποσοστού μπάρας προόδου
        percent = int(((index) / float(total_addons)) * 100)
        pDialog.update(percent, 'World Updater', f'Λήψη: {addon_id} ({index}/{total_addons})')
        
        # Καθορίζουμε την πλήρη διαδρομή του φακέλου του addon
        # Το addons_path έρχεται έτοιμο από το updatervar σου (π.χ. special://home/addons/)
        full_addon_path = xbmcvfs.translatePath(os.path.join(addons_path, addon_id))
        
        # Αν το πρόσθετο ΔΕΝ υπάρχει, το στέλνουμε για εγκατάσταση
        if not os.path.exists(full_addon_path):
            xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
            xbmc.sleep(1000)
            xbmc.executebuiltin('SendClick(11)')
            
            # 🔥 ΤΟ ΕΞΥΠΝΟ ΦΡΕΝΟ (SAFE INSTALLATION LOCK):
            # Η Python «παγώνει» εδώ και περιμένει μέχρι το Kodi να δημιουργήσει τον φάκελο στον δίσκο!
            # Δίνουμε μέγιστη αναμονή 45 δευτερόλεπτα (90 loops * 500ms) ανά πρόσθετο για ασφάλεια.
            timeout_counter = 0
            while not os.path.exists(full_addon_path) and timeout_counter < 90:
                xbmc.sleep(500)
                timeout_counter += 1
                # Κρατάμε το Kodi ζωντανό κατά την αναμονή
                if timeout_counter % 10 == 0:
                    xbmc.executebuiltin('SendClick(11)')
                    
    # Τελικό κλείσιμο της μπάρας
    pDialog.update(100, 'World Updater', 'Όλα τα πρόσθετα εγκαταστάθηκαν επιτυχώς!')
    xbmc.sleep(2000)
    pDialog.close()

# Εκτέλεση του ελέγχου
check_addons_list()
