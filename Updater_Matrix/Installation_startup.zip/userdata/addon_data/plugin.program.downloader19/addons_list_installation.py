﻿def installation():
    if addons_list_installation_version > int(setting('installationversion')):
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py')
        xbmc.sleep(2000)
        
        # 🔒 Ανοίγουμε το κεντρικό Busy Box (Κλειδώνει την οθόνη του χρήστη)
        BG.create(Dialog_U12, Dialog_U6)
        xbmc.sleep(1000)
        
        BG.update(20, Dialog_U12, 'Έναρξη διαδικασίας λήψης...')
        
        # 🚀 Εκκίνηση του script εγκαταστάσεων
        xbmc.executebuiltin(Installation_startup)
        
        # Δίνουμε 2 δευτερόλεπτα αέρα για να προλάβει το script να ανάψει το Property στη μνήμη
        xbmc.sleep(2000) 
        
        # 🎯 ΤΟ ΝΕΟ ΦΡΕΝΟ (WINDOW PROPERTY LOCK):
        # Το service κοιτάει αν το Property 'InstallationRunning' στο Window 10000 είναι 'true'.
        # Θα μείνει εγκλωβισμένο εδώ μέσα και ΔΕΝ θα πάει στο επόμενο check, 
        # αν το script εγκαταστάσεων δεν τελειώσει και δεν σβήσει το property! (Μέγιστη αναμονή 4 λεπτά)
        wait_seconds = 0
        while xbmcgui.Window(10000).getProperty('InstallationRunning') == 'true' and wait_seconds < 240:
            xbmc.sleep(1000) # Έλεγχος ανά 1 δευτερόλεπτο
            wait_seconds += 1
            
            # Dynamic ενημέρωση στην οθόνη για να βλέπει ο χρήστης την πρόοδο
            if wait_seconds % 5 == 0:
                BG.update(30 + (wait_seconds // 4), Dialog_U12, f'Γίνεται λήψη νέων πρόσθετων... Παρακαλώ περιμένετε ({wait_seconds}δ.)')

        # Μόλις το script καθαρίσει το property, το loop σπάει και προχωράμε με απόλυτη ασφάλεια!
        BG.update(95, Dialog_U1, 'Η εγκατάσταση ολοκληρώθηκε επιτυχώς!')
        xbmc.sleep(2000)
        
        xbmc.executebuiltin(install_startup)
        setting_set('installationversion', str(addons_list_installation_version))
        xbmc.sleep(1000)
        
        BG.update(100, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.close() # 🔓 Τώρα κλείνει το κεντρικό Busy Box και το service συνεχίζει στα επόμενα checks!
