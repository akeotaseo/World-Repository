# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import threading
import hashlib
import json
import os
import shutil
import glob
import re
import urllib.request as urllib_utils
import urllib.parse as url_parse

temp_video_file = ""
ADDON_ID = "context.subtitles.autosniper"
SUB_EXTS = ("*.srt", "*.sub", "*.ass", "*.ssa")


def get_addon_dir():
    return os.path.dirname(os.path.abspath(__file__))


def get_file_hash(filepath):
    try:
        hasher = hashlib.md5()
        with open(filepath, 'rb') as f:
            hasher.update(f.read())
        return hasher.hexdigest()
    except Exception:
        return ""


def save_unique_subtitle(src_file, target_folder, final_name):
    src_hash = get_file_hash(src_file)
    if src_hash:
        for ext in SUB_EXTS:
            for existing in glob.glob(os.path.join(target_folder, ext)):
                if os.path.abspath(existing) == os.path.abspath(src_file):
                    continue
                if get_file_hash(existing) == src_hash:
                    return "duplicate", os.path.basename(existing)

    target_file = os.path.join(target_folder, final_name)
    if os.path.exists(target_file):
        name_part, ext_part = os.path.splitext(final_name)
        counter = 2
        while os.path.exists(os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")):
            counter += 1
        target_file = os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")

    try:
        shutil.copyfile(src_file, target_file)
    except Exception:
        shutil.move(src_file, target_file)
    return "saved", os.path.basename(target_file)


def get_addon_lang():
    lang_file = os.path.join(get_addon_dir(), 'lang_config.txt')
    if os.path.exists(lang_file):
        try:
            with open(lang_file, 'r', encoding='utf-8') as f:
                val = f.read().strip().lower()
                if val in ['el', 'en']:
                    return val
        except Exception:
            pass
    return "el"


def set_addon_lang(lang_code):
    lang_file = os.path.join(get_addon_dir(), 'lang_config.txt')
    try:
        with open(lang_file, 'w', encoding='utf-8') as f:
            f.write(lang_code)
    except Exception:
        pass


def check_first_run_language():
    lang_file = os.path.join(get_addon_dir(), 'lang_config.txt')
    if not os.path.exists(lang_file):
        dialog = xbmcgui.Dialog()
        options = [
            "Ελληνικά (Greek) - Επιλογή Ελληνικής γλώσσας μενού",
            "English (Αγγλικά) - Select English menu language"
        ]
        choice = dialog.select("Επιλογή Γλώσσας / Select Language", options)
        set_addon_lang("en" if choice == 1 else "el")


def clean_release_title(raw_release):
    if not raw_release:
        return ""
    clean_tags = re.sub(
        r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)[^\]]*\]',
        '',
        raw_release,
        flags=re.IGNORECASE
    )
    clean_tags = clean_tags.replace('\r', ' ').replace('\n', ' ')
    clean_tags = re.sub(r'\(\s*\)|\[\s*\]', '', clean_tags)
    clean_tags = re.sub(r'[\\/*?:"<>|]', '', clean_tags).strip()
    clean_tags = " ".join(clean_tags.split())
    clean_tags = re.sub(r'(?i)(?:[\.\s]+(?:srt|sub|ass|ssa|txt|el|en))+$', '', clean_tags).strip()
    if len(clean_tags) > 3 and not clean_tags.isdigit():
        return clean_tags
    return ""


def get_kodi_language():
    try:
        res = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"locale.language"},"id":1}'
        )
        data = json.loads(res)
        val = str(data.get('result', {}).get('value', '')).strip()
        if val and "en_gb" not in val.lower() and "en_us" not in val.lower():
            try:
                with open(os.path.join(get_addon_dir(), 'kodi_local_lang.txt'), 'w', encoding='utf-8') as f:
                    f.write(val)
            except Exception:
                pass
        return val
    except Exception:
        return ""


def get_saved_local_kodi_lang():
    local_file = os.path.join(get_addon_dir(), 'kodi_local_lang.txt')
    installed_non_en = []
    try:
        res = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Addons.GetAddons","params":{"type":"kodi.resource.language","enabled":true},"id":1}'
        )
        data = json.loads(res)
        for item in data.get('result', {}).get('addons', []):
            aid = item.get('addonid', '')
            if aid and "en_gb" not in aid.lower() and "en_us" not in aid.lower():
                path1 = xbmcvfs.translatePath(f"special://home/addons/{aid}")
                path2 = xbmcvfs.translatePath(f"special://xbmc/addons/{aid}")
                if os.path.exists(path1) or os.path.exists(path2):
                    installed_non_en.append(aid)
    except Exception:
        pass

    if not installed_non_en:
        if os.path.exists(local_file):
            try:
                os.remove(local_file)
            except Exception:
                pass
        return ""

    if os.path.exists(local_file):
        try:
            with open(local_file, 'r', encoding='utf-8') as f:
                saved = f.read().strip()
                if saved and saved in installed_non_en:
                    return saved
        except Exception:
            pass

    return installed_non_en[0]


def get_kodi_lang_display_name(locale_id, ui_lang):
    if not locale_id:
        return "Local" if ui_lang == "en" else "Τοπική"
    low = locale_id.lower()
    if "en_gb" in low or "en_us" in low:
        return "English"
    if "el_gr" in low:
        return "Greek" if ui_lang == "en" else "Ελληνικά"
    try:
        lang_addon = xbmcaddon.Addon(locale_id)
        name = lang_addon.getAddonInfo('name')
        if name:
            return name
    except Exception:
        pass
    short_code = locale_id.replace("resource.language.", "").upper()
    return short_code if short_code else ("Other" if ui_lang == "en" else "Άλλη Γλώσσα")


def set_kodi_language(target_locale):
    try:
        xbmc.executeJSONRPC(
            f'{{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{{"setting":"locale.language","value":"{target_locale}"}},"id":1}}'
        )
        xbmc.sleep(300)
        xbmc.executebuiltin('ReloadSkin()')
    except Exception:
        pass


def get_tmdbh_language():
    try:
        tmdbh_xml = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper/settings.xml')
        if xbmcvfs.exists(tmdbh_xml):
            with open(tmdbh_xml, 'r', encoding='utf-8') as f:
                content = f.read()
            m = re.search(r'<setting id="language"[^>]*>(.*?)</setting>', content)
            if m and m.group(1).strip():
                val = m.group(1).strip()
                if val != "18":
                    try:
                        with open(os.path.join(get_addon_dir(), 'tmdbh_local_lang.txt'), 'w', encoding='utf-8') as f:
                            f.write(val)
                    except Exception:
                        pass
                return val
    except Exception:
        pass
    return "12"


def get_saved_local_tmdbh_lang():
    local_file = os.path.join(get_addon_dir(), 'tmdbh_local_lang.txt')
    if os.path.exists(local_file):
        try:
            with open(local_file, 'r', encoding='utf-8') as f:
                saved = f.read().strip()
                if saved and saved != "18":
                    return saved
        except Exception:
            pass
    return "12"


def set_tmdbh_language(value):
    try:
        tmdbh_xml = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper/settings.xml')
        if not xbmcvfs.exists(tmdbh_xml):
            return False
        with open(tmdbh_xml, 'r', encoding='utf-8') as f:
            content = f.read()
        pattern = r'<setting id="language"[^>]*>.*?</setting>'
        new_setting = f'<setting id="language">{value}</setting>'
        if re.search(pattern, content):
            updated = re.sub(pattern, new_setting, content)
        else:
            updated = content.replace('</settings>', f'    {new_setting}\n</settings>')
        with open(tmdbh_xml, 'w', encoding='utf-8') as f:
            f.write(updated)
        return True
    except Exception:
        return False


def get_tmdbh_lang_display_name(tmdbh_code, saved_kodi_local, ui_lang):
    code = str(tmdbh_code).strip()
    if code == "18":
        return "English (18)"
    if code == "12":
        return "Ελληνικά (12)" if ui_lang == "el" else "Greek (12)"

    try:
        tmdbh_addon = xbmcaddon.Addon('plugin.video.themoviedb.helper')
        res_xml = os.path.join(tmdbh_addon.getAddonInfo('path'), 'resources', 'settings.xml')
        if os.path.exists(res_xml):
            with open(res_xml, 'r', encoding='utf-8') as f:
                xml_txt = f.read()
            m_block = re.search(r'<setting id="language"[^>]*>.*?</setting>', xml_txt, re.DOTALL)
            if m_block:
                m_opt = re.search(rf'<option label="([^"]+)">{re.escape(code)}</option>', m_block.group(0))
                if m_opt:
                    lbl = m_opt.group(1)
                    if lbl.isdigit():
                        lbl = tmdbh_addon.getLocalizedString(int(lbl)) or lbl
                    if lbl:
                        return f"{lbl} ({code})"
    except Exception:
        pass

    local_name = get_kodi_lang_display_name(saved_kodi_local, ui_lang)
    return f"{local_name} ({code})"


def show_language_settings_menu():
    dialog = xbmcgui.Dialog()
    while True:
        lang = get_addon_lang()
        addon_status = "Ελληνικά" if lang == "el" else "English"
        addon_next_name = "English" if lang == "el" else "Greek (Ελληνικά)"

        if lang == "el":
            title = "⇄  Ρυθμίσεις Γλώσσας"
            opts = [
                f"1. Γλώσσα Μενού Πρόσθετου: [COLOR orange]{addon_status}[/COLOR] (Σε {addon_next_name})",
                "2. Αλλαγή Γλώσσας Kodi & TMDb Helper [COLOR grey](Προαιρετικό)[/COLOR]"
            ]
        else:
            title = "⇄  Language Settings"
            opts = [
                f"1. Addon Menu Language: [COLOR orange]{addon_status}[/COLOR] (To {addon_next_name})",
                "2. Change Kodi & TMDb Helper Language [COLOR grey](Optional)[/COLOR]"
            ]

        choice = dialog.select(title, opts)
        if choice == -1:
            break
        elif choice == 0:
            new_l = "en" if lang == "el" else "el"
            set_addon_lang(new_l)
            msg = "Menu language switched to English!" if new_l == "en" else "Η γλώσσα μενού άλλαξε σε Ελληνικά!"
            dialog.notification("AutoSniper", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        elif choice == 1:
            if lang == "el":
                info_t = "Προαιρετική Αλλαγή Γλώσσας"
                info_m = (
                    "Προαιρετικά, μπορείτε να αλλάξετε τη γλώσσα του Kodi και του TMDb Helper στα Αγγλικά "
                    "για ακόμα καλύτερα και πιο άμεσα αποτελέσματα σε όλους τους παρόχους υποτίτλων."
                )
            else:
                info_t = "Optional Language Switch"
                info_m = (
                    "Optionally, you can switch Kodi and TMDb Helper to English "
                    "for even better and faster subtitle search results across all providers."
                )
            dialog.ok(info_t, info_m)
            show_kodi_tmdbh_language_submenu()


def show_kodi_tmdbh_language_submenu():
    dialog = xbmcgui.Dialog()
    while True:
        lang = get_addon_lang()
        kodi_loc = get_kodi_language()
        saved_kodi_local = get_saved_local_kodi_lang()
        tmdbh_loc = get_tmdbh_language()
        saved_tmdbh_local = get_saved_local_tmdbh_lang()

        is_kodi_english = ("en_gb" in kodi_loc.lower() or "en_us" in kodi_loc.lower())

        if is_kodi_english and not saved_kodi_local:
            kodi_status = "English"
            kodi_action_lbl = "Only English installed - Install another" if lang == "en" else "Μόνο Αγγλικά - Εγκατάσταση άλλης"
        else:
            kodi_status = "English" if is_kodi_english else get_kodi_lang_display_name(kodi_loc, lang)
            kodi_next_name = get_kodi_lang_display_name(saved_kodi_local, lang) if is_kodi_english else "English"
            kodi_action_lbl = f"To {kodi_next_name} + Reload" if lang == "en" else f"Σε {kodi_next_name} + Reload"

        tmdbh_status = get_tmdbh_lang_display_name(tmdbh_loc, saved_kodi_local, lang)
        tmdbh_next_code = "18" if tmdbh_loc != "18" else saved_tmdbh_local
        tmdbh_next_raw = get_tmdbh_lang_display_name(tmdbh_next_code, saved_kodi_local, lang)
        tmdbh_next_name = "English" if tmdbh_next_code == "18" else tmdbh_next_raw.rsplit(" (", 1)

        if lang == "el":
            title = "⇄  Γλώσσα Kodi & TMDb Helper (Προαιρετικό)"
            opts = [
                f"1. Γλώσσα Μενού Kodi: [COLOR orange]{kodi_status}[/COLOR] ({kodi_action_lbl})",
                f"2. Γλώσσα Μενού TMDb Helper: [COLOR orange]{tmdbh_status}[/COLOR] (Σε {tmdbh_next_name} + Reload)"
            ]
        else:
            title = "⇄  Kodi & TMDb Helper Language (Optional)"
            opts = [
                f"1. Kodi Interface Language: [COLOR orange]{kodi_status}[/COLOR] ({kodi_action_lbl})",
                f"2. TMDb Helper Language: [COLOR orange]{tmdbh_status}[/COLOR] (To {tmdbh_next_name} + Reload)"
            ]

        choice = dialog.select(title, opts)
        if choice == -1:
            break
        elif choice == 0:
            if is_kodi_english and not saved_kodi_local:
                if lang == "en":
                    q_t = "Install Language"
                    q_m = "Only English is currently installed in Kodi.\nWould you like to open Kodi Regional Settings to install another language?"
                else:
                    q_t = "Εγκατάσταση Γλώσσας"
                    q_m = "Στο Kodi είναι εγκατεστημένα μόνο τα Αγγλικά.\nΘέλετε να ανοίξουν οι Ρυθμίσεις Περιοχής του Kodi για να εγκαταστήσετε μια άλλη γλώσσα;"
                if dialog.yesno(q_t, q_m):
                    xbmc.executebuiltin('ActivateWindow(interfacesettings,regional)')
                    xbmc.sleep(300)
                    xbmc.executebuiltin('SetFocus(5)')
                    xbmc.executebuiltin('SetFocus(-179)')
                    xbmc.sleep(150)
                    xbmc.executebuiltin('Action(Select)')
                    break
                continue

            if is_kodi_english:
                target_loc = saved_kodi_local
                target_label = get_kodi_lang_display_name(target_loc, lang)
            else:
                target_loc = "resource.language.en_gb"
                target_label = "English"
            set_kodi_language(target_loc)
            msg = f"Kodi language changed to {target_label}!" if lang == "en" else f"Η γλώσσα του Kodi άλλαξε σε {target_label}!"
            dialog.notification("AutoSniper", msg, xbmcgui.NOTIFICATION_INFO, 2500)
        elif choice == 1:
            new_t = "18" if tmdbh_loc != "18" else saved_tmdbh_local
            ok = set_tmdbh_language(new_t)
            if ok:
                xbmc.sleep(200)
                xbmc.executebuiltin('ReloadSkin()')
                msg = f"TMDb Helper language set to ({new_t})!" if lang == "en" else f"Η γλώσσα TMDb Helper ορίστηκε σε ({new_t})!"
                dialog.notification("AutoSniper", msg, xbmcgui.NOTIFICATION_INFO, 2500)
            else:
                err = "TMDb Helper settings.xml not found." if lang == "en" else "Δεν βρέθηκε το settings.xml του TMDb Helper."
                dialog.notification("AutoSniper", err, xbmcgui.NOTIFICATION_ERROR, 2500)


def get_storage_path():
    addon_dir = get_addon_dir()
    config_file = os.path.join(addon_dir, 'path_config.txt')
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                saved_path = f.read().strip()
                if saved_path:
                    translated_path = xbmcvfs.translatePath(saved_path)
                    if not os.path.exists(translated_path):
                        os.makedirs(translated_path)
                    return translated_path
        except Exception:
            pass
    default_path = os.path.join(addon_dir, 'download_subtitles')
    if not os.path.exists(default_path):
        os.makedirs(default_path)
    return default_path


def set_custom_storage_path():
    lang = get_addon_lang()
    dialog = xbmcgui.Dialog()
    current_path = get_storage_path()
    prompt = "Select Subtitles Storage Folder" if lang == "en" else "Επιλογή Φακέλου Αποθήκευσης Υποτίτλων"
    new_path = dialog.browse(0, prompt, "video", "", False, False, current_path)
    if new_path and new_path != current_path:
        config_file = os.path.join(get_addon_dir(), 'path_config.txt')
        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                f.write(new_path)
            msg = "New storage folder set!" if lang == "en" else "Ο νέος φάκελος ορίστηκε!"
            dialog.notification("Subtitle Manager", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception:
            err = "Error saving folder path." if lang == "en" else "Σφάλμα κατά την αποθήκευση."
            dialog.notification("Subtitle Manager", err, xbmcgui.NOTIFICATION_ERROR, 2000)


def reset_storage_path_to_default():
    lang = get_addon_lang()
    dialog = xbmcgui.Dialog()
    addon_dir = get_addon_dir()
    config_file = os.path.join(addon_dir, 'path_config.txt')

    q_title = "Confirmation" if lang == "en" else "Επιβεβαίωση"
    q_text = "Reset storage path to default folder?" if lang == "en" else "Θέλετε να επαναφέρετε την προεπιλεγμένη διαδρομή αποθήκευσης;"
    if dialog.yesno(q_title, q_text):
        if os.path.exists(config_file):
            try:
                os.remove(config_file)
            except Exception:
                pass
        default_path = os.path.join(addon_dir, 'download_subtitles')
        if not os.path.exists(default_path):
            os.makedirs(default_path)
        msg = "Reset to default folder completed!" if lang == "en" else "Έγινε επαναφορά στον προεπιλεγμένο φάκελο!"
        dialog.notification("Subtitle Manager", msg, xbmcgui.NOTIFICATION_INFO, 2500)


def run_os_checker(movie_title, movie_year, imdb_id, season, episode):
    try:
        xbmcgui.Window(10000).clearProperty('tmdbmovies.has_el_sub')
        xbmcgui.Window(10000).clearProperty('tmdbmovies.has_en_sub')
        if not movie_title:
            return
        if imdb_id and str(imdb_id).startswith('tt'):
            numeric_id = str(imdb_id).replace('tt', '')
            is_tv = season and episode and str(season) != '0' and str(episode) != '0'
            query_path = f"episode-{episode}/imdbid-{numeric_id}/season-{season}" if is_tv else f"imdbid-{numeric_id}"
        else:
            query_clean = url_parse.quote(movie_title)
            query_path = f"query-{query_clean}/year-{movie_year}" if movie_year else f"query-{query_clean}"

        url = f"https://opensubtitles.org{query_path}"
        req = urllib_utils.Request(url, headers={'User-Agent': 'HotSubtitlesV1'})
        response = urllib_utils.urlopen(req, timeout=5.0)
        if response.getcode() == 200:
            data = json.loads(response.read().decode('utf-8'))
            if isinstance(data, list):
                found_el, found_en = False, False
                norm_lang = {
                    'ell': 'el', 'gre': 'el', 'el': 'el', 'gr': 'el', 'greek': 'el',
                    'eng': 'en', 'en': 'en', 'english': 'en'
                }
                for item in data:
                    lang_resolved = (
                        norm_lang.get(str(item.get('ISO639', '')).lower().strip())
                        or norm_lang.get(str(item.get('SubLanguageID', '')).lower().strip())
                    )
                    if lang_resolved == 'el':
                        found_el = True
                    if lang_resolved == 'en':
                        found_en = True
                    if found_el and found_en:
                        break
                if found_el:
                    xbmcgui.Window(10000).setProperty('tmdbmovies.has_el_sub', 'true')
                if found_en:
                    xbmcgui.Window(10000).setProperty('tmdbmovies.has_en_sub', 'true')
    except Exception:
        pass


def auto_stop_and_move(clean_filename, focus_container="", focus_item=""):
    global temp_video_file
    lang = get_addon_lang()
    addon_dir = get_addon_dir()
    icon_path = os.path.join(addon_dir, 'icon.png')
    target_folder = get_storage_path()
    searching_msg = "Searching for subtitles..." if lang == "en" else "Αναζήτηση υποτίτλων..."
    play_after = False

    while True:
        xbmc.sleep(350)

        xbmcgui.Dialog().notification(
            "AutoSniper Subtitles",
            searching_msg,
            icon_path,
            300000,
            False
        )

        release_name = ""
        while xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
            if not xbmc.getCondVisibility('Window.IsVisible(notification)'):
                xbmcgui.Dialog().notification(
                    "AutoSniper Subtitles",
                    searching_msg,
                    icon_path,
                    300000,
                    False
                )

            candidates = [
                xbmc.getInfoLabel('Container(120).ListItem.Label2'),
                xbmc.getInfoLabel('ListItem.Label2'),
                xbmc.getInfoLabel('Container(120).ListItem.Label'),
                xbmc.getInfoLabel('ListItem.Label')
            ]
            for cand in candidates:
                if not cand or 'ListItem' in cand:
                    continue
                clean_c = re.sub(
                    r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)[^\]]*\]',
                    '',
                    cand,
                    flags=re.IGNORECASE
                ).replace('\r', ' ').replace('\n', ' ').strip()
                if clean_c and len(clean_c) > 4 and clean_c.lower() not in ['greek', 'english', 'el', 'en', 'ελληνικά', 'αγγλικά']:
                    release_name = clean_c
                    break
            xbmc.sleep(100)

        xbmc.executebuiltin('Dialog.Close(notification, true)')

        downloaded_subs = []
        for _ in range(8):
            for ext in SUB_EXTS:
                downloaded_subs.extend(glob.glob(os.path.join(addon_dir, ext)))
            if downloaded_subs:
                xbmc.sleep(250)
                downloaded_subs = []
                for ext in SUB_EXTS:
                    downloaded_subs.extend(glob.glob(os.path.join(addon_dir, ext)))
                break
            xbmc.sleep(200)

        if not downloaded_subs:
            break

        downloaded_subs.sort(key=lambda x: (".el." in os.path.basename(x).lower(), os.path.getmtime(x)), reverse=True)
        sub_file = next(iter(downloaded_subs), "")
        base_name = os.path.basename(sub_file)
        base_no_ext, ext_raw = os.path.splitext(base_name)
        file_ext = ext_raw.lower() or ".srt"

        chosen_title = ""
        if release_name and release_name.lower() not in ['greek', 'english']:
            chosen_title = clean_release_title(release_name)

        generic_names = ['subtitles.el', 'subtitles.en', 'subtitles', 'temp', clean_filename.lower()]
        if not chosen_title and base_no_ext.lower() not in generic_names and len(base_no_ext) > 3:
            clean_file = re.sub(r'[\\/*?:"<>|]', '', base_no_ext).strip()
            clean_file = re.sub(r'(?i)(?:[\.\s]+(?:el|en))$', '', clean_file).strip()
            if len(clean_file) > 3:
                chosen_title = clean_file

        if not chosen_title:
            chosen_title = clean_filename

        lang_part = ""
        if ".el." in base_name.lower() or "greek" in base_name.lower() or base_name.lower().endswith(f'.el{file_ext}'):
            lang_part = ".el"
        elif ".en." in base_name.lower() or "english" in base_name.lower() or base_name.lower().endswith(f'.en{file_ext}'):
            lang_part = ".en"
        elif chosen_title == clean_filename:
            lang_part = ".el" if "el" in base_name.lower() or "greek" in base_name.lower() else ".en"

        final_name = f"{chosen_title}{lang_part}{file_ext}"

        sub_status = "saved"
        try:
            sub_status, _ = save_unique_subtitle(sub_file, target_folder, final_name)
        except Exception:
            pass

        keep_files = {
            "addon.py", "addon.xml", "icon.png", "fanart.jpg", "fake.mp4",
            "path_config.txt", "lang_config.txt", "kodi_local_lang.txt", "tmdbh_local_lang.txt",
            "osd_search.py", "changelog.txt", "license.txt", os.path.basename(temp_video_file).lower()
        }
        for item in os.listdir(addon_dir):
            item_path = os.path.join(addon_dir, item)
            if os.path.isfile(item_path) and item.lower() not in keep_files:
                try:
                    os.remove(item_path)
                except Exception:
                    pass

        xbmc.executebuiltin('PlayerControl(RepeatOne)')
        if not xbmc.getCondVisibility('Player.Paused'):
            xbmc.executebuiltin('PlayerControl(Pause)')

        if lang == "en":
            sel_title = (
                "Identical subtitle already exists! Download another?"
                if sub_status == "duplicate"
                else "Subtitle saved! Download another one?"
            )
            sel_opts = [
                "[COLOR lime]✔  Yes, download another subtitle[/COLOR]",
                "✖  No, finish",
                "[COLOR deepskyblue]▶  Open Movie / Episode (Select Player)[/COLOR]"
            ]
        else:
            sel_title = (
                "Ίδιος υπότιτλος υπάρχει ήδη! Κατέβασμα και άλλου;"
                if sub_status == "duplicate"
                else "Ο υπότιτλος αποθηκεύτηκε! Κατέβασμα και άλλου;"
            )
            sel_opts = [
                "[COLOR lime]✔  Ναι, κατέβασμα και άλλου υπότιτλου[/COLOR]",
                "✖  Όχι, ολοκλήρωση",
                "[COLOR deepskyblue]▶  Άνοιγμα Ταινίας / Επεισοδίου (Επιλογή Player)[/COLOR]"
            ]

        choice = xbmcgui.Dialog().select(sel_title, sel_opts)

        if choice == 0:
            xbmc.executebuiltin('PlayerControl(RepeatOne)')
            if not xbmc.getCondVisibility('Player.Paused'):
                xbmc.executebuiltin('PlayerControl(Pause)')
            xbmc.executebuiltin('ActivateWindow(subtitlesearch)')
            continue
        elif choice == 2:
            play_after = True
            break
        else:
            break

    xbmc.executebuiltin('PlayerControl(RepeatOff)')
    if xbmc.Player().isPlaying():
        xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.sleep(300)

    for _ in range(3):
        all_mp4_files = glob.glob(os.path.join(addon_dir, "*.mp4"))
        for mp4_file in all_mp4_files:
            if os.path.basename(mp4_file).lower().strip() != "fake.mp4":
                try:
                    os.remove(mp4_file)
                except Exception:
                    pass
        xbmc.sleep(200)

    if play_after:
        launch_msg = (
            "Opening item — select your preferred player/source..."
            if lang == "en"
            else "Άνοιγμα στοιχείου — επιλέξτε player / πηγή..."
        )
        xbmcgui.Dialog().notification("AutoSniper", launch_msg, icon_path, 3000, False)
        xbmc.sleep(600)
        if focus_container and focus_container.isdigit():
            xbmc.executebuiltin(f'SetFocus({focus_container})')
            xbmc.sleep(150)
        xbmc.executebuiltin('Action(Select)')



def show_sub_manager_menu(clean_filename, target_folder, global_mode=False):
    lang = get_addon_lang()
    dialog = xbmcgui.Dialog()
    sort_mode = "date"

    existing_subs = []
    for ext in ("*.srt", "*.sub", "*.ass", "*.ssa", "*.idx"):
        existing_subs.extend(glob.glob(os.path.join(target_folder, ext)))

    movie_subs = existing_subs
    menu_title = "Manage Subtitles (All Files)" if lang == "en" else "Διαχείριση Υποτίτλων (Όλα τα Αρχεία)"

    while True:
        if not movie_subs:
            empty_msg = "No local subtitles found." if lang == "en" else "Δεν βρέθηκαν τοπικοί υπότιτλοι."
            dialog.notification("Subtitle Manager", empty_msg, xbmcgui.NOTIFICATION_INFO, 2000)
            break

        if sort_mode == "date":
            movie_subs.sort(key=os.path.getmtime, reverse=True)
            sort_lbl = "[COLOR deepskyblue][B]⇅  Sort: Date / Newest (Switch to A-Z)[/B][/COLOR]" if lang == "en" else "[COLOR deepskyblue][B]⇅  Ταξινόμηση: Χρονολογικά (Αλλαγή σε Αλφαβητικά)[/B][/COLOR]"
        else:
            movie_subs.sort(key=lambda x: re.sub(r'^\[[^\]]+\]\s*', '', os.path.basename(x)).strip().lower())
            sort_lbl = "[COLOR deepskyblue][B]⇅  Sort: Alphabetical A-Z (Switch to Date)[/B][/COLOR]" if lang == "en" else "[COLOR deepskyblue][B]⇅  Ταξινόμηση: Αλφαβητικά (Αλλαγή σε Χρονολογικά)[/B][/COLOR]"

        clear_lbl = "[COLOR red][B]✖  [ Clear All Files in Folder ][/B][/COLOR]" if lang == "en" else "[COLOR red][B]✖  [ Καθαρισμός Όλων των Αρχείων στον Φάκελο ][/B][/COLOR]"
        del_prefix = "[COLOR red]─  Delete: [/COLOR]" if lang == "en" else "[COLOR red]─  Διαγραφή: [/COLOR]"

        options = [clear_lbl, sort_lbl]
        for sub in movie_subs:
            sub_name = os.path.basename(sub)
            m_prov = re.match(r'^(\[[^\]]+\]\s*)(.*)$', sub_name)
            if m_prov:
                prov_tag, rest_title = m_prov.group(1), m_prov.group(2)
                options.append(f"{del_prefix}[COLOR white]{prov_tag}[/COLOR][COLOR orange][B]{rest_title}[/B][/COLOR]")
            else:
                options.append(f"{del_prefix}[COLOR orange][B]{sub_name}[/B][/COLOR]")

        choice = dialog.select(menu_title, options)
        if choice == -1:
            break
        elif choice == 0:
            c_title = "Confirm Cleanup" if lang == "en" else "Επιβεβαίωση Καθαρισμού"
            c_text = "Are you sure you want to delete ALL subtitles from the folder?" if lang == "en" else "Θέλετε να αδειάσετε ΟΛΟΚΛΗΡΟ τον φάκελο από όλους τους υπότιτλους;"
            if dialog.yesno(c_title, c_text):
                for sub in movie_subs:
                    try:
                        os.remove(sub)
                    except Exception:
                        pass
                done_msg = "All files deleted!" if lang == "en" else "Όλα τα αρχεία διαγράφηκαν!"
                dialog.notification("Subtitle Manager", done_msg, xbmcgui.NOTIFICATION_INFO, 2000)
                break
        elif choice == 1:
            sort_mode = "alpha" if sort_mode == "date" else "date"
            continue
        elif choice > 1:
            target_sub = movie_subs[choice - 2]
            try:
                if os.path.exists(target_sub):
                    os.remove(target_sub)
                if target_sub in movie_subs:
                    movie_subs.remove(target_sub)
                del_msg = "Subtitle deleted!" if lang == "en" else "Ο υπότιτλος διαγράφηκε!"
                dialog.notification("Subtitle Manager", del_msg, xbmcgui.NOTIFICATION_INFO, 1500)
            except Exception:
                pass
            xbmc.sleep(200)

def open_browser_subs(search_query):
    lang = get_addon_lang()
    dialog = xbmcgui.Dialog()
    names = [
        "[B][COLOR white]Subs4Free (Movies)[/COLOR][/B]" if lang == "en" else "[B][COLOR white]Subs4Free (Ταινίες)[/COLOR][/B]",
        "[B][COLOR white]Subs4Series (TV Shows)[/COLOR][/B]" if lang == "en" else "[B][COLOR white]Subs4Series (Σειρές)[/COLOR][/B]",
        "[B][COLOR white]GreekSubs[/COLOR][/B]",
        "[B][COLOR white]OpenSubtitles.org[/COLOR][/B]",
        "[B][COLOR white]Subtitles.gr[/COLOR][/B]",
        "[B][COLOR white]TVSubtitles[/COLOR][/B]",
        "[B][COLOR white]YTS-Subs[/COLOR][/B]"
    ]
    urls = [
        "https://subs4free.info",
        "https://subs4series.com",
        "https://greeksubs.net",
        "https://opensubtitles.org",
        "http://subtitles.gr",
        "https://tvsubtitles.net",
        "https://yts-subs.com"
    ]

    b_title = f"Browser Search: {search_query}" if lang == "en" else f"Αναζήτηση σε Browser: {search_query}"
    choice = dialog.select(b_title, names)
    if choice < 0:
        return

    selected_url = urls[choice]

    if search_query and xbmc.getCondVisibility('system.platform.windows'):
        try:
            import subprocess
            subprocess.run(['clip'], input=search_query.strip().encode('utf-16le'), check=True)
        except Exception:
            pass

    clip_msg = "Title copied! Download file -> LocalSubtitle" if lang == "en" else "Ο τίτλος αντιγράφηκε! Κατεβάστε το αρχείο -> LocalSubtitle"
    dialog.notification("Browser Search", clip_msg, xbmcgui.NOTIFICATION_INFO, 4500)

    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin(f'StartAndroidActivity(,android.intent.action.VIEW,,{selected_url})')
    elif xbmc.getCondVisibility('system.platform.windows'):
        try:
            os.startfile(selected_url)
        except Exception:
            import webbrowser
            webbrowser.open(selected_url)
    else:
        import webbrowser
        webbrowser.open(selected_url)


def find_active_subtitles_dialog_xml():
    skin_base = xbmcvfs.translatePath('special://skin/')
    for sub in ['xml', '1080i', '720p', '1080p']:
        candidate = os.path.join(skin_base, sub, 'DialogSubtitles.xml')
        if os.path.exists(candidate):
            return candidate
    for root, dirs, files in os.walk(skin_base):
        if 'DialogSubtitles.xml' in files:
            return os.path.join(root, 'DialogSubtitles.xml')
    return ""


def is_sub_dialog_hook_installed():
    dlg_path = find_active_subtitles_dialog_xml()
    if not dlg_path:
        return False
    try:
        with open(dlg_path, 'r', encoding='utf-8') as f:
            return 'osd_search.py' in f.read()
    except Exception:
        return False


def toggle_sub_dialog_hook():
    lang = get_addon_lang()
    dialog = xbmcgui.Dialog()
    dlg_path = find_active_subtitles_dialog_xml()

    if not dlg_path:
        err = "DialogSubtitles.xml not found in active skin." if lang == "en" else "Δεν βρέθηκε το DialogSubtitles.xml στο ενεργό Skin."
        dialog.notification("AutoSniper", err, xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    bak_path = dlg_path + ".autosniper.bak"
    target_cmd = "RunScript(special://home/addons/context.subtitles.autosniper/osd_search.py)"
    installed = is_sub_dialog_hook_installed()

    if not installed:
        if lang == "en":
            q_t = "Enable Auto-Save in Subtitles Dialog"
            q_m = (
                "This will update your active skin's DialogSubtitles.xml so that clicking 'Search / Download' inside the Subtitles dialog automatically saves subtitles with their real release name.\n"
                "(A backup of your original DialogSubtitles.xml will be created automatically).\n\n"
                "Do you want to proceed?"
            )
        else:
            q_t = "Ενεργοποίηση Auto-Save στο Παράθυρο Υποτίτλων"
            q_m = (
                "Θα τροποποιηθεί το DialogSubtitles.xml του ενεργού Skin ώστε όταν πατάτε 'Αναζήτηση / Λήψη' στο παράθυρο υποτίτλων, να αποθηκεύονται αυτόματα με την πραγματική τους ονομασία.\n"
                "(Θα κρατηθεί αυτόματα αντίγραφο ασφαλείας του αρχικού αρχείου).\n\n"
                "Θέλετε να προχωρήσετε;"
            )
        if not dialog.yesno(q_t, q_m):
            return

        try:
            with open(dlg_path, 'r', encoding='utf-8') as f:
                content = f.read()

            if not os.path.exists(bak_path):
                with open(bak_path, 'w', encoding='utf-8') as f:
                    f.write(content)

            new_content, count = re.subn(
                r'(?i)<onclick>\s*ActivateWindow\(\s*SubtitleSearch[^)]*\)\s*</onclick>',
                f'<onclick>{target_cmd}</onclick>',
                content
            )

            if count == 0:
                pattern_150 = r'(<control\b[^>]*\bid=["\']150["\'][^>]*>)(.*?)(</control>)'

                def add_onclick_to_150(match):
                    open_tag, inner, close_tag = match.group(1), match.group(2), match.group(3)
                    if 'osd_search.py' not in inner:
                        inner = inner + f'\n\t\t\t<onclick>{target_cmd}</onclick>'
                    return open_tag + inner + close_tag

                new_content, count = re.subn(pattern_150, add_onclick_to_150, content, flags=re.DOTALL)

            if count == 0:
                not_found = "Search button (id=150) not found in DialogSubtitles.xml." if lang == "en" else "Δεν βρέθηκε το κουμπί αναζήτησης (id=150) στο DialogSubtitles.xml."
                dialog.notification("AutoSniper", not_found, xbmcgui.NOTIFICATION_WARNING, 3000)
                return

            with open(dlg_path, 'w', encoding='utf-8') as f:
                f.write(new_content)

            xbmc.sleep(200)
            xbmc.executebuiltin('ReloadSkin()')
            ok_msg = "Subtitles Dialog Auto-Save enabled & Skin reloaded!" if lang == "en" else "Ενεργοποιήθηκε στο Παράθυρο Υποτίτλων & έγινε Reload Skin!"
            dialog.notification("AutoSniper", ok_msg, xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            dialog.notification("AutoSniper", f"Error: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 3000)
    else:
        if lang == "en":
            q_t = "Restore Default Subtitles Dialog"
            q_m = "Subtitles Dialog Auto-Save is currently active.\nWould you like to restore the original DialogSubtitles.xml?"
        else:
            q_t = "Επαναφορά Αρχικού Παραθύρου Υποτίτλων"
            q_m = "Η αυτόματη αποθήκευση στο Παράθυρο Υποτίτλων είναι ήδη ενεργή.\nΘέλετε να επαναφέρετε το αρχικό DialogSubtitles.xml;"
        if not dialog.yesno(q_t, q_m):
            return

        try:
            if os.path.exists(bak_path):
                shutil.copyfile(bak_path, dlg_path)
                os.remove(bak_path)
            else:
                with open(dlg_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                restored = re.sub(rf'\s*<onclick>{re.escape(target_cmd)}</onclick>', '', content)
                with open(dlg_path, 'w', encoding='utf-8') as f:
                    f.write(restored)

            xbmc.sleep(200)
            xbmc.executebuiltin('ReloadSkin()')
            ok_msg = "Original DialogSubtitles.xml restored!" if lang == "en" else "Έγινε επαναφορά του αρχικού DialogSubtitles.xml!"
            dialog.notification("AutoSniper", ok_msg, xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            dialog.notification("AutoSniper", f"Error: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 3000)


def show_addon_info():
    lang = get_addon_lang()
    dialog = xbmcgui.Dialog()
    active_folder_path = get_storage_path()

    if lang == "en":
        info_title = "Information & User Guide"
        info_text = (
            "[B][COLOR orange]AutoSniper Subtitle Manager[/COLOR][/B]\n\n"
            "[B]Why Use AutoSniper? (Purpose of the Addon):[/B]\n"
            "This addon allows you to download subtitles in their original filename/release format [B]before[/B] or [B]during[/B] video playback. Especially for TV shows—where multiple video releases exist (e.g. WEB-DL, BluRay, HDTV)—knowing the exact subtitle release you downloaded helps you pick the matching video stream for 100% synchronization, and load it via: Subtitles -> LocalSubtitle -> Browse.\n\n"
            "[B]1. Automatic Download & Save (Before Playback):[/B]\n"
            "Select 'Search & Download Subtitles' from the context menu to search across all providers. Once you click a subtitle, it is automatically saved to your download folder with its original clean filename. You can also download multiple subtitles in a row.\n\n"
            "[B]2. In-Playback Auto-Save (Subtitles Dialog Integration):[/B]\n"
            "From the addon's Management & Settings menu (under Programs / Add-ons), you can enable [COLOR lime]Auto-Save in Subtitles Dialog[/COLOR]. This safely patches your active skin's DialogSubtitles.xml (creating an automatic [COLOR yellow].autosniper.bak[/COLOR] backup) so that downloading any subtitle during playback automatically saves a copy in your storage folder with its clean release name. You can restore the original skin file anytime with one click.\n\n"
            "[B]3. If no subtitle is found:[/B]\n"
            "Try switching services from the subtitle services menu ([COLOR orange]a4kSubtitles  Subtitles.gr  Greek Subs[/COLOR]).\n\n"
            "[B]4. Browser Search (Last Resort):[/B]\n"
            "Opens external subtitle websites in your browser and automatically copies the movie/show title to your clipboard (press Paste / Ctrl+V). After downloading the subtitle file, load it inside the video via: Subtitles -> LocalSubtitle -> Browse.\n\n"
            "[B]5. Storage Folder Location & Change:[/B]\n"
            "From 'Set Storage Folder' you can choose any custom folder.\n"
            "• [B]Default Folder:[/B]\n"
            "[COLOR yellow]addons/context.subtitles.autosniper/download_subtitles[/COLOR]\n"
            "• [B]Active Storage Folder:[/B]\n"
            f"[COLOR yellow]{active_folder_path}[/COLOR]\n\n"
            "[B]6. Management & Cleanup:[/B]\n"
            "From 'Manage / Delete Subtitles' you can delete individual files or empty the entire storage folder.\n\n"
            "[B]7. Language Settings (Addon / Optional Kodi & TMDb Helper):[/B]\n"
            "From 'Change Language', you can switch the Addon's own menu language between Greek and English, or optionally open the Kodi & TMDb Helper language switcher to set them to English for even better results across all subtitle providers."

        )
    else:
        info_title = "Πληροφορίες & Οδηγίες Χρήσης"
        info_text = (
            "[B][COLOR orange]AutoSniper Subtitle Manager[/COLOR][/B]\n\n"
            "[B]Σκοπός & Χρησιμότητα του Πρόσθετου:[/B]\n"
            "Το πρόσθετο δημιουργήθηκε ώστε να κατεβάζετε τους υπότιτλους στην αυθεντική τους ονομασία (release) [B]πριν[/B] ή [B]κατά τη διάρκεια[/B] της αναπαραγωγής. Κυρίως στις σειρές—όπου υπάρχουν πολλές διαφορετικές εκδόσεις βίντεο (π.χ. WEB-DL, BluRay, HDTV)—γνωρίζοντας ακριβώς ποια έκδοση υπότιτλου κατεβάσατε, μπορείτε να επιλέξετε το αντίστοιχο αρχείο αναπαραγωγής για απόλυτο συγχρονισμό και έπειτα να φορτώσετε τον υπότιτλο μέσα από το μενού της ταινίας: Υπότιτλοι -> LocalSubtitle -> Browse.\n\n"
            "[B]1. Αυτόματη Λήψη & Αποθήκευση (Πριν την Αναπαραγωγή):[/B]\n"
            "Επιλέξτε 'Αναζήτηση & Λήψη Υποτίτλων' από το μενού περιβάλλοντος για να ψάξετε σε όλους τους παρόχους. Μόλις πατήσετε έναν υπότιτλο, αυτός αποθηκεύεται αυτόματα στον φάκελο λήψεων με την αυθεντική του ονομασία. Μπορείτε να κατεβάσετε και 2ο ή 3ο υπότιτλο στη σειρά.\n\n"
            "[B]2. Αυτόματη Αποθήκευση κατά την Αναπαραγωγή (Subtitles Dialog):[/B]\n"
            "Μέσα από το μενού 'Διαχείριση & Ρυθμίσεις' του πρόσθετου (από τα Πρόσθετα), μπορείτε να ενεργοποιήσετε την επιλογή [COLOR lime]Αυτόματη Αποθήκευση στο Παράθυρο Υποτίτλων[/COLOR]. Η επιλογή αυτή προσαρμόζει με ασφάλεια το DialogSubtitles.xml του ενεργού Skin (κρατώντας αυτόματα αντίγραφο ασφαλείας [COLOR yellow].autosniper.bak[/COLOR]) ώστε όποιος υπότιτλος κατεβαίνει κατά την αναπαραγωγή να αποθηκεύεται αυτόματα στον φάκελό σας με την καθαρή ονομασία της έκδοσής του. Μπορείτε να επαναφέρετε το αρχικό αρχείο του Skin ανά πάσα στιγμή με ένα κλικ.\n\n"
            "[B]3. Αν δεν βρεθεί υπότιτλος:[/B]\n"
            "Δοκιμάστε να αλλάξετε υπηρεσία από το μενού υπηρεσιών ([COLOR orange]a4kSubtitles  Subtitles.gr  Greek Subs[/COLOR]).\n\n"
            "[B]4. Αναζήτηση μέσω Browser (Έσχατη Λύση):[/B]\n"
            "Ανοίγει εξωτερικά sites υποτίτλων στον browser σας και αντιγράφει αυτόματα τον τίτλο της ταινίας/σειράς στη μνήμη (πατήστε Επικόλληση / Ctrl+V στην αναζήτηση του site). Αφού κατεβάσετε το αρχείο υπότιτλου, φορτώστε το μέσα στην ταινία από: Υπότιτλοι -> LocalSubtitle -> Browse.\n\n"
            "[B]5. Αλλαγή & Θέση Φακέλου Αποθήκευσης:[/B]\n"
            "Από την επιλογή 'Ρύθμιση Φακέλου Αποθήκευσης' μπορείτε να επιλέξετε οποιονδήποτε δικό σας φάκελο.\n"
            "• [B]Προεπιλεγμένος Φάκελος:[/B]\n"
            "[COLOR yellow]addons/context.subtitles.autosniper/download_subtitles[/COLOR]\n"
            "• [B]Ενεργός Φάκελος Αποθήκευσης:[/B]\n"
            f"[COLOR yellow]{active_folder_path}[/COLOR]\n\n"
            "[B]6. Διαχείριση & Καθαρισμός:[/B]\n"
            "Από το μενού 'Διαχείριση / Διαγραφή Υποτίτλων' μπορείτε να σβήσετε μεμονωμένα αρχεία ή να αδειάσετε όλο τον φάκελο αποθήκευσης.\n\n"
            "[B]7. Ρυθμίσεις Γλώσσας (Πρόσθετο / Προαιρετικά Kodi & TMDb Helper):[/B]\n"
            "Από την επιλογή 'Αλλαγή Γλώσσας' μπορείτε να αλλάξετε τη γλώσσα μενού του ίδιου του πρόσθετου (Ελληνικά / English), ή προαιρετικά να ανοίξετε την αλλαγή γλώσσας για το Kodi και το TMDb Helper ώστε να τα γυρίσετε στα Αγγλικά για ακόμα καλύτερα αποτελέσματα σε όλους τους παρόχους υποτίτλων."

        )
    dialog.textviewer(info_title, info_text)


def show_management_menu(lang, target_folder):
    hook_active = is_sub_dialog_hook_installed()
    sub_dlg_en = "[COLOR lime]ON[/COLOR]" if hook_active else "[COLOR grey]OFF[/COLOR]"
    sub_dlg_el = "[COLOR lime]Ενεργό[/COLOR]" if hook_active else "[COLOR grey]Ανενεργό[/COLOR]"
    dialog = xbmcgui.Dialog()

    if lang == "en":
        app_title = "AutoSniper: Management & Settings"
        app_options = [
            "[COLOR orange]✖  Global Delete Subtitles (All Movies)[/COLOR]",
            "⚙  Change Storage Folder",
            "↩  Reset Default Storage Folder",
            "⇄  Change Language (Addon / Kodi / TMDb Helper)",
            f"▶  Auto-Save in Subtitles Dialog ({sub_dlg_en})",
            "ℹ  Information & User Guide"
        ]
    else:
        app_title = "AutoSniper: Διαχείριση & Ρυθμίσεις"
        app_options = [
            "[COLOR orange]✖  Καθολική Διαγραφή Υποτίτλων (Όλες οι Ταινίες)[/COLOR]",
            "⚙  Αλλαγή Φακέλου Αποθήκευσης",
            "↩  Επαναφορά Προεπιλεγμένου Φακέλου",
            "⇄  Αλλαγή Γλώσσας (Πρόσθετο / Kodi / TMDb Helper)",
            f"▶  Αυτόματη Αποθήκευση στο Παράθυρο Υποτίτλων ({sub_dlg_el})",
            "ℹ  Πληροφορίες & Οδηγίες Χρήσης"
        ]

    app_choice = dialog.select(app_title, app_options)
    if app_choice == 0:
        show_sub_manager_menu("", target_folder, global_mode=True)
    elif app_choice == 1:
        set_custom_storage_path()
    elif app_choice == 2:
        reset_storage_path_to_default()
    elif app_choice == 3:
        show_language_settings_menu()
    elif app_choice == 4:
        toggle_sub_dialog_hook()
    elif app_choice == 5:
        show_addon_info()



def main():
    global temp_video_file
    check_first_run_language()
    lang = get_addon_lang()
    target_folder = get_storage_path()

    win_id = xbmcgui.getCurrentWindowId()
    item_addon_id = xbmc.getInfoLabel('ListItem.Property(Addon.ID)')
    item_path = xbmc.getInfoLabel('ListItem.FolderPath')
    has_media_info = (
        xbmc.getInfoLabel('ListItem.IMDBNumber')
        or xbmc.getInfoLabel('ListItem.Season')
        or xbmc.getInfoLabel('ListItem.Year')
    )

    if (
        win_id in (10001, 10040)
        or (win_id == 10000 and not has_media_info)
        or item_addon_id == ADDON_ID
        or 'addons://' in item_path.lower()
        or ADDON_ID in item_path.lower()
    ):
        show_management_menu(lang, target_folder)
        return

    focus_container = xbmc.getInfoLabel('System.CurrentControlId')
    focus_item = xbmc.getInfoLabel(f'Container({focus_container}).CurrentItem') if focus_container else ""

    movie_title, season, episode, movie_year, imdb_id = "", "", "", "", ""
    raw_label = ""

    for _ in range(10):
        season = xbmc.getInfoLabel('ListItem.Season')
        episode = xbmc.getInfoLabel('ListItem.Episode')
        raw_label = xbmc.getInfoLabel('ListItem.Label') or xbmc.getInfoLabel('ListItem.Title')

        if (not season or not episode or season == '0' or episode == '0') and raw_label:
            m_ep = re.search(r'(?i)(?:s(\d+)[eε](\d+)|(\d+)x(\d+))', raw_label)
            if m_ep:
                season = m_ep.group(1) or m_ep.group(3)
                episode = m_ep.group(2) or m_ep.group(4)

        is_ep = season and episode and str(season) != '0' and str(episode) != '0'

        if is_ep:
            movie_title = (
                xbmc.getInfoLabel('ListItem.Property(tvshow.originaltitle)')
                or xbmc.getInfoLabel('Container.ShowTitle')
                or xbmc.getInfoLabel('ListItem.TVShowTitle')
                or xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
                or xbmc.getInfoLabel('ListItem.OriginalTitle')
                or raw_label
            )
        else:
            movie_title = (
                xbmc.getInfoLabel('ListItem.OriginalTitle')
                or xbmc.getInfoLabel('ListItem.Title')
                or raw_label
            )

        bad_names = ('blacklodge', 'tmdb helper', 'tmdbhelper', 'themoviedb', 'plugin://', 'autosniper', 'subtitle manager')
        if any(bad in movie_title.lower() for bad in bad_names):
            movie_title = ""
        elif re.match(r'(?i)^(σεζόν|season|επεισόδιο|episode)\s*\d+$', movie_title.strip()):
            movie_title = ""

        movie_year = xbmc.getInfoLabel('ListItem.Year')
        imdb_id = xbmc.getInfoLabel('ListItem.IMDBNumber')
        if not imdb_id or not str(imdb_id).startswith('tt'):
            imdb_id = xbmc.getInfoLabel('ListItem.Property(imdb_id)')
        if not imdb_id or not str(imdb_id).startswith('tt'):
            imdb_id = xbmc.getInfoLabel('ListItem.Property(tvshow.imdb_id)')

        if movie_title != '':
            xbmc.sleep(100)
            break
        xbmc.sleep(50)

    if not movie_title or ADDON_ID in movie_title:
        show_management_menu(lang, target_folder)
        return

    base_title = movie_title
    base_title = re.split(r'\s*[\-\–\:]\s*(?:s\d+[eε]\d+|\d+x\d+)', base_title, flags=re.IGNORECASE).pop(0).strip()
    base_title = re.sub(r'^\d+x\d+\s*[\.\-\:]*\s*', '', base_title).strip()
    base_title = re.sub(r'(?i)^(sezon|season|epei?sodio|episode)\s*\d+\s*[\.\-\:]*\s*', '', base_title).strip()
    base_title = re.sub(r'^(Σεζόν|Επεισόδιο)\s*\d+\s*[\.\-\:]*\s*', '', base_title).strip()

    is_tv_show = season and episode and str(season) != '0' and str(episode) != '0'
    search_string = f"{base_title} S{str(season).zfill(2)}E{str(episode).zfill(2)}" if is_tv_show else base_title
    search_string = " ".join(search_string.split()).strip()

    greek_to_english = {
        'α': 'a', 'β': 'b', 'γ': 'g', 'δ': 'd', 'ε': 'e', 'ζ': 'z', 'η': 'i', 'θ': 'th',
        'ι': 'i', 'κ': 'k', 'λ': 'l', 'μ': 'm', 'ν': 'n', 'ξ': 'x', 'ο': 'o', 'π': 'p',
        'ρ': 'r', 'σ': 's', 'ς': 's', 'τ': 't', 'υ': 'y', 'φ': 'f', 'χ': 'ch', 'ψ': 'ps', 'ω': 'o',
        'Α': 'A', 'Β': 'B', 'Γ': 'G', 'Δ': 'D', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'I', 'Θ': 'Th',
        'Ι': 'I', 'Κ': 'K', 'Λ': 'L', 'Μ': 'M', 'Ν': 'N', 'Ξ': 'X', 'Ο': 'O', 'Π': 'P',
        'Ρ': 'R', 'Σ': 'S', 'Τ': 'T', 'Υ': 'Y', 'Φ': 'F', 'Χ': 'Ch', 'Ψ': 'Ps', 'Ω': 'O',
        'ά': 'a', 'έ': 'e', 'ή': 'i', 'ί': 'i', 'ό': 'o', 'ύ': 'y', 'ώ': 'o'
    }
    clean_filename = "".join([greek_to_english.get(char, char) for char in search_string])
    clean_filename = re.sub(r'[^A-Za-z0-9\s\-_]', '', clean_filename)
    clean_filename = " ".join(clean_filename.split()).strip()
    if not clean_filename:
        clean_filename = "Series_Track"

    t = threading.Thread(target=run_os_checker, args=(base_title, movie_year, imdb_id, season, episode))
    t.daemon = True
    t.start()

    dialog = xbmcgui.Dialog()
    if lang == "en":
        main_title = f"Subtitles: {search_string}"
        main_options = [
            "[COLOR lime][B]▶  Search & Download Subtitles[/B][/COLOR]",
            "◈  Search via Browser (External Sites)",
            "⚙  Set Storage Folder",
            "↩  Reset Default Storage Folder",
            "[COLOR orange]✖  Manage / Delete Subtitles[/COLOR]",
            "⇄  Change Language (Addon / Kodi / TMDb Helper)",
            "ℹ  Information & User Guide"
        ]
    else:
        main_title = f"Υπότιτλοι: {search_string}"
        main_options = [
            "[COLOR lime][B]▶  Αναζήτηση & Λήψη Υποτίτλων[/B][/COLOR]",
            "◈  Αναζήτηση μέσω Browser (Εξωτερικά Sites)",
            "⚙  Ρύθμιση Φακέλου Αποθήκευσης",
            "↩  Επαναφορά Προεπιλεγμένου Φακέλου",
            "[COLOR orange]✖  Διαχείριση / Διαγραφή Υποτίτλων[/COLOR]",
            "⇄  Αλλαγή Γλώσσας (Πρόσθετο / Kodi / TMDb Helper)",
            "ℹ  Πληροφορίες & Οδηγίες Χρήσης"
        ]

    main_choice = dialog.select(main_title, main_options)
    if main_choice == 1:
        open_browser_subs(base_title)
        return
    elif main_choice == 2:
        set_custom_storage_path()
        return
    elif main_choice == 3:
        reset_storage_path_to_default()
        return
    elif main_choice == 4:
        show_sub_manager_menu(clean_filename, target_folder, global_mode=False)
        return
    elif main_choice == 5:
        show_language_settings_menu()
        return
    elif main_choice == 6:
        show_addon_info()
        return
    elif main_choice == -1:
        return

    addon_dir = get_addon_dir()
    base_fake_video = os.path.join(addon_dir, 'fake.mp4')
    if not os.path.exists(base_fake_video):
        return

    temp_video_file = os.path.join(addon_dir, f"{clean_filename}.mp4")
    try:
        shutil.copyfile(base_fake_video, temp_video_file)
    except Exception:
        temp_video_file = base_fake_video

    list_item = xbmcgui.ListItem(search_string)
    video_metadata = {'title': search_string, 'title_clean': base_title, 'label': search_string}
    if is_tv_show:
        video_metadata['tvshowtitle'] = base_title
        video_metadata['season'] = int(season)
        video_metadata['episode'] = int(episode)
    if movie_year and movie_year.isdigit():
        video_metadata['year'] = int(movie_year)
    if imdb_id and str(imdb_id).startswith('tt'):
        video_metadata['imdbnumber'] = imdb_id
    list_item.setInfo('video', video_metadata)

    xbmc.Player().play(temp_video_file, list_item)

    for _ in range(20):
        if xbmc.Player().isPlayingVideo():
            xbmc.executebuiltin('PlayerControl(Pause)')
            break
        xbmc.sleep(100)
    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
        xbmc.executebuiltin('Action(SmallWindow)')

    xbmcgui.Window(10000).setProperty('subtitles.searchstring', search_string)
    xbmcgui.Window(10000).setProperty('SubtitleSearchString', search_string)
    xbmcgui.Window(10000).setProperty('subtitles.filename', search_string)
    xbmcgui.Window(10000).setProperty('autosniper.last_en_title', base_title)

    m = threading.Thread(target=auto_stop_and_move, args=(clean_filename, focus_container, focus_item))
    m.daemon = True
    m.start()
    xbmc.executebuiltin('ActivateWindow(subtitlesearch)')


if __name__ == '__main__':
    main()




