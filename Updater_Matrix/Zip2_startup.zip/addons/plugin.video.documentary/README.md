DOCUMENTARY for Kodi
====================

Greek documentary YouTube channels and playlists in one place.
Requires plugin.video.youtube for playback. Kodi 21 and newer.

License: GPL-3.0-or-later

Αλλαγή καναλιών
---------------
Η λίστα βρίσκεται στο resources/channels.json. Κάθε κανάλι είναι μία γραμμή:

    {"id": "UCxxxxxxxxxxxxxxxxxxxxxx ή @handle ή https://www.youtube.com/@handle", "name": "Προαιρετικό όνομα", "icon": "προαιρετικό: http(s) url ή πλήρης διαδρομή"}

Μόνο το id είναι υποχρεωτικό (channel id, @handle ή URL καναλιού). Αν λείπει το name ή το icon, παίρνονται αυτόματα από το YouTube (το εικονίδιο είναι η εικόνα του καναλιού).
Για αλλαγή χωρίς νέο zip, βάλε ένα channels.json στο userdata/addon_data/plugin.video.documentary/
και θα χρησιμοποιείται αντί για το ενσωματωμένο.
