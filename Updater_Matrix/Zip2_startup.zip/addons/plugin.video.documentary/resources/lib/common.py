# -*- coding: utf-8 -*-
"""Shared helpers: settings, debug-only logging, JSON file cache, bookmarks."""

import json
import os
import time
from hashlib import sha1

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DIR = os.path.join(PROFILE, 'cache')
BOOKMARKS_FILE = os.path.join(PROFILE, 'bookmarks.json')
HANDLES_FILE = os.path.join(PROFILE, 'handles.json')


def lang(string_id):
    return ADDON.getLocalizedString(string_id)


def media(name):
    return os.path.join(ADDON_PATH, 'resources', 'media', name)


def fmt_date(iso):
    """'2026-10-22T10:00:00Z' -> '22/10/2026' (empty string if unknown)."""
    if len(iso or '') < 10:
        return ''
    return '{}/{}/{}'.format(iso[8:10], iso[5:7], iso[0:4])


def debug_enabled():
    return ADDON.getSetting('debug') == 'true'


def log(message):
    """Logs only when the debug switch in the settings is on."""
    if debug_enabled():
        xbmc.log('[{}] {}'.format(ADDON_ID, message), xbmc.LOGINFO)


def _ensure_dir(path):
    if not os.path.isdir(path):
        xbmcvfs.mkdirs(path)


def _write_json(path, data):
    _ensure_dir(os.path.dirname(path))
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def _read_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


# ---- cache -----------------------------------------------------------------

def _cache_path(key):
    return os.path.join(CACHE_DIR, sha1(key.encode('utf-8')).hexdigest() + '.json')


def cache_get(key, ttl_hours=None):
    """Returns cached data. With ttl_hours=None the entry is returned even if expired."""
    entry = _read_json(_cache_path(key))
    if not isinstance(entry, dict) or 'data' not in entry:
        return None
    if ttl_hours is not None and time.time() - entry.get('ts', 0) > ttl_hours * 3600:
        return None
    return entry['data']


def cache_set(key, data):
    try:
        _write_json(_cache_path(key), {'ts': time.time(), 'data': data})
    except OSError as exc:
        log('cache write failed: {}'.format(exc))


def cache_clear():
    if os.path.isdir(CACHE_DIR):
        for name in os.listdir(CACHE_DIR):
            try:
                os.remove(os.path.join(CACHE_DIR, name))
            except OSError:
                pass


# ---- bookmarks (playlists) -------------------------------------------------

def bookmarks_get():
    data = _read_json(BOOKMARKS_FILE)
    return data if isinstance(data, list) else []


def bookmark_add(playlist_id, title, image):
    items = [b for b in bookmarks_get() if b.get('id') != playlist_id]
    items.append({'id': playlist_id, 'title': title, 'image': image})
    _write_json(BOOKMARKS_FILE, items)


def bookmark_delete(playlist_id):
    _write_json(BOOKMARKS_FILE, [b for b in bookmarks_get() if b.get('id') != playlist_id])


# ---- resolved @handles (kept across cache clears) --------------------------

def handle_get(handle):
    data = _read_json(HANDLES_FILE)
    return data.get(handle.lower()) if isinstance(data, dict) else None


def handle_set(handle, info):
    data = _read_json(HANDLES_FILE)
    data = data if isinstance(data, dict) else {}
    data[handle.lower()] = info
    _write_json(HANDLES_FILE, data)
