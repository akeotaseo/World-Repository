# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import xbmc, xbmcgui
# import xbmc
import sys
from tulip.compat import parse_qsl
from xbmc import getInfoLabel
from resources.lib import theories


params = dict(parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')
url = params.get('url')

fp = getInfoLabel('Container.FolderPath')

if action is None:
    theories.Indexer().root(audio_only='audio' in fp)

elif action == 'addBookmark':
    from tulip import bookmarks
    bookmarks.add(url)

elif action == 'deleteBookmark':
    from tulip import bookmarks
    bookmarks.delete(url)

elif action == 'bookmarks':
    whiskey.Indexer().bookmarks()
elif action == 'videos':
    theories.Indexer().videos(url)

elif action == 'play':
    theories.Indexer().play(url)

elif action == 'archive1':
    theories.Indexer().archive1()

elif action == 'archive2':
    theories.Indexer().archive2()

elif action == 'archive3':
    theories.Indexer().archive3()

elif action == 'archive4':
    theories.Indexer().archive4()

elif action == 'archive5':
    theories.Indexer().archive5()

elif action == 'archive6':
    theories.Indexer().archive6()
    
elif action == 'archive7':
    theories.Indexer().archive7()
    
elif action == 'archive8':
    theories.Indexer().archive8()

elif action == 'archive9':
    theories.Indexer().archive9()
    
elif action == 'archive20':
    theories.Indexer().archive20()

elif action == 'episodes':
    theories.Indexer().episodes(url)


    

elif action == 'cache_clear':
    from tulip import cache
    cache.clear(withyes=False)
