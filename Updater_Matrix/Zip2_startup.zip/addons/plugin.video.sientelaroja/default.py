# -*- coding: utf-8 -*-
import xbmcgui
import xbmcplugin
import xbmc
import sys
import re
import requests
import base64
import urllib.parse
import time
from urllib.parse import parse_qs
from datetime import datetime

HANDLE = int(sys.argv[1])

# ============================================================
# CONFIGURACIÓN
# ============================================================
ADDON_NAME = "Siente La Roja"
BASE_API   = "https://apis-data10.tcrbg61levl.cfd"

API_MIRRORS = [
    "https://apis-data10.tcrbg61levl.cfd",
    "https://apis-data-defra10.tcrbg61levl.cfd",
]

PLAYER_MIRRORS = [
    "https://teagan01bp.mvksstick9uq6cprotection.cfd",  
    "https://may01bp.2f17ubowlsjn46easier.cfd",          
]

REFERER_MIRRORS = [
    "https://brit01.i6a6qcometogpvcelectric.sbs/",      
    "https://nia17bp.2wruedoublej4l6adjective.sbs/",    
    "https://www.fctv33hd.help/",                        
    "https://www.fctv33hd.monster/",                    
]

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)
# =====
# ============================================================

SPORT_TYPES = [
    ('1',  '⚽ Fútbol'),
    ('2',  '🏀 Baloncesto'),
    ('3',  '🎾 Tenis'),
    ('7',  '🏎 Motor'),
    ('14', '🥊 Lucha / MMA'),
]

def obtener_player_base_actual():
    """
    Lee la web principal y extrae el dominio del player del iframe.
    Así funciona aunque cambien los dominios.
    """
    import re, requests
    
    # Intentar obtener un partido activo de la API para construir su URL
    for api in API_MIRRORS:
        for ref in REFERER_MIRRORS:
            try:
                r = requests.get(
                    f"{api}/api/match/live?language=4&sportType=1",
                    headers=get_headers(ref),
                    timeout=10
                )
                if r.status_code == 200 and len(r.content) > 1000:
                    # Tenemos datos, obtener el primer matchId
                    data = r.content
                    i = 0
                    while i < len(data) - 10:
                        if data[i] == 0x08:
                            try:
                                mid, p1 = decode_varint(data, i+1)
                                if 1000000 < mid < 99000000:
                                    # Construir URL del partido en la web
                                    # y leer el iframe del player
                                    web_base = ref.rstrip('/')
                                    match_url = f"{web_base}/es/football/match-{mid}.html"
                                    rw = requests.get(
                                        match_url,
                                        headers=get_headers(ref),
                                        timeout=10
                                    )
                                    # Buscar src del iframe
                                    m = re.search(
                                        r'<iframe[^>]+src=["\']([^"\']+mdata=[^"\']+)["\']',
                                        rw.text
                                    )
                                    if m:
                                        iframe_src = m.group(1)
                                        # Extraer dominio base
                                        from urllib.parse import urlparse
                                        parsed = urlparse(iframe_src)
                                        return f"{parsed.scheme}://{parsed.netloc}"
                            except:
                                pass
                        i += 1
            except:
                continue
    return PLAYER_MIRRORS[0] 

def get_headers(referer=None):
    return {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, */*',
        'Referer': referer or REFERER,
        'Origin': (referer or REFERER).rstrip('/'),
    }

def decode_varint(data, pos):
    result = 0
    shift = 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, pos

def limpiar_nombre(txt):
    txt = re.sub(r'^\d+', '', txt).strip()
    txt = re.sub(r'[\xf0-\xff]$', '', txt).strip()
    txt = re.sub(r'[\x00-\x1f\x7f]', '', txt).strip()
    return txt

def get_api_data(sport_type):
    """Intenta todos los mirrors de API hasta que uno responda."""
    for api_base in API_MIRRORS:
        for ref in REFERER_MIRRORS:
            try:
                r = requests.get(
                    f"{api_base}/api/match/live?language=4&sportType={sport_type}",
                    headers=get_headers(ref),
                    timeout=15
                )
                if r.status_code == 200 and len(r.content) > 50:
                    return r.content
            except:
                continue
    return b''

def extraer_partidos(data):
    ahora_ms = int(time.time() * 1000)
    partidos = []
    i = 0

    while i < len(data) - 10:
        if data[i] == 0x08:
            try:
                match_id, p1 = decode_varint(data, i + 1)
                if not (1000 < match_id < 99000000):
                    i += 1
                    continue

                if p1 >= len(data) or data[p1] != 0x10:
                    i += 1
                    continue
                status, p2 = decode_varint(data, p1 + 1)

                if p2 >= len(data) or data[p2] != 0x18:
                    i += 1
                    continue
                timestamp_ms, p3 = decode_varint(data, p2 + 1)

                if not (1700000000000 < timestamp_ms < 2100000000000):
                    i += 1
                    continue

                diff_min = (timestamp_ms - ahora_ms) / 60000

                # Ignorar eventos de más de 12h en el futuro
                if diff_min > 720:
                    i += 1
                    continue

                if diff_min < -180:
                    estado = 'terminado'
                elif diff_min < 0:
                    estado = 'en_curso'
                else:
                    estado = 'proximo'

                # Extraer nombre via campo f2 01 12 [len] [nombre]
                nombre = None
                zona_bytes = data[i:i+500]
                j = 0
                while j < len(zona_bytes) - 5:
                    if zona_bytes[j] == 0xf2 and zona_bytes[j+1] == 0x01:
                        try:
                            _, jp = decode_varint(zona_bytes, j+2)
                            if zona_bytes[jp] == 0x12:
                                inner_len, jp2 = decode_varint(zona_bytes, jp+1)
                                if 4 < inner_len < 80 and jp2 + inner_len <= len(zona_bytes):
                                    candidato = zona_bytes[jp2:jp2+inner_len].decode('utf-8', errors='replace')
                                    if len(candidato) > 4:
                                        nombre = limpiar_nombre(candidato)
                                        break
                        except:
                            pass
                    j += 1

                # Fallback regex
                if not nombre:
                    zona = zona_bytes.decode('latin-1', errors='replace')
                    m = re.search(
                        r'([\w\xc0-\xd6\xd8-\xf6]'
                        r'[\w\s\xc0-\xd6\xd8-\xf6\-\.]{2,35}'
                        r'(?:\s+vs\s+[\w\xc0-\xd6\xd8-\xf6]'
                        r'[\w\s\xc0-\xd6\xd8-\xf6\-\.]{2,35})?)',
                        zona
                    )
                    if m:
                        nombre = limpiar_nombre(m.group(1))

                if not nombre:
                    i += 1
                    continue

                hora = datetime.fromtimestamp(timestamp_ms / 1000).strftime('%H:%M')

                partidos.append({
                    'match_id': match_id,
                    'nombre': nombre,
                    'hora': hora,
                    'timestamp': timestamp_ms,
                    'diff_min': int(diff_min),
                    'estado': estado,
                })

            except:
                pass
        i += 1

    vistos = {}
    for p in partidos:
        if p['match_id'] not in vistos:
            vistos[p['match_id']] = p
    return sorted(vistos.values(), key=lambda x: x['timestamp'])

def abrir_en_navegador(url):
    """Abre la URL en el navegador del dispositivo."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        try:
            xbmc.executebuiltin(
                f'StartAndroidActivity("", "android.intent.action.VIEW", "", "{url}")'
            )
        except:
            xbmc.executebuiltin(
                f'StartAndroidActivity("com.android.chrome", '
                f'"android.intent.action.VIEW", "", "{url}")'
            )
    elif xbmc.getCondVisibility("System.Platform.IOS"):
        xbmc.executebuiltin(f'System.LaunchURL("{url}")')
    else:
        import webbrowser
        webbrowser.open(url)

def listar_deportes():
    pbar = xbmcgui.DialogProgress()
    pbar.create(ADDON_NAME, "Cargando categorías...")

    datos = {}
    for idx, (st, _) in enumerate(SPORT_TYPES):
        pbar.update(
            int((idx / len(SPORT_TYPES)) * 100),
            f"Cargando {SPORT_TYPES[idx][1]}..."
        )
        if pbar.iscanceled():
            break
        data_raw = get_api_data(st)
        partidos = extraer_partidos(data_raw) if data_raw else []
        activos = [p for p in partidos if p['estado'] != 'terminado']
        datos[st] = activos

    pbar.close()

    for st, nombre in SPORT_TYPES:
        activos = datos.get(st, [])
        count = len(activos)
        en_curso = sum(1 for p in activos if p['estado'] == 'en_curso')

        if count == 0:
            label = f"[COLOR gray]{nombre}  —  sin eventos[/COLOR]"
        elif en_curso > 0:
            label = (
                f"[B]{nombre}[/B]  "
                f"[COLOR green]● {en_curso} en vivo[/COLOR]  "
                f"[COLOR yellow]({count} total)[/COLOR]"
            )
        else:
            label = f"[B]{nombre}[/B]  [COLOR yellow]({count} próximos)[/COLOR]"

        li = xbmcgui.ListItem(label=label)
        url = f"{sys.argv[0]}?action=listar_partidos&sport={st}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def listar_partidos(sport_type):
    pbar = xbmcgui.DialogProgress()
    pbar.create(ADDON_NAME, "Cargando partidos...")
    data = get_api_data(sport_type)
    pbar.close()

    if not data:
        xbmcgui.Dialog().ok(ADDON_NAME, "No se pudo cargar la agenda.\nComprueba tu conexión.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    partidos = extraer_partidos(data)

    if not partidos:
        xbmcgui.Dialog().ok(ADDON_NAME, "No hay eventos disponibles ahora mismo.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for p in partidos:
        if p['estado'] == 'en_curso':
            hora_txt   = f"[COLOR green]● {p['hora']}[/COLOR]"
            nombre_txt = f"[COLOR green][B]{p['nombre']}[/B][/COLOR]"
        elif p['estado'] == 'terminado':
            hora_txt   = f"[COLOR red]{p['hora']}[/COLOR]"
            nombre_txt = f"[COLOR red]{p['nombre']}[/COLOR]"
        else:
            hora_txt   = f"[COLOR yellow]{p['hora']}[/COLOR]"
            nombre_txt = f"[B]{p['nombre']}[/B]"

        titulo = f"{hora_txt}  {nombre_txt}"
        li = xbmcgui.ListItem(label=titulo)
        li.setProperty('IsPlayable', 'true')
        mdata = base64.b64encode(
            f"{p['match_id']}_{sport_type}".encode()
        ).decode()
        url = f"{sys.argv[0]}?action=reproducir&mdata={urllib.parse.quote(mdata)}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def reproducir_video(mdata_enc):
    # Intentar con todos los mirrors del player
    player_url = None
    for mirror in PLAYER_MIRRORS:
        url_candidate = f"{mirror}/es/player.html?mdata={mdata_enc}&ilang=es"
        try:
            r = requests.head(url_candidate, timeout=5)
            if r.status_code < 400:
                player_url = url_candidate
                break
        except:
            continue

    if not player_url:
        player_url = f"{PLAYER_MIRRORS[0]}/es/player.html?mdata={mdata_enc}&ilang=es"

    pbar = xbmcgui.DialogProgress()
    pbar.create(ADDON_NAME, "Abriendo reproductor...")
    xbmc.sleep(800)
    pbar.close()
    abrir_en_navegador(player_url)
    xbmcplugin.setResolvedUrl(HANDLE, False, listitem=xbmcgui.ListItem())

# --- Ejecución ---
params = parse_qs(sys.argv[2][1:])
act = params.get('action', [None])[0]

if not act:
    listar_deportes()
elif act == 'listar_partidos':
    listar_partidos(params.get('sport', ['1'])[0])
elif act == 'reproducir':
    mdata = params.get('mdata', [''])[0]
    reproducir_video(mdata)