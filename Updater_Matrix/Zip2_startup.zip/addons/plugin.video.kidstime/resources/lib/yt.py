# -*- coding: utf-8 -*-
"""Minimal YouTube Data API v3 client (stdlib only) with cache and stale fallback."""

import json
import re
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from . import common

API = 'https://www.googleapis.com/youtube/v3/'
# Built-in key, used when the "API key" setting is empty.
DEFAULT_KEY = 'AIzaSyBOPEs4OAyhazXwkiJi7GzzPxGLlrXdaRY'

TTL_PLAYLISTS = 24   # hours
TTL_ITEMS = 6        # hours
TTL_CHANNELS = 168   # hours
HIDDEN_TITLES = ('Private video', 'Deleted video')


class YouTubeError(Exception):
    def __init__(self, message, reason=''):
        super().__init__(message)
        self.reason = reason


def _key():
    return (common.ADDON.getSetting('api_key') or '').strip() or DEFAULT_KEY


def _get(endpoint, params, ttl_hours):
    """Cached GET. On network/quota failure, falls back to an expired cache entry if present."""
    cache_key = endpoint + '?' + urlencode(sorted(params.items()))
    cached = common.cache_get(cache_key, ttl_hours)
    if cached is not None:
        common.log('cache hit: {}'.format(cache_key))
        return cached

    query = dict(params, key=_key())
    req = Request(API + endpoint + '?' + urlencode(query), headers={'User-Agent': 'Kodi/plugin.video.kidstime'})

    try:
        with urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        common.log('fetched: {}'.format(cache_key))
    except HTTPError as exc:
        reason = ''
        try:
            reason = json.loads(exc.read().decode('utf-8'))['error']['errors'][0]['reason']
        except Exception:
            pass
        common.log('HTTP {} {} for {}'.format(exc.code, reason, cache_key))
        if exc.code == 404 and reason in ('playlistNotFound', 'channelNotFound'):
            # e.g. a channel without live streams: treat as an empty result
            empty = {'items': []}
            common.cache_set(cache_key, empty)
            return empty
        stale = common.cache_get(cache_key)
        if stale is not None:
            return stale
        raise YouTubeError('HTTP {} {}'.format(exc.code, reason).strip(), reason)
    except (URLError, socket.timeout, ValueError, OSError) as exc:
        common.log('request failed: {} ({})'.format(exc, cache_key))
        stale = common.cache_get(cache_key)
        if stale is not None:
            return stale
        raise YouTubeError(str(exc))

    common.cache_set(cache_key, data)
    return data


def _thumb(snippet):
    thumbs = snippet.get('thumbnails') or {}
    for name in ('maxres', 'standard', 'high', 'medium', 'default'):
        if name in thumbs:
            return thumbs[name].get('url', '')
    return ''


CHANNEL_ID = re.compile(r'^UC[\w-]{22}$')
CHANNEL_URL = re.compile(r'youtube\.com/(?:channel/(UC[\w-]{22})|(@[^/?#\s]+))', re.I)


def parse_channel_ref(value):
    """Accepts a channel id (UC...), an @handle, or a youtube.com channel/@handle URL.

    Returns ('id', 'UC...'), ('handle', '@name') or None.
    """
    value = (value or '').strip()
    if CHANNEL_ID.match(value):
        return 'id', value
    if value.startswith('@') and len(value) > 1:
        return 'handle', value
    match = CHANNEL_URL.search(value)
    if match:
        return ('id', match.group(1)) if match.group(1) else ('handle', match.group(2))
    return None


def resolve_handle(handle):
    """@handle -> {'id', 'title', 'image'}. Resolved once (1 quota unit), then stored for good."""
    stored = common.handle_get(handle)
    if stored:
        return stored
    data = _get('channels', {'part': 'snippet', 'forHandle': handle}, TTL_CHANNELS)
    items = data.get('items', [])
    if not items:
        raise YouTubeError('handle not found: {}'.format(handle), 'handleNotFound')
    snippet = items[0].get('snippet', {})
    info = {'id': items[0]['id'], 'title': snippet.get('title', ''), 'image': _thumb(snippet)}
    common.handle_set(handle, info)
    return info


def channels_info(channel_ids):
    """Title and thumbnail for channels, one API call per 50 channels: {id: {title, image}}."""
    info = {}
    ids = list(channel_ids)
    for start in range(0, len(ids), 50):
        data = _get('channels', {'part': 'snippet', 'id': ','.join(ids[start:start + 50]), 'maxResults': 50},
                    TTL_CHANNELS)
        for item in data.get('items', []):
            snippet = item.get('snippet', {})
            info[item['id']] = {'title': snippet.get('title', ''), 'image': _thumb(snippet)}
    return info


def channel_playlists(channel_id):
    """All public playlists of a channel: list of dicts (id, title, image, plot, count)."""
    result, token = [], None
    for _ in range(10):  # safety cap: 500 playlists
        params = {'part': 'snippet,contentDetails,status', 'channelId': channel_id, 'maxResults': 50}
        if token:
            params['pageToken'] = token
        data = _get('playlists', params, TTL_PLAYLISTS)
        for item in data.get('items', []):
            snippet = item.get('snippet', {})
            count = item.get('contentDetails', {}).get('itemCount', 0)
            if count == 0:
                continue
            result.append({
                'id': item['id'],
                'title': snippet.get('title', ''),
                'image': _thumb(snippet),
                'plot': snippet.get('description', ''),
                'count': count,
                'date': snippet.get('publishedAt', ''),
                'podcast': (item.get('status') or {}).get('podcastStatus') == 'enabled',
            })
        token = data.get('nextPageToken')
        if not token:
            break
    return result


# Every channel has automatic playlists derived from its id (UC... -> prefix + rest).
# They are not part of the documented API, but are widely used.
AUTO_PREFIX = {'uploads': 'UU', 'videos': 'UULF', 'live': 'UULV'}


def auto_playlist(channel_id, kind):
    return AUTO_PREFIX[kind] + channel_id[2:] if channel_id.startswith('UC') else channel_id


def playlist_videos(playlist_id, token=None):
    """One page (50) of videos. Returns (list of dicts, next page token or None)."""
    params = {'part': 'snippet,contentDetails', 'playlistId': playlist_id, 'maxResults': 50}
    if token:
        params['pageToken'] = token
    data = _get('playlistItems', params, TTL_ITEMS)

    videos = []
    for item in data.get('items', []):
        snippet = item.get('snippet', {})
        title = snippet.get('title', '')
        video_id = (snippet.get('resourceId') or {}).get('videoId')
        if not video_id or title in HIDDEN_TITLES:
            continue
        videos.append({
            'id': video_id,
            'title': title,
            'image': _thumb(snippet),
            'plot': snippet.get('description', ''),
            'date': item.get('contentDetails', {}).get('videoPublishedAt') or snippet.get('publishedAt', ''),
        })
    return videos, data.get('nextPageToken')
