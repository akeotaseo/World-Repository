# -*- coding: utf-8 -*-
"""KIDS TIME: directory listing and routing."""

import os
import re
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from . import channels, common, yt

YT_PLAY = 'plugin://plugin.video.youtube/play/?video_id={}'
VIDEO_ID = re.compile(r'(?:v=|youtu\.be/|embed/|^)([A-Za-z0-9_-]{11})(?:[&?/]|$)')


class Plugin:

    def __init__(self, base_url, handle):
        self.base = base_url
        self.handle = handle

    # ---- helpers -----------------------------------------------------------

    def url(self, **query):
        return '{}?{}'.format(self.base, urlencode(query))

    def end(self, content, sorts=(), cache=True):
        xbmcplugin.setContent(self.handle, content)
        for method in sorts:
            xbmcplugin.addSortMethod(self.handle, method)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def fail(self, exc):
        common.log('error: {}'.format(exc))
        if getattr(exc, 'reason', '') in ('quotaExceeded', 'dailyLimitExceeded', 'rateLimitExceeded'):
            message = common.lang(32604)
        else:
            message = '{}: {}'.format(common.lang(32601), exc)
        xbmcgui.Dialog().notification(common.ADDON.getAddonInfo('name'), message, xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def label(self, title, date):
        """Title, optionally followed by the date (setting 'date_in_title')."""
        if date and common.ADDON.getSetting('date_in_title') == 'true':
            return '{}  ({})'.format(title, common.fmt_date(date))
        return title

    def folder(self, title, url, image='', plot='', date='', menu=None):
        li = xbmcgui.ListItem(label=self.label(title, date), offscreen=True)
        li.setArt({'icon': image, 'thumb': image, 'poster': image, 'fanart': common.ADDON.getAddonInfo('fanart')})
        tag = li.getVideoInfoTag()
        tag.setMediaType('tvshow')
        tag.setTitle(title)
        tag.setTvShowTitle(title)
        if plot:
            tag.setPlot(plot)
        if date:
            li.setLabel2(common.fmt_date(date))
            li.setDateTime(date)
            tag.setPremiered(date[:10])
        if menu:
            li.addContextMenuItems(menu)
        xbmcplugin.addDirectoryItem(self.handle, url, li, True)

    def video(self, video):
        date = video['date']
        li = xbmcgui.ListItem(label=self.label(video['title'], date), offscreen=True)
        li.setArt({'icon': video['image'], 'thumb': video['image'], 'fanart': video['image']})
        tag = li.getVideoInfoTag()
        tag.setMediaType('episode')
        tag.setTitle(video['title'])
        tag.setPlot(video['plot'])
        if date:
            li.setLabel2(common.fmt_date(date))
            li.setDateTime(date)
            tag.setFirstAired(date[:10])
            tag.setPremiered(date[:10])
            tag.setYear(int(date[:4]))
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(self.handle, YT_PLAY.format(video['id']), li, False)

    # ---- screens -----------------------------------------------------------

    def resolved_channels(self):
        """channels.json with ids resolved (@handles, URLs) and name/icon filled in from YouTube when missing."""
        entries = []
        for c in channels.load():
            ref = yt.parse_channel_ref(c['id'])
            if not ref:
                common.log('unrecognised channel entry: {}'.format(c['id']))
                continue
            kind, value = ref
            fetched = {}
            if kind == 'handle':
                try:
                    fetched = yt.resolve_handle(value)
                except yt.YouTubeError as exc:
                    common.log('cannot resolve {}: {}'.format(value, exc))
                    continue
                value = fetched['id']
            entries.append((c, value, fetched))

        missing = [cid for c, cid, fetched in entries if not fetched and (not c.get('name') or not c.get('icon'))]
        if missing:
            try:
                for cid, info in yt.channels_info(missing).items():
                    for c, eid, fetched in entries:
                        if eid == cid:
                            fetched.update(info)
            except yt.YouTubeError as exc:
                common.log('channel info failed: {}'.format(exc))

        result = []
        for c, cid, fetched in entries:
            icon = c.get('icon') or fetched.get('image') or common.ADDON.getAddonInfo('icon')
            if not icon.startswith(('http', 'special://')) and not os.path.isabs(icon):
                icon = common.media(icon)
            result.append({'id': cid, 'name': c.get('name') or fetched.get('title') or cid, 'icon': icon})
        return result

    def root(self):
        clear = (common.lang(32009), 'RunPlugin({})'.format(self.url(action='cache_clear')))
        for c in self.resolved_channels():
            self.folder(c['name'], self.url(action='channel', id=c['id']), image=c['icon'], menu=[clear])
        if common.bookmarks_get():
            self.folder(common.lang(32008), self.url(action='bookmarks'), image=common.media('bookmarks.png'))
        self.end('tvshows')

    def channel(self, channel_id):
        """Channel menu: latest videos, shorts, live, playlists, podcasts."""
        icon = next((c['icon'] for c in self.resolved_channels() if c['id'] == channel_id), '')

        playlists = []
        try:
            playlists = yt.channel_playlists(channel_id)
        except yt.YouTubeError as exc:
            common.log('playlists unavailable: {}'.format(exc))

        self.folder(common.lang(32010), self.url(action='latest', id=channel_id), image=icon)

        # show Live only when the channel really has live streams (the page is cached and reused when opened)
        live = yt.auto_playlist(channel_id, 'live')
        try:
            if yt.playlist_videos(live)[0]:
                self.folder(common.lang(32012), self.url(action='playlist', id=live), image=icon)
        except yt.YouTubeError as exc:
            common.log('live check failed: {}'.format(exc))

        if any(not p['podcast'] for p in playlists):
            self.folder(common.lang(32013), self.url(action='playlists', id=channel_id), image=icon)
        if any(p['podcast'] for p in playlists):
            self.folder(common.lang(32014), self.url(action='playlists', id=channel_id, podcasts='1'), image=icon)
        self.end('tvshows')

    def playlists(self, channel_id, podcasts=False):
        try:
            playlists = yt.channel_playlists(channel_id)
        except yt.YouTubeError as exc:
            return self.fail(exc)

        for item in playlists:
            if item['podcast'] != podcasts:
                continue
            add = (common.lang(32501), 'RunPlugin({})'.format(
                self.url(action='addBookmark', id=item['id'], title=item['title'], image=item['image'])))
            self.folder(item['title'], self.url(action='playlist', id=item['id']),
                        image=item['image'], plot=item['plot'], date=item['date'], menu=[add])
        self.end('tvshows', (xbmcplugin.SORT_METHOD_LABEL, xbmcplugin.SORT_METHOD_DATE))

    def latest(self, channel_id, token=None):
        """Regular videos only (no Shorts); falls back to all uploads if that list is empty."""
        playlist_id = yt.auto_playlist(channel_id, 'videos')
        if not token:
            try:
                if not yt.playlist_videos(playlist_id)[0]:
                    playlist_id = yt.auto_playlist(channel_id, 'uploads')
            except yt.YouTubeError as exc:
                return self.fail(exc)
        self.playlist(playlist_id, token)

    def playlist(self, playlist_id, token=None):
        try:
            videos, next_token = yt.playlist_videos(playlist_id, token)
        except yt.YouTubeError as exc:
            return self.fail(exc)

        if not videos and not next_token:
            xbmcgui.Dialog().notification(common.ADDON.getAddonInfo('name'), common.lang(32600))

        for video in videos:
            self.video(video)

        if next_token:
            self.folder(common.lang(32500), self.url(action='playlist', id=playlist_id, token=next_token))

        self.end('episodes', (xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_DATE,
                              xbmcplugin.SORT_METHOD_VIDEO_TITLE))

    def bookmarks(self):
        items = sorted(common.bookmarks_get(), key=lambda b: b.get('title', '').lower())
        for item in items:
            remove = (common.lang(32502), 'RunPlugin({})'.format(self.url(action='deleteBookmark', id=item['id'])))
            self.folder(item.get('title', ''), self.url(action='playlist', id=item['id']),
                        image=item.get('image', ''), menu=[remove])
        self.end('tvshows')

    def play(self, value):
        """Backward compatibility: old favourites used action=play with a video id or link."""
        match = VIDEO_ID.search(value or '')
        if not match:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        xbmcplugin.setResolvedUrl(self.handle, True, xbmcgui.ListItem(path=YT_PLAY.format(match.group(1))))

    # ---- router ------------------------------------------------------------

    def run(self, query):
        params = dict(parse_qsl(query.lstrip('?')))
        action = params.get('action')
        common.log('route: {}'.format(params))

        if action is None:
            self.root()
        elif action == 'channel':
            self.channel(params['id'])
        elif action == 'latest':
            self.latest(params['id'], params.get('token'))
        elif action == 'playlists':
            self.playlists(params['id'], params.get('podcasts') == '1')
        elif action == 'playlist':
            self.playlist(params['id'], params.get('token'))
        elif action == 'bookmarks':
            self.bookmarks()
        elif action == 'addBookmark':
            common.bookmark_add(params['id'], params.get('title', ''), params.get('image', ''))
        elif action == 'deleteBookmark':
            common.bookmark_delete(params['id'])
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'play':
            self.play(params.get('url'))
        elif action == 'cache_clear':
            common.cache_clear()
            xbmcgui.Dialog().notification(common.ADDON.getAddonInfo('name'), common.lang(32602))
        # --- old action names, kept so existing favourites keep working ---
        elif action and re.fullmatch(r'archive\d+', action):
            items = self.resolved_channels()
            if 0 < int(action[7:]) <= len(items):
                self.channel(items[int(action[7:]) - 1]['id'])
        elif action == 'episodes':
            self.playlist(params.get('url', ''))


def main():
    Plugin(sys.argv[0], int(sys.argv[1])).run(sys.argv[2])
