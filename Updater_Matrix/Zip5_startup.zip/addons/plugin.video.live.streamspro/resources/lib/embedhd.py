# -*- coding: utf-8 -*-
import re
import requests


DEFAULT_UA = "Mozilla/5.0"


def get_m3u8(url, referer):
    try:
        headers = {
            "User-Agent": DEFAULT_UA,
            "Referer": referer,
            "Origin": referer.rstrip("/")
        }

        # 🔹 Request al embed
        r = requests.get(url, headers=headers, timeout=10, verify=False)
        html = r.text

        # 🔹 Buscar el m3u8 dentro del JS
        match = re.search(r'source:\s*"([^"]+\.m3u8[^"]*)"', html)

        if not match:
            return None

        m3u8 = match.group(1)

        # 🔹 Limpiar &amp;
        m3u8 = m3u8.replace("&amp;", "&")

        # 🔹 Dominio base para headers finales
        base = re.match(r'(https?://[^/]+)', url).group(1)

        # 🔹 Armar URL final para Kodi
        final_url = (
            f"{m3u8}"
            f"|referer={base}/"
            f"&origin={base}"
            f"&user-agent={DEFAULT_UA}"
            f"&verifypeer=false"
        )

        return final_url

    except Exception as e:
        print("ERROR embedhd:", str(e))
        return None


# 🔹 Test directo (opcional)
if __name__ == "__main__":
    url = "https://instream.click/jwp-us.php?stream=NBA1"
    referer = "https://embedhd.click/"
    print(get_m3u8(url, referer))