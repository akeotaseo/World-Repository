# -*- coding: utf-8 -*-

import requests,re
from urllib.parse import urlparse
import xbmc

session=requests.Session()

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"

BASE_HEADERS={
    "User-Agent":UA,
    "Accept":"*/*",
    "Accept-Language":"es-ES,es;q=0.9",
    "Connection":"keep-alive"
}

def log(msg):
    xbmc.log("[L2L2] %s"%msg,xbmc.LOGINFO)

def build_url(m3u8,referer=None):
    host=urlparse(referer if referer else m3u8).netloc
    if not host:return ""

    cookies=session.cookies.get_dict()
    cookie="; ".join("%s=%s"%(k,v) for k,v in cookies.items())

    url=m3u8+"|User-Agent="+UA
    url+="&Referer=https://"+host+"/"
    url+="&Origin=https://"+host

    if cookie:
        url+="&Cookie="+cookie

    url+="&verifypeer=false&verifyhost=false"

    return url

def method_src(html,referer):
    m=re.search(r'''src=["'](https?://[^"']+?\.m3u8[^"']*)["']''',html,re.I)
    if not m:return ""
    log("Metodo SRC")
    return build_url(m.group(1),referer)

def method_join(html,referer):
    m=re.search(r'return\s*\(\[(.*?)\]\.join',html,re.S)
    if not m:return ""
    chars=re.findall(r'"(.*?)"',m.group(1))
    if not chars:return ""
    m3u8="".join(chars).replace("\\/","/").strip()
    if ".m3u8" not in m3u8:return ""
    log("Metodo JOIN")
    return build_url(m3u8,referer)

METHODS=(method_src,method_join)

def resolve(url):
    try:
        log("Resolviendo: %s"%url)

        parsed=urlparse(url)
        base="%s://%s"%(parsed.scheme,parsed.netloc)

        m=re.search(r'id=(\d+)',url)
        if m:
            api="%s/api/player.php?id=%s"%(base,m.group(1))
            headers=BASE_HEADERS.copy()
            headers["Referer"]=base+"/"
            log("API: %s"%api)

            r=session.get(api,headers=headers,timeout=10,verify=False)
            log("API STATUS: %s"%r.status_code)

            try:
                data=r.json()
                real_url=data.get("url","")
                if real_url:
                    url=real_url
                    log("URL REAL: %s"%url)
            except:
                pass

        headers=BASE_HEADERS.copy()
        headers["Referer"]=url

        r=session.get(url,headers=headers,timeout=15,verify=False)
        html=r.text

        log("STATUS: %s"%r.status_code)
        log("HTML LEN: %s"%len(html))

        for method in METHODS:
            try:
                result=method(html,url)
                if result:
                    log("OK -> %s"%method.__name__)
                    return result
            except Exception as e:
                log("%s ERROR: %s"%(method.__name__,e))

        log("NO STREAM")
        return ""

    except Exception as e:
        log("GENERAL ERROR: %s"%e)
        return ""