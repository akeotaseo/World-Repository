# -*- coding: utf-8 -*-

import requests
import re

session = requests.Session()

HEADERS = {
"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
"Referer":"https://sportsnline.click/",
"Origin":"https://sportsnline.click",
"Accept":"*/*",
"Accept-Language":"es-ES,es;q=0.9",
"Connection":"keep-alive"
}

def resolve(channel_id):

    try:

        # 1️⃣ abrir página del canal
        url = f"http://sportzonline.click/channels/hd/{channel_id}.php"

        r = session.get(url, headers=HEADERS, timeout=10, verify=False)

        html = r.text


        # 2️⃣ buscar iframe
        iframe = re.search(r'<iframe src="([^"]+)', html)

        if not iframe:
            return "NA"

        iframe_url = iframe.group(1)

        if iframe_url.startswith("//"):
            iframe_url = "https:" + iframe_url


        # 3️⃣ abrir iframe
        r = session.get(iframe_url, headers=HEADERS, timeout=10, verify=False)

        html = r.text


        # 4️⃣ buscar m3u8 directo
        m3u8 = re.search(r'(https?://[^"]+\.m3u8[^"]*)', html)

        if not m3u8:
            return "NA"

        stream = m3u8.group(1)


        # 5️⃣ añadir headers para Kodi
        stream += (
        "|User-Agent=" + HEADERS["User-Agent"] +
        "&Referer=https://0e4vqvmlb660m2.dynamicsnake.net/" +
        "&Origin=https://0e4vqvmlb660m2.dynamicsnake.net"
        )

        return stream

    except:
        return "NA"