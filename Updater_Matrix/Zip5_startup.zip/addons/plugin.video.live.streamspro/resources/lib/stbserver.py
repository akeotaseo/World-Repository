# -*- coding: utf-8 -*-
import re
import requests
from xml.sax.saxutils import escape as escape_xml
from urllib.parse import quote_plus
import xbmcgui
import time
import hashlib

requests.packages.urllib3.disable_warnings()

# =========================================
# CACHE GLOBAL
# =========================================

SESSION = requests.Session()
SESSION.verify = False

TOKEN_CACHE = {}
PROFILE_CACHE = {}

# =========================================
# 🔹 Funciones auxiliares
# =========================================


def make_device_info(mac, model="MAG250"):
    mac = mac.upper()

    sn = hashlib.md5(mac.encode()).hexdigest().upper()
    sn_cut = sn[:13]

    device_id = hashlib.sha256(mac.encode()).hexdigest().upper()

    signature = hashlib.sha256((sn_cut + mac).encode()).hexdigest().upper()

    return {
        "mac": mac,
        "sn": sn,
        "snCut": sn_cut,
        "deviceId": device_id,
        "deviceId2": device_id,
        "signature": signature,
        "model": model
    }

def stb_headers(mac, token, server=None, device=None):

    if device is None:
        device = make_device_info(mac)

    return {
        "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) "
                      "AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 2 rev: 250 Safari/533.3",

        "X-User-Agent": f"Model: {device['model']}; Link: WiFi",

        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "Keep-Alive",

        "Cookie": (
            f"mac={device['mac']}; "
            f"stb_lang=en; "
            f"timezone=America/New_York; "
            f"sn={device['snCut']}"
        ),

        "Referer": f"http://{server}/c/" if server else "",

        "Authorization": f"Bearer {token}" if token else ""
    }

def _notify(msg):
    """Muestra notificación en Kodi"""
    dialog = xbmcgui.Dialog()
    dialog.notification("BlackGhost IPTV", msg, xbmcgui.NOTIFICATION_INFO, 4000)


# =========================================
# 🔹 Token del portal http://89.47.232.166:8080/portal.php?type=stb&action=handshake&JsHttpRequest=1-xml
# =========================================

def get_token(server, mac):

    cache_key = f"{server}|{mac}"

    try:

        if cache_key in TOKEN_CACHE:

            token, expire = TOKEN_CACHE[cache_key]

            if expire > time.time():
                return token

        url = (
            f"http://{server}/portal.php"
            f"?type=stb&action=handshake"
            f"&JsHttpRequest=1-xml"
        )

        headers = stb_headers(mac, "", server)

        r = SESSION.get(
            url,
            headers=headers,
            timeout=10,
            allow_redirects=True
        )

        if not r or r.status_code != 200:
            return None

        m = re.search(
            r'"token"\s*:\s*"([^"]+)"',
            r.text
        )

        if not m:
            return None

        token = m.group(1)

        TOKEN_CACHE[cache_key] = (
            token,
            time.time() + 300
        )

        return token

    except:
        return None


# =========================================
# 🔹 Categorías portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml
# =========================================

def get_categories(server, mac):
    """Devuelve XML con las categorías del servidor, incluyendo opción de buscar canal"""
    try:
        token = get_token(server, mac)
        if not token:
            return "<items><item><title>Server Inactivo: prueba otro</title><link>NA</link></item></items>"

        headers = stb_headers(mac, token)
        url = f"http://{server}/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"

        s = requests.Session()
        r = SESSION.get(url, headers=headers, timeout=10, verify=False, allow_redirects=True)
        data = r.json().get("js", [])

        # =========================================
        # Botón de BUSCAR CANAL (siempre primero)
        # =========================================
        items = f"""
<item>
  <title>[COLOR lightyellow][B]Server: {server} [/COLOR] MAC:[COLORcoral]{mac}[/COLOR][/B]</title>
  <link>NA</link>
  <thumbnail>https://addonbg.co/black/img/icon.png</thumbnail>
  <fanart>https://addonbg.co/black/img/fanart.jpg</fanart>
  <info>Introduce el nombre del canal que deseas buscar.</info>
</item>
"""

        # =========================================
        # Agregar las demás categorías con color según idioma/región
        # =========================================
        for d in data:
            cid = d.get("id")
            title = escape_xml(d.get("title", "Sin título"))

            # Palabras clave para colorear de verde
            keywords = ["español", "spanish", "sp ", "esp", "es |", "es|", "es ", "es:", 
                        "lat", "lam ", "mx", "mex", "spania"]

            # Revisar si el título contiene alguna de las palabras clave (insensible a mayúsculas)
            color = "lightgreen" if any(k.lower() in title.lower() for k in keywords) else "skyblue"

            items += f"""
<item>
  <title>[B][COLOR {color}]{title}[/COLOR][/B]</title>
  <link>NA</link>
  <externallink>$doregex[cat_{cid}]</externallink>
  <thumbnail>https://addonbg.co/black/img/television.png</thumbnail>
  <regex>
    <name>cat_{cid}</name>
    <expres><![CDATA[#$pyFunction
from resources.lib import stbserver
def GetLSProData(page_data, Cookie_Jar, m):
    return stbserver.get_channels("{server}", "{mac}", "{cid}", 1)
]]></expres>
    <page></page>
  </regex>
</item>
"""

        # Devolver todos los items después de recorrer todas las categorías
        return f"<items>{items}</items>"

    except Exception as e:
        return f"<items><item><title>Error: {escape_xml(str(e))}</title><link>NA</link></item></items>"

# =========================================
# 🔹 Canales por categoría http://89.47.232.166:8080/portal.php?type=itv&action=get_ordered_list&genre=26&force_ch_link_check=&fav=0&sortby=number&hd=0&p=1&JsHttpRequest=1-xml
# =========================================
def get_channels(server, mac, cat_id, page=1):
    """Carga únicamente una página de canales y agrega botón Página siguiente"""
    try:
        token = get_token(server, mac)
        if not token:
            raise Exception("No se pudo obtener token")

        headers = stb_headers(mac, token)
        s = requests.Session()

        url = (
            f"http://{server}/portal.php?"
            f"type=itv&action=get_ordered_list"
            f"&genre={cat_id}"
            f"&force_ch_link_check="
            f"&fav=0"
            f"&sortby=number"
            f"&hd=0"
            f"&p={page}"
            f"&JsHttpRequest=1-xml"
        )

        r = SESSION.get(
            url,
            headers=headers,
            timeout=10,
            verify=False,
            allow_redirects=True
        )

        canal_blocks = re.findall(
            r'"id":"(\d+)".*?"name":"([^"]+)"',
            r.text
        )

        if not canal_blocks:
            return (
                "<items>"
                "<item>"
                "<title>No hay canales</title>"
                "<link>NA</link>"
                "</item>"
                "</items>"
            )

        items = ""

        # ==========================
        # Canales
        # ==========================
        for stream_id, name in canal_blocks:

            name = escape_xml(name)

            items += f"""
<item>
  <title>{name}</title>
  <link>$doregex[stream_{stream_id}]</link>
  <thumbnail>https://addonbg.co/black/img/tp.png</thumbnail>

  <regex>
    <name>stream_{stream_id}</name>
    <expres><![CDATA[#$pyFunction
from resources.lib import stbserver

def GetLSProData(page_data, Cookie_Jar, m):
    return stbserver.get_stream_link(
        "{server}",
        "{mac}",
        "{stream_id}"
    )
]]></expres>
    <page></page>
  </regex>

</item>
"""

        # ==========================
        # Verificar si existe página siguiente
        # ==========================
        next_page = page + 1

        test_url = (
            f"http://{server}/portal.php?"
            f"type=itv&action=get_ordered_list"
            f"&genre={cat_id}"
            f"&force_ch_link_check="
            f"&fav=0"
            f"&sortby=number"
            f"&hd=0"
            f"&p={next_page}"
            f"&JsHttpRequest=1-xml"
        )

        r2 = s.get(
            test_url,
            headers=headers,
            timeout=10,
            verify=False,
            allow_redirects=True
        )

        more_channels = re.findall(
            r'"id":"(\d+)"',
            r2.text
        )

        if more_channels:

            items += f"""
<item>
  <title>[COLOR gold][B]>>> Página {next_page} >>>[/B][/COLOR]</title>
  <link>NA</link>
  <thumbnail>https://addonbg.co/black/img/next.png</thumbnail>

  <externallink>$doregex[next_{cat_id}_{next_page}]</externallink>

  <regex>
    <name>next_{cat_id}_{next_page}</name>
    <expres><![CDATA[#$pyFunction
from resources.lib import stbserver

def GetLSProData(page_data, Cookie_Jar, m):
    return stbserver.get_channels(
        "{server}",
        "{mac}",
        "{cat_id}",
        {next_page}
    )
]]></expres>
    <page></page>
  </regex>

</item>
"""

        return f"<items>{items}</items>"

    except Exception as e:

        return (
            f"<items>"
            f"<item>"
            f"<title>Error: {escape_xml(str(e))}</title>"
            f"<link>NA</link>"
            f"</item>"
            f"</items>"
        )
    
# =========================================
# 🔹 Buscar canal por nombre (optimizado)
# =========================================

def buscar_canal(server, mac, term, max_resultados=50):
    """
    Busca canales por nombre en todo el portal STB de manera optimizada.
    Devuelve XML <items> con los resultados encontrados.
    """
    try:
        term = term.lower().strip()
        token = get_token(server, mac)
        if not token:
            return f"<items><item><title>No se pudo obtener token</title><link>NA</link></item></items>"

        headers = stb_headers(mac, token)
        s = requests.Session()

        encontrados = []

        # Obtener categorías
        url_genres = f"http://{server}/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
        r = SESSION.get(url_genres, headers=headers, timeout=10, verify=False, allow_redirects=True)
        genres = r.json().get("js", [])

        for g in genres:
            cat_id = g.get("id")
            cat_title = escape_xml(g.get("title", "Sin título"))

            # Revisar hasta 5 páginas por categoría
            for page in range(1, 6):
                url = f"http://{server}/portal.php?type=itv&action=get_ordered_list&genre={cat_id}&force_ch_link_check=&fav=0&sortby=number&hd=0&p={page}&JsHttpRequest=1-xml"
                r = s.get(url, headers=headers, timeout=10, verify=False, allow_redirects=True)
                matches = re.finditer(r'"id":"(.*?)".*?"name":"(.*?)"', r.text)

                for match in matches:
                    stream_id, name = match.groups()
                    if term in name.lower():
                        name_esc = escape_xml(name)
                        link_final = f"$doregex[stream_{stream_id}]"

                        encontrados.append({
                            "name": name_esc,
                            "stream_id": stream_id,
                            "cat_title": cat_title,
                            "link": link_final
                        })

                        if len(encontrados) >= max_resultados:
                            break
                if len(encontrados) >= max_resultados:
                    break
            if len(encontrados) >= max_resultados:
                break

        if not encontrados:
            return f"<items><item><title>No se encontraron canales con '{escape_xml(term)}'</title><link>NA</link></item></items>"

        # Generar XML
        items = ""
        for c in encontrados:
            items += f"""
<item>
  <title>[COLORlightblue]{c['name']}[/COLOR] [I]({c['cat_title']})[/I]</title>
  <link>{c['link']}</link>
  <thumbnail>https://addonbg.co/black/img/tp.png</thumbnail>
  <regex>
    <name>stream_{c['stream_id']}</name>
    <expres><![CDATA[#$pyFunction
from resources.lib import stbserver
def GetLSProData(page_data, Cookie_Jar, m):
    return stbserver.get_stream_link("{server}", "{mac}", "{c['stream_id']}")
]]></expres>
  <page></page>
  </regex>
</item>
"""
        return f"<items>{items}</items>"

    except Exception as e:
        return f"<items><item><title>Error en búsqueda: {escape_xml(str(e))}</title><link>NA</link></item></items>"


# =========================================
# 🔹 Enlace final del stream
# =========================================

def get_stream_link(server, mac, stream_id):
    try:
        s = requests.Session()

        # 🔥 HANDSHAKE
        url = f"http://{server}/portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
        headers = stb_headers(mac, "", server)

        r = SESSION.get(url, headers=headers, timeout=10, verify=False, allow_redirects=True)

        if not r or r.status_code != 200:
            return "Error: handshake falló"

        match = re.search(r'"token"\s*:\s*"([^"]+)"', r.text)
        if not match:
            return "Error: sin token"

        token = match.group(1)

        # 🔥 HEADERS con token
        headers = stb_headers(mac, token, server)

        # 🔥 PROFILE
        cache_key = f"{server}|{mac}|{token}"
        profile_url = f"http://{server}/portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml"
        if cache_key not in PROFILE_CACHE:

            SESSION.get(
            profile_url,
            headers=headers,
            timeout=10,
            allow_redirects=True
        )

        PROFILE_CACHE[cache_key] = True

        # 🔥 (extra estabilidad)
        #channels_url = f"http://{server}/portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
        #s.get(channels_url, headers=headers, timeout=10, verify=False, allow_redirects=True)

        # 🔥 CREATE LINK
        url = (
            f"http://{server}/portal.php?"
            f"type=itv&action=create_link&"
            f"cmd=http://localhost/ch/{stream_id}_&JsHttpRequest=1-xml"
        )

        r = s.get(url, headers=headers, timeout=10, verify=False, allow_redirects=True)
      

        if not r or r.status_code != 200:
            return "Error: create_link falló"

        data = r.json()
        cmd = data.get("js", {}).get("cmd", "")

        # 🔥 VALIDACIONES CLAVE
        if not cmd:
            return "Error: sin enlace"

        if "offline" in cmd.lower():
            return "Error: canal offline"

        if cmd.startswith("ffmpeg "):
            cmd = cmd[7:]

        return (
            f"{cmd}"
            f"|User-Agent={quote_plus(headers['User-Agent'])}"
            f"&Referer=http://{server}/c/"
            f"&Cookie={quote_plus(headers['Cookie'])}"
            f"&Authorization={quote_plus(headers['Authorization'])}"
        ).replace("\\/", "/")

    except Exception as e:
        return f"Error: {e}"
