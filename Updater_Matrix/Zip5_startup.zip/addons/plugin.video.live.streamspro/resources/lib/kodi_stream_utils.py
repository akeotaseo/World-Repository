# resources/lib/kodi_stream_utils.py

import re
import requests
import base64
import urllib3
import json
import urllib.parse
import xbmc
import xbmcgui


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
def voodc_m3u8(embed_url):
    import requests, re, urllib3, xbmc
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    try:
        xbmc.log(f"[voodc_m3u8] Iniciando con URL: {embed_url}", xbmc.LOGINFO)

        session = requests.Session()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Referer': 'https://voodc.com/',
            'Origin': 'https://voodc.com',
        }

        # Paso 1: obtener página inicial
        html0 = session.get(embed_url, headers=headers, timeout=10, verify=False).text
        xbmc.log(f"[voodc_m3u8] HTML0 obtenido: {len(html0)} caracteres", xbmc.LOGINFO)

        # Paso 2: buscar iframe
        embed_match = re.search(r'src="(//voodc\.com/embed/[^"]+)"', html0)
        if not embed_match:
            xbmc.log("[voodc_m3u8] No se encontró iframe embed", xbmc.LOGERROR)
            return None

        embed_url_full = 'https:' + embed_match.group(1)
        xbmc.log(f"[voodc_m3u8] URL embed completa: {embed_url_full}", xbmc.LOGINFO)

        # Paso 3: obtener HTML del embed
        html3 = session.get(embed_url_full, headers=headers, timeout=10, verify=False).text
        xbmc.log(f"[voodc_m3u8] HTML3 obtenido: {len(html3)} caracteres", xbmc.LOGINFO)

        # Paso 4: buscar token
        token_match = re.search(r'embedded\+\"(.*?)\"', html3)
        if not token_match:
            xbmc.log("[voodc_m3u8] No se encontró token", xbmc.LOGERROR)
            return None

        token = token_match.group(1)
        xbmc.log(f"[voodc_m3u8] Token encontrado: {token}", xbmc.LOGINFO)

        # Paso 5: obtener player
        player_url = f'https://voodc.com/player/d/{token}'
        xbmc.log(f"[voodc_m3u8] Player URL: {player_url}", xbmc.LOGINFO)

        html2 = session.get(player_url, headers=headers, timeout=10, verify=False).text
        xbmc.log(f"[voodc_m3u8] HTML2 obtenido: {len(html2)} caracteres", xbmc.LOGINFO)

        # Paso 6: buscar m3u8
        m3u8_match = re.search(r"var\s+PlayS\s*=\s*'([^']+\.m3u8[^']*)'", html2)
        if not m3u8_match:
            xbmc.log("[voodc_m3u8] No se encontró URL m3u8", xbmc.LOGERROR)
            return None

        url = m3u8_match.group(1)
        xbmc.log(f"[voodc_m3u8] M3U8 encontrado: {url}", xbmc.LOGINFO)

        # Paso 7: formatear para Kodi
        kodi_url = f"{url}|User-Agent=Mozilla/5.0&Referer=https://voodc.com/&Origin=https://voodc.com"
        xbmc.log(f"[voodc_m3u8] URL final para Kodi: {kodi_url}", xbmc.LOGINFO)

        return kodi_url

    except Exception as e:
        xbmc.log(f"[voodc_m3u8] Error general: {str(e)}", xbmc.LOGERROR)
        return None







def daddyhd(channel_id):

    import re
    import base64
    import urllib.parse
    import requests
    import urllib3
    import xbmc

    try:

        # IGNORAR SSL
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        s = requests.Session()

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
            "Referer": "https://dlhd.pk/",
            "Origin": "https://dlhd.pk"
        }

        # STEP 1
        url1 = f"https://dlhd.pk/watch.php?id={channel_id}"

        r1 = s.get(
            url1,
            headers=headers,
            verify=False,
            timeout=10
        )

        xbmc.log(f"[DaddyHD] watch -> {r1.url}", xbmc.LOGINFO)

        iframe1 = re.search(
            r'<iframe[^>]+src="([^"]+stream-\d+\.php)"',
            r1.text
        )

        if not iframe1:
            xbmc.log("[DaddyHD] iframe1 NOT FOUND", xbmc.LOGERROR)
            return ""

        iframe1 = iframe1.group(1)

        xbmc.log(f"[DaddyHD] iframe1 -> {iframe1}", xbmc.LOGINFO)

        # STEP 2
        headers["Referer"] = url1

        r2 = s.get(
            iframe1,
            headers=headers,
            verify=False,
            timeout=10
        )

        iframe2 = re.search(
        r'<iframe\s*src="(http.*?)"',
        r2.text
        )

        if not iframe2:
            xbmc.log("[DaddyHD] iframe2 NOT FOUND", xbmc.LOGERROR)
            return ""

        iframe2 = iframe2.group(1)

        xbmc.log(f"[DaddyHD] iframe2 -> {iframe2}", xbmc.LOGINFO)

        # STEP 3
        headers["Referer"] = iframe1

        r3 = s.get(
            iframe2,
            headers=headers,
            verify=False,
            timeout=10
        )

        b64 = re.search(
            r"atob\('([^']+)'\)",
            r3.text
        )

        if not b64:
            xbmc.log("[DaddyHD] BASE64 NOT FOUND", xbmc.LOGERROR)
            return ""

        b64 = b64.group(1)

        m3u8 = base64.b64decode(b64).decode("utf-8")

        xbmc.log(f"[DaddyHD] m3u8 -> {m3u8}", xbmc.LOGINFO)

        cookie_string = "; ".join(
            [f"{c.name}={c.value}" for c in s.cookies]
        )

        kodi_headers = {
            "User-Agent": headers["User-Agent"],
            "Referer": "https://donis.jimpenopisonline.online/",
            "Origin": "https://donis.jimpenopisonline.online",
            "Cookie": cookie_string
        }

        header_string = urllib.parse.urlencode(kodi_headers)

        final = f"{m3u8}|{header_string}"

        xbmc.log(f"[DaddyHD] FINAL -> {final}", xbmc.LOGINFO)

        return final

    except Exception as e:

        xbmc.log(f"[DaddyHD] ERROR -> {str(e)}", xbmc.LOGERROR)

        return ""
    








def daddyhdvynx(channel):

    try:

        xbmc.log(f"[DaddyHD] Iniciando resolver | channel={channel}", xbmc.LOGINFO)

        session = requests.Session()

        headers = {
            "User-Agent": UA,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://tv.vynx.cc/",
            "Origin": "https://tv.vynx.cc",
            "Connection": "keep-alive"
        }

        token_url = f"https://media-proxy.vynx.workers.dev/tv/whitelist/token?channel=premium{channel}"

        xbmc.log(f"[DaddyHD] Request token -> {token_url}", xbmc.LOGINFO)

        r = session.get(
            token_url,
            headers=headers,
            timeout=10,
            verify=False
        )

        xbmc.log(f"[DaddyHD] Token status -> {r.status_code}", xbmc.LOGINFO)

        if r.status_code != 200:
            return ""

        data = r.json()

        token = data.get("token")
        verify_url = data.get("verify_url")
        channel_id = data.get("channel_id")

        if not token:
            return ""

        payload = {
            "recaptcha-token": token,
            "channel_id": channel_id
        }

        vr = session.post(
            verify_url,
            json=payload,
            headers={
                "User-Agent": UA,
                "Content-Type": "application/json",
                "Origin": "https://tv.vynx.cc",
                "Referer": "https://tv.vynx.cc/"
            },
            timeout=10,
            verify=False
        )

        xbmc.log(f"[DaddyHD] VERIFY status -> {vr.status_code}", xbmc.LOGINFO)

        channel_num = re.findall(r"\d+", str(channel))[0]

        m3u8 = f"http://dlhd.vynx.workers.dev/play/{channel_num}?key=vynx"

        xbmc.log(f"[DaddyHD] FINAL M3U8 -> {m3u8}", xbmc.LOGINFO)

        url = m3u8 + "|User-Agent=" + UA + "&Referer=https://tv.vynx.cc/"

        return url

    except Exception as e:

        xbmc.log("[DaddyHD] EXCEPTION -> " + str(e), xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

        return ""
		
		

def daddyhd_fixed(channel_id):

    import requests
    import xbmc

    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

    headers = {
        "User-Agent": ua,
        "Referer": "https://www.ksohls.ru/",
        "Origin": "https://www.ksohls.ru",
        "Accept": "*/*",
        "Connection": "keep-alive"
    }

    session = requests.Session()

    try:
        xbmc.log("[DaddyHD] ===== START =====", xbmc.LOGINFO)

        # -----------------------------------
        # SERVER LOOKUP (multi fallback)
        # -----------------------------------
        lookup_urls = [
            f"https://chevy.embedkclx.sbs/server_lookup?channel_id=premium{channel_id}",
            f"https://chevy.enviromentalanimal.horse/server_lookup?channel_id=premium{channel_id}",
            f"https://chevy.soyspace.cyou/server_lookup?channel_id=premium{channel_id}"
        ]

        server = None

        for url in lookup_urls:
            try:
                xbmc.log(f"[DaddyHD] LOOKUP → {url}", xbmc.LOGINFO)

                r = session.get(url, headers=headers, timeout=5)
                data = r.json()

                xbmc.log(f"[DaddyHD] LOOKUP RESP → {data}", xbmc.LOGINFO)

                if "server_key" in data:
                    server = data["server_key"]
                    xbmc.log(f"[DaddyHD] SERVER = {server}", xbmc.LOGINFO)
                    break

            except Exception as e:
                xbmc.log(f"[DaddyHD] LOOKUP FAIL → {e}", xbmc.LOGINFO)

        if not server:
            xbmc.log("[DaddyHD] ❌ No server found", xbmc.LOGERROR)
            return None

        # -----------------------------------
        # SERVERS FALLBACK (muy importante)
        # -----------------------------------
        servers = [
            server,
            "ddy6",
            "zeko",
            "wind",
            "dokko1",
            "nfs",
            "wiki",
            "x4"
        ]

        domains = [
            "embedkclx.sbs",
            "enviromentalanimal.horse",
            "soyspace.cyou"
        ]

        # -----------------------------------
        # TEST STREAMS
        # -----------------------------------
        for s in servers:
            for d in domains:

                stream = f"https://chevy.{d}/proxy/{s}/premium{channel_id}/mono.css"

                xbmc.log(f"[DaddyHD] TEST → {stream}", xbmc.LOGINFO)

                try:
                    r = session.get(stream, headers=headers, timeout=5)

                    xbmc.log(f"[DaddyHD] STATUS → {r.status_code}", xbmc.LOGINFO)
                    xbmc.log(f"[DaddyHD] SIZE → {len(r.text)}", xbmc.LOGINFO)

                    # validar contenido m3u
                    if "#EXTM3U" in r.text:

                        xbmc.log("[DaddyHD] ✅ STREAM FOUND!", xbmc.LOGINFO)

                        final = (
                            stream
                            + "|User-Agent=" + ua
                            + "&Referer=https://www.ksohls.ru/"
                            + "&Origin=https://www.ksohls.ru"
                            + "&Accept=*/*"
                            + "&Connection=keep-alive"
                        )

                        xbmc.log(f"[DaddyHD] FINAL → {final}", xbmc.LOGINFO)

                        return final

                except Exception as e:
                    xbmc.log(f"[DaddyHD] TEST FAIL → {e}", xbmc.LOGINFO)

        xbmc.log("[DaddyHD] ❌ No stream found", xbmc.LOGERROR)
        return None

    except Exception as e:
        xbmc.log(f"[DaddyHD] 💥 ERROR → {e}", xbmc.LOGERROR)
        return None


def daddyhd_neweew(channel_id):
    # 1. Configuración e Inicio
    xbmc.log(f"[DaddyHD] === INICIANDO PARA CANAL: {channel_id} ===", xbmc.LOGINFO)
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    session = requests.Session()
    # Usamos la versión exacta de Chrome que reportaste que sí funciona
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
    host_url = "https://adffdafdsafds.sbs"
    
    headers = {
        "User-Agent": ua,
        "Referer": f"{host_url}/",
        "Origin": host_url,
        "Accept": "*/*"
    }

    try:
        # 2. Obtener página para activar la IP y obtener Cookies
        page_url = f"{host_url}/premiumtv/daddyhd.php?id={channel_id}"
        xbmc.log(f"[DaddyHD] Validando sesión en: {page_url}", xbmc.LOGINFO)
        r = session.get(page_url, headers=headers, verify=False, timeout=15)
        
        if r.status_code != 200:
            xbmc.log(f"[DaddyHD] Error HTTP en página: {r.status_code}", xbmc.LOGERROR)
            return ""

        html = r.text

        # 3. Extraer CHANNEL_KEY
        m = re.search(r"CHANNEL_KEY\s*=\s*['\"]([^'\"]+)['\"]", html)
        if not m:
            xbmc.log("[DaddyHD] Error: No se encontró CHANNEL_KEY en el HTML", xbmc.LOGERROR)
            return ""
        
        channel_key = m.group(1)

        # 4. Server Lookup (Usando la sesión con cookies activas)
        lookup_url = f"https://ai.the-sunmoon.site/server_lookup?channel_id={channel_key}"
        r2 = session.get(lookup_url, headers=headers, verify=False, timeout=10)
        
        try:
            data = r2.json()
            server_key = data.get("server_key", "")
        except:
            xbmc.log("[DaddyHD] Error al leer JSON del servidor", xbmc.LOGERROR)
            return ""

        if not server_key:
            xbmc.log("[DaddyHD] No se recibió server_key de la API", xbmc.LOGERROR)
            return ""

        # 5. Construcción URL FINAL con Headers Persistentes
        # Cambiamos a https para mayor compatibilidad con la KEY
        stream_url = f"https://ai.the-sunmoon.site/proxy/{server_key}/{channel_key}/mono.css"
        
        # Estas cabeceras se inyectan en el reproductor. 
        # Kodi las usará para pedir el .css, la .key y los segmentos .ts (disfrazados de .png)
        headers_kodi = (
            f"User-Agent={ua}&"
            f"Referer={host_url}/&"
            f"Origin={host_url}&"
            f"verifypeer=false"
        )
        
        final_url = f"{stream_url}|{headers_kodi}"
        
        xbmc.log(f"[DaddyHD] ÉXITO. URL generada para Kodi: {final_url}", xbmc.LOGINFO)
        
        return final_url

    except Exception as e:
        xbmc.log(f"[DaddyHD] ERROR CRÍTICO: {str(e)}", xbmc.LOGERROR)
        return ""







def daddy_hd(channel_id):
    import re
    import requests
    import traceback
    import urllib3
    from urllib.parse import urlparse
    import xbmc

    base = f"https://chevy.giokko.ru/tv/premium{channel_id}/5893{channel_id}.m3u8"
    final = f"http://dlhd.vynx.workers.dev/play/{channel_id}?key=vynx"

    return final





def daddyhd_m3u8_new(channel_id, domain):
    import re
    import ast
    import requests
    import traceback
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    try:
        import xbmc
        def log(x):
            xbmc.log(f"[DaddyHD] {x}", xbmc.LOGINFO)
    except Exception:
        def log(x):
            print(f"[DaddyHD] {x}")

    UA = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/146.0.0.0 Safari/537.36"
    )

    def get_html_headers():
        return {
            "User-Agent": UA,
            "Referer": "https://deportelibres.shop/",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "es-ES,es;q=0.9",
            "DNT": "1",
            "Upgrade-Insecure-Requests": "1",
        }

    def get_json_headers(base):
        return {
            "User-Agent": UA,
            "Referer": f"{base}/",
            "Origin": base,
            "Accept": "application/json,text/plain,*/*",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "es-ES,es;q=0.9",
            "DNT": "1",
        }

    def get_m3u8_headers(base):
        return {
            "User-Agent": UA,
            "Referer": f"{base}/",
            "Origin": base,
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "es-ES,es;q=0.9",
            "DNT": "1",
        }

    def score_playlist(text):
        score = 0
        if "#EXTM3U" in text:
            score += 20
        score += text.count("#EXTINF:") * 3
        if "#EXT-X-KEY" in text:
            score += 5
        if "/key/" in text:
            score += 5
        if "403" in text or "forbidden" in text.lower():
            score -= 50
        if len(text.strip()) < 50:
            score -= 20
        return score

    try:
        log("──────────── START ────────────")
        base = f"https://{domain}"
        html_url = f"{base}/premiumtv/bizz-streams2u.php?id={channel_id}"
        log(f"HTML → {html_url}")

        r = requests.get(html_url, headers=get_html_headers(), timeout=15, verify=False)
        log(f"HTML status: {r.status_code}")
        if r.status_code != 200:
            return None

        html = r.text

        m = re.search(r"const\s+CHANNEL_KEY\s*=\s*['\"]([^'\"]+)['\"]", html, re.I)
        if not m:
            log("No encontré CHANNEL_KEY")
            return None
        channel_key = m.group(1)
        log(f"CHANNEL_KEY = {channel_key}")

        m = re.search(r"const\s+M3U8_SERVERS\s*=\s*(\[[^\]]*\])", html, re.S | re.I)
        servers = []
        if m:
            raw = m.group(1)
            try:
                servers = ast.literal_eval(raw)
            except Exception:
                servers = re.findall(r"['\"]([^'\"]+)['\"]", raw)

        if not servers:
            servers = ["chevy.soyspace.cyou"]

        log(f"M3U8_SERVERS = {servers}")

        candidates = []

        for server in servers:
            try:
                lookup_url = f"https://{server}/server_lookup?channel_id={channel_key}"
                log(f"Lookup → {lookup_url}")

                r2 = requests.get(
                    lookup_url,
                    headers=get_json_headers(base),
                    timeout=12,
                    verify=False
                )
                log(f"Lookup status [{server}] = {r2.status_code}")

                try:
                    data = r2.json()
                except Exception:
                    log(f"Lookup no JSON [{server}]")
                    continue

                server_key = data.get("server_key", "")
                if not server_key:
                    continue

                if server_key == "top1/cdn":
                    m3u8_url = f"https://{server}/proxy/top1/cdn/{channel_key}/mono.css"
                else:
                    m3u8_url = f"https://{server}/proxy/{server_key}/{channel_key}/mono.css"

                log(f"M3U8 candidata [{server}] = {m3u8_url}")

                preview = ""
                status = 0
                try:
                    r3 = requests.get(
                        m3u8_url,
                        headers=get_m3u8_headers(base),
                        timeout=12,
                        verify=False
                    )
                    status = r3.status_code
                    preview = r3.text[:2500]
                    log(f"M3U8 status [{server}] = {status}")
                except Exception as e:
                    log(f"M3U8 error [{server}] = {e}")

                candidates.append({
                    "server": server,
                    "server_key": server_key,
                    "m3u8_url": m3u8_url,
                    "status": status,
                    "preview": preview,
                    "score": score_playlist(preview) if preview else -999
                })

            except Exception as e:
                log(f"Error con server {server}: {e}")

        if not candidates:
            log("No hubo candidatos")
            return None

        candidates.sort(key=lambda x: (x["score"], x["status"] == 200), reverse=True)
        best = candidates[0]

        log(f"Servidor elegido = {best['server']}")
        log(f"server_key = {best['server_key']}")
        log(f"score = {best['score']}")
        log(f"M3U8 final = {best['m3u8_url']}")

        headers_final = (
            "User-Agent=Mozilla/5.0%20(Windows%20NT%2010.0;%20Win64;%20x64)%20"
            "AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20"
            "Chrome/146.0.0.0%20Safari/537.36&"
            "verify=false&verifypeer=false&verifyhost=false&"
            f"Referer={base}/&"
            f"Origin={base}"
        )

        final = f"{best['m3u8_url']}|{headers_final}"
        log(f"Final = {final}")
        log("──────────── DONE ────────────")
        return final

    except Exception:
        log("EXCEPCIÓN")
        log(traceback.format_exc())
        return None














def daddy_m3u8_old(channel_id, domain, page_url):
    import requests
    import xbmc
    import json

    requests.packages.urllib3.disable_warnings()

    xbmc.log("🔵 daddy_m3u8() INICIADO", xbmc.LOGINFO)
    xbmc.log(f"🔍 PARAMS: channel_id={channel_id} | domain={domain}", xbmc.LOGINFO)

    # ----------- SERVER LOOKUP ---------------
    try:
        lookup_url = f"https://{domain}/server_lookup.js?channel_id={channel_id}"
        xbmc.log(f"🔶 SERVER LOOKUP: {lookup_url}", xbmc.LOGINFO)

        r = requests.get(
            lookup_url,
            timeout=10,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        if r.status_code != 200:
            raise Exception(f"HTTP {r.status_code}")

        server_info = json.loads(r.text.strip())
        server_key = server_info.get("server_key")

        if not server_key:
            raise Exception("server_key no encontrado")

        xbmc.log(f"🟢 SERVER KEY = {server_key}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"🔴 ERROR EN SERVER LOOKUP: {e}", xbmc.LOGERROR)
        return ""

    # ----------- FORMAR URL .m3u8 DIRECTA ---------------
    try:
        if server_key == "top1/cdn":
            m3u8 = f"https://top1.giokko.ru/top1/cdn/{channel_id}/mono.m3u8"
        else:
            m3u8 = f"https://{server_key}new.giokko.ru/{server_key}/{channel_id}/mono.m3u8"

        xbmc.log(f"🟢 URL FINAL M3U8: {m3u8}", xbmc.LOGINFO)
        return m3u8

    except Exception as e:
        xbmc.log(f"🔴 ERROR CREANDO URL FINAL M3U8: {e}", xbmc.LOGERROR)
        return ""




# resources/lib/kodi_stream_utils.py
def daddy_m3u8_old(channel_id,domain,base_url):
    """
    Devuelve el enlace M3U8 final del servidor DaddyHD (kondoplay.cfd)
    con headers Kodi incluidos para reproducir el stream.
    Actualizado según la versión del regex m3u8 más reciente.
    """
    import re, json, base64, traceback
    from urllib.parse import quote_plus, urlparse
    import requests, urllib3
    import xbmc

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    try:
        # ---------- CONFIG ----------
        base = f"https://{domain}"
        page_url = f"{base_url}"
        ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
              "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36")

        s = requests.Session()
        headers_html = {
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
            "Referer": base + "/",
        }

        # ---------- OBTENER HTML ----------
        r = s.get(page_url, headers=headers_html, verify=False, timeout=15)
        r.raise_for_status()
        html = r.text

        # ---------- CHANNEL_KEY ----------
        m_ck = re.search(r'const\s+CHANNEL_KEY\s*=\s*"([^"]+)"', html)
        channel_key = m_ck.group(1) if m_ck else channel_id

        # ---------- DETECTAR VARIABLE BASE64 ----------
        m_bundle = re.search(
            r'const\s+BUNDLE\s*=\s*"([A-Za-z0-9+/=]{100,})"', html
        )
        if not m_bundle:
            raise ValueError("❌ No se encontró BUNDLE base64")

        bundle = m_bundle.group(1)

        # ---------- DECODIFICAR BUNDLE ----------
        decoded = base64.b64decode(bundle).decode("utf-8", "ignore")
        parts = json.loads(decoded)
        for k, v in parts.items():
            try:
                parts[k] = base64.b64decode(v).decode("utf-8", "ignore")
            except Exception:
                pass

        # ---------- CONSTRUIR auth_url ----------
        bx = [40, 60, 61, 33, 103, 57, 33, 57]
        sc = ''.join(chr(b ^ 73) for b in bx)
        host = "https://top2new.giokko.ru/"
        auth_url = (
            f"{host}{sc}?channel_id={quote_plus(channel_key)}&"
            f"ts={quote_plus(parts.get('b_ts',''))}&"
            f"rnd={quote_plus(parts.get('b_rnd',''))}&"
            f"sig={quote_plus(parts.get('b_sig',''))}"
        )

        headers_api = {"User-Agent": ua, "Referer": page_url, "Connection": "keep-alive"}
        try:
            s.get(auth_url, headers=headers_api, verify=False, timeout=10)
        except:
            pass

        # ---------- SERVER LOOKUP ----------
        lookup_url = f"https://{urlparse(page_url).netloc}/server_lookup.php?channel_id={channel_key}"
        lr = s.get(lookup_url, headers=headers_api, verify=False, timeout=15)
        lookup = lr.json() if lr.ok else {}
        server_key = lookup.get("server_key", "")

        # ---------- GENERAR M3U8 ----------
        if server_key == "top1/cdn" or not server_key:
            m3u8_url = f"https://top1.giokko.ru/top1/cdn/{channel_key}/mono.m3u8"
        else:
            m3u8_url = f"https://{server_key}new.giokko.ru/{server_key}/{channel_key}/mono.m3u8"

        # ---------- HEADERS KODI ----------
        referer = f'https://{urlparse(page_url).netloc}'
        headers_kodi = f"Referer={referer}/&Origin={referer}&Connection=Keep-Alive&User-Agent={ua}"

        return m3u8_url + "|" + headers_kodi

    except Exception as e:
        xbmc.log("❌ Error en daddyhd_m3u8: " + str(e) + " | " + traceback.format_exc(), xbmc.LOGERROR)
        return "plugin://plugin.video.blackghost/?error=" + quote_plus(str(e))







def streamglobal_m3u8(stream_url):
    """Extrae la URL .m3u8 desde streamtpglobal.com"""
    try:
        html = requests.get(stream_url, verify=False, timeout=10).text

        tp_match = re.search(r'playbackURL=""\,.*?=(\[\[.*?\]\]);', html, re.DOTALL)
        claves = re.search(r'{return\s(.*?)\;[\w\W\s]*?\{return\s(.*?)\;', html)
        if not tp_match or not claves:
            return "ERROR: No se encontró estructura JS"

        tp = eval(tp_match.group(1))
        tp.sort(key=lambda x: x[0])
        k = int(claves.group(1)) + int(claves.group(2))

        playback_url = ''
        for _, b64 in tp:
            try:
                decoded = base64.b64decode(b64).decode('utf-8')
                digits = ''.join(filter(str.isdigit, decoded))
                char_code = int(digits) - k
                playback_url += chr(char_code)
            except:
                continue
        return playback_url
    except Exception as e:
        return f"ERROR: {str(e)}"


def get_unpacked(page_data, pattern):
    """Extrae y desempaqueta JavaScript ofuscado (tipo eval(function(p,a,c,k,e,d)...))"""
    try:
        packed_match = re.search(pattern, page_data)
        if not packed_match:
            return "ERROR: no se encontró script ofuscado"

        from jsunpack import unpack
        unpacked = unpack(packed_match.group(1))
        return unpacked
    except Exception as e:
        return f"ERROR: {str(e)}"

# resources/lib/kodi_stream_utils.py

def play_jetextractors(url):
    """
    Wrapper para reproducir cualquier stream usando script.module.jetextractors.
    Recibe una URL (o lista de URLs) y reproduce directamente en Kodi.
    """
    try:
        from jetextractors import sportjetextractors
        import xbmcgui, xbmcplugin, sys

        urls = [url] if isinstance(url, str) else url

        # Ejecuta JetExtractors
        streams = sportjetextractors.play(urls)

        if not streams:
            xbmcgui.Dialog().ok("Error", "No se pudo extraer el stream")
            return

        # Reproducir cada stream (generalmente hay solo uno)
        for s in streams:
            list_item = xbmcgui.ListItem(label=s.get("name", "Stream"))
            list_item.setInfo('video', {'title': s.get("name", "Stream")})
            list_item.setPath(s["url"])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

    except ModuleNotFoundError:
        xbmcgui.Dialog().ok("Error", "script.module.jetextractors no está instalado")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo reproducir el stream: {str(e)}")
		

