# -*- coding: utf-8 -*-

import requests
import re
import base64
import json
from urllib.parse import urlparse

import xbmc

session = requests.Session()

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"

BASE_HEADERS = {
    "User-Agent": UA,
    "Accept": "*/*",
    "Accept-Language": "es-ES,es;q=0.9",
    "Connection": "keep-alive"
}


# ───────────────────────────────
# 🪵 LOGGER
# ───────────────────────────────
def log(txt):
    xbmc.log(f"[l2l2] {txt}", xbmc.LOGINFO)


# ───────────────────────────────
# 🔓 DECODER
# ───────────────────────────────
def decode_econfig(data):
    try:
        log("Decodificando econfig...")

        data = base64.b64decode(data).decode()
        size = len(data) // 4
        partes = [data[i*size:(i+1)*size] for i in range(4)]

        orden = [2, 0, 3, 1]
        resultado = [""] * 4

        for i in range(4):
            p = partes[i]

            if len(p) > 4:
                p = p[:3] + p[4:]

            try:
                resultado[orden[i]] = base64.b64decode(p).decode()
            except:
                resultado[orden[i]] = ""

        final = "".join(resultado)
        final = base64.b64decode(final).decode()

        return json.loads(final)

    except Exception as e:
        log(f"❌ ERROR decode_econfig: {e}")
        return {}


# ───────────────────────────────
# 🎯 RESOLVER UNIVERSAL
# ───────────────────────────────
def resolver(url, referer=""):

    try:
        log(f"Resolviendo URL: {url}")

        headers = BASE_HEADERS.copy()

        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"

        # ───────── EXTRAER ID
        id_match = re.search(r'id=(\d+)', url)
        if not id_match:
            log("❌ No se encontró ID")
            return "NA"

        ch_id = id_match.group(1)

        # ───────── USAR API PARA /ch Y /channel
        if "/ch?" in url or "/channel?" in url:

            api = f"{base}/api/player.php?id={ch_id}"
            log(f"Llamando API: {api}")

            headers["Referer"] = base + "/"

            r = session.get(api, headers=headers, timeout=10, verify=False)

            log(f"API status: {r.status_code}")

            data = r.json()

            url = data.get("url", "")

            if not url:
                log("❌ API sin URL")
                return "NA"

            log(f"URL real: {url}")

        # ───────── ABRIR PLAYER CON REFERER INTELIGENTE
        referers = [
            "https://nrdrse.link/",  # 🔥 el importante
            "https://l2l2.link/",
            base + "/"
        ]

        html = ""

        for ref in referers:
            try:
                headers["Referer"] = ref
                log(f"Probando referer: {ref}")

                r = session.get(url, headers=headers, timeout=10, verify=False)

                if "._econfig" in r.text:
                    html = r.text
                    log("✅ econfig encontrado")
                    break

            except Exception as e:
                log(f"Error con referer {ref}: {e}")
                continue

        if not html:
            log("❌ No se encontró econfig en ningún referer")
            return "NA"

        # ───────── EXTRAER ECONFIG
        match = re.search(r"window\._econfig='(.*?)'", html)

        if not match:
            log("❌ Regex econfig falló")
            return "NA"

        econfig = match.group(1)

        # ───────── DECODIFICAR
        data = decode_econfig(econfig)

        if not data:
            log("❌ JSON vacío")
            return "NA"

        m3u8 = (
            data.get("stream_url_nop2p") or
            data.get("stream_url") or
            data.get("source") or
            ""
        )

        if not m3u8 or ".m3u8" not in m3u8:
            log("❌ No hay m3u8 válido")
            return "NA"

        return build_stream(m3u8, url)

    except Exception as e:
        log(f"❌ ERROR resolver: {e}")
        return "NA"


# ───────────────────────────────
# 🔗 BUILD STREAM
# ───────────────────────────────
def build_stream(m3u8, referer):

    p = urlparse(referer)
    origin = f"{p.scheme}://{p.netloc}"

    stream = m3u8 + (
        "|User-Agent=" + UA +
        "&Referer=" + referer +
        "&Origin=" + origin +
        "&verifypeer=false&verifyhost=false"
    )

    log("✅ Stream construido correctamente")

    return stream