# -*- coding: utf-8 -*-

import requests
import re
import html
import xbmc
from urllib.parse import urljoin, urlparse

requests.packages.urllib3.disable_warnings()

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"

MAX_HOPS = 4  # cuantos saltos de iframe/redirect seguimos como máximo


def log(msg):
    xbmc.log("[BLACKGHOST][resolver] %s" % str(msg), xbmc.LOGINFO)


def _clean_url(u):
    """Decodifica entidades HTML (&amp; -> &) y recorta espacios."""
    if not u:
        return u
    return html.unescape(u).strip()


def get_iframe(html_src):

    matches = re.findall(
        r'<iframe.*?src=["\']([^"\']+)',
        html_src,
        re.I | re.S
    )

    matches = [_clean_url(m) for m in matches]

    log("IFRAMES -> %s" % str(matches))

    if not matches:
        return None

    bad = ["chat.php", "telegram", "facebook", "whatsapp", "ads", "banner"]

    for m in matches:
        if any(x in m.lower() for x in bad):
            continue
        return m

    return matches[0]


def get_js_redirect(html_src):
    """Busca redirecciones tipo window.location / location.href / meta refresh."""

    patterns = [
        r'(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)["\']',
        r'<meta[^>]+http-equiv=["\']refresh["\'][^>]+content=["\']\s*\d+\s*;\s*url=([^"\']+)["\']',
        r'window\.open\(\s*["\']([^"\']+)["\']',
    ]

    for p in patterns:
        m = re.search(p, html_src, re.I)
        if m:
            url = _clean_url(m.group(1))
            log("JS/META REDIRECT -> %s" % url)
            return url

    return None


def find_m3u8(html_src):

    patterns = [
        r'var\s+src\s*=\s*"([^"]+\.m3u8[^"]*)"',
        r'file\s*:\s*"([^"]+\.m3u8[^"]*)"',
        r'source\s*:\s*"([^"]+\.m3u8[^"]*)"',
        r'(https?:\/\/[^"\']+\.m3u8[^"\']*)'
    ]

    for p in patterns:
        m = re.search(p, html_src, re.I)
        if m:
            return m.group(1).replace("\\/", "/")

    return None


def _fetch(url, referer, sec_fetch_dest="iframe", sec_fetch_site="same-origin"):

    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "es-ES,es;q=0.9",
        "Connection": "keep-alive",
        "DNT": "1",
        "Referer": referer,
        "Sec-Fetch-Dest": sec_fetch_dest,
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": sec_fetch_site,
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": UA,
        "sec-ch-ua": '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"'
    }

    r = requests.get(url, headers=headers, timeout=15, verify=False)
    log("STATUS %s -> %s" % (url, r.status_code))
    return r


def resolve(url, referer="https://www.telegratishd.com/"):

    try:

        if url.endswith(".html"):
            url = url.replace(".html", ".php")

        log("URL -> %s" % url)

        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "es-ES,es;q=0.9",
            "Connection": "keep-alive",
            "DNT": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": UA,
            "sec-ch-ua": '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"'
        }

        r = requests.get(url, headers=headers, timeout=15, verify=False)

        log("MAIN STATUS -> %s" % r.status_code)

        current_html = r.text
        current_url = url
        current_referer = url

        for hop in range(MAX_HOPS):

            # 1) intentamos sacar el m3u8 de la página actual antes de saltar
            m3u8 = find_m3u8(current_html)
            if m3u8:
                log("m3u8 -> %s" % m3u8)
                return build_stream(m3u8, current_url)

            # 2) si no hay m3u8, buscamos a dónde saltar: iframe o redirect JS/meta
            next_url = get_iframe(current_html)

            if not next_url:
                next_url = get_js_redirect(current_html)

            if not next_url:
                log("No hay más saltos posibles (hop %d)" % hop)
                break

            if not next_url.startswith("http"):
                next_url = urljoin(current_url, next_url)

            log("HOP %d -> %s" % (hop + 1, next_url))

            r = _fetch(next_url, current_referer)

            current_html = r.text
            current_referer = current_url
            current_url = next_url

        # último intento tras salir del loop (por si el último hop sí traía el m3u8)
        m3u8 = find_m3u8(current_html)
        if m3u8:
            log("m3u8 -> %s" % m3u8)
            return build_stream(m3u8, current_url)

        log("m3u8 NO encontrada")
        return "NA"

    except Exception as e:

        import traceback

        log(str(e))
        log(traceback.format_exc())

        return "NA"


def build_stream(m3u8, referer):

    p = urlparse(m3u8)
    origin = f"{p.scheme}://{p.netloc}"

    headers = (
        "|User-Agent=" + UA +
        "&Referer=" + origin +
        "&Origin=" + origin +
        "&verifypeer=false&verifyhost=false"
    )

    return m3u8 + headers