# -*- coding: utf-8 -*-
import re
import time
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    import xbmc
    def log(msg):
        xbmc.log("[space] " + str(msg), xbmc.LOGINFO)
except:
    def log(msg):
        print("[space]", msg)

BASE = "https://chevy.soyspace.cyou"
ORIGIN = "https://yuntracking.co"
REFERER = "https://yuntracking.co/"
HOME = "https://deportelibres.shop/"

# User-Agent actualizado (el 146 es muy antiguo y lo detectan como bot)
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"

def headers(extra=None):
    h = {
        "User-Agent": UA,
        "Accept": "*/*",
        "Accept-Language": "es-ES,es;q=0.9",
        "Origin": ORIGIN,
        "Referer": REFERER,
        "Connection": "keep-alive"
    }
    if extra:
        h.update(extra)
    return h

def extract_id(url):
    # Ajustado para capturar el ID correctamente
    m = re.search(r'id=([A-Za-z0-9]+)', url)
    if m:
        cid = m.group(1)
        return "premium" + cid if not cid.startswith("premium") else cid
    return None

def warmup(session, url, ref):
    try:
        session.get(url, headers={
            "User-Agent": UA,
            "Referer": ref
        }, timeout=10, verify=False)
        log(f"WARMUP OK → {url}")
    except Exception as e:
        log(f"WARMUP FAIL → {e}")

def get_server(session, cid):
    try:
        # Usamos la ruta de tu script original
        url = f"{BASE}/server_lookup?channel_id={cid}"
        r = session.get(url, headers=headers(), timeout=10, verify=False)
        log("SERVER RESP: " + r.text)
        return r.json().get("server_key")
    except:
        return None

def activate_session(session, server, cid):
    url = f"{BASE}/proxy/{server}/{cid}/mono.css"
    log("ACTIVANDO SESIÓN → " + url)
    try:
        # IMPORTANTE: Seteamos la cookie que pide el HTML
        session.cookies.set("access", "true", domain="chevy.soyspace.cyou")
        
        session.get(
            url,
            headers=headers({
                "Accept": "text/html,application/xhtml+xml"
            }),
            timeout=10,
            verify=False
        )
        time.sleep(1.2)
        log("SESSION ACTIVADA")
    except Exception as e:
        log("SESSION ERROR: " + str(e))

def is_valid_m3u8(txt):
    return "#EXTM3U" in txt

def resolve(url):
    log("===== FINAL SESSION FIX =====")
    cid = extract_id(url)
    if not cid:
        log("❌ NO CHANNEL ID")
        return None, False

    s = requests.Session()
    s.verify = False

    # 1. warmup
    warmup(s, HOME, HOME)
    warmup(s, url, HOME)

    # 2. server
    server = get_server(s, cid)
    if not server:
        log("❌ NO SERVER")
        return None, False

    # 3. activar sesión
    activate_session(s, server, cid)

    stream = f"{BASE}/proxy/{server}/{cid}/mono.css"

    # 4. intentar varias veces
    real_stream = None
    for i in range(4):
        log(f"INTENTO #{i+1}")
        try:
            r = s.get(
                stream,
                headers=headers({
                    "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,*/*"
                }),
                timeout=10,
                verify=False
            )
            if is_valid_m3u8(r.text):
                log("✅ M3U8 DETECTADO")
                real_stream = stream
                break
        except Exception as e:
            log("ERROR REQUEST: " + str(e))
        time.sleep(1.5)

    if not real_stream:
        log("❌ NO SE CONSIGUIÓ STREAM")
        return None, False

    # 5. CONSTRUCCIÓN FINAL CON COOKIES PARA KODI
    # Extraemos las cookies de la sesión para que el reproductor no sea bloqueado
    c_dict = s.cookies.get_dict()
    c_str = "; ".join([f"{k}={v}" for k, v in c_dict.items()])
    
    final = (
        real_stream +
        "|User-Agent=" + UA +
        "&Cookie=" + c_str +
        "&Referer=" + REFERER +
        "&Origin=" + ORIGIN +
        "&verifypeer=false"
    )

    log("FINAL → " + final)
    # Devolvemos dos valores para evitar el error de unpacking en default.py
    return final

def get(url):
    return resolve(url)

def get_m3u8(url):
    return resolve(url)