# -*- coding: utf-8 -*-
import re
import requests
import time

# ==============================
# CONFIG
# ==============================

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Safari/605.1.15",
    "Referer": "https://vaughnlive.com/",
    "Connection": "keep-alive"
}

COOKIES = {
    "history_r1": "a36CAPobWXgfMrbKBOqXV1GXWEqUOlZiDYWNMrn8t5YqaO1Og5TUbk44XtdAkc"
}

TIMEOUT = 10
RETRIES = 2


# ==============================
# FUNCION PRINCIPAL
# ==============================

def resolve(channel_id):
    """
    Resuelve el stream desde VaughnLive (modo scraping)
    Incluye fallback automático
    """

    url = f"https://vaughnlive.com/{channel_id}"

    for intento in range(RETRIES):
        try:
            r = requests.get(
                url,
                headers=HEADERS,
                cookies=COOKIES,
                timeout=TIMEOUT,
                verify=False
            )

            data = r.text

            match = re.search(
                r'mp4StreamName.*?=\s*"(.*?)".*?\.flv\?\&(.*?)"',
                data,
                re.DOTALL
            )

            if match:
                stream_name = match.group(1)

                final_url = f"https://stream-cdn-iad.vaughnsoft.net/play/{stream_name}.flv?"

                # 🔥 Mejora PRO (headers para Kodi)
                return build_headers(final_url)

        except Exception as e:
            print(f"[VAU] intento {intento+1} error:", str(e))
            time.sleep(1)

    # ==========================
    # 🔥 FALLBACK NIVEL DIOS
    # ==========================
    print("[VAU] usando fallback directo")

    fallback_url = direct(channel_id)

    if fallback_url:
        return build_headers(fallback_url)

    return None


# ==============================
# MODO DIRECTO (como ?ch=)
# ==============================

def direct(ch):
    try:
        return f"http://stream-cdn-iad3.vaughnsoft.net/play/live_{ch}.flv?android_vs.ts.m3u8"
    except:
        return None


# ==============================
# HEADERS PARA KODI
# ==============================

def build_headers(url):
    """
    Agrega headers tipo Kodi:
    URL|User-Agent=xxx&Referer=xxx
    """
    headers = (
        f"|User-Agent={HEADERS['User-Agent']}"
        f"&Referer={HEADERS['Referer']}"
    )
    return url + headers