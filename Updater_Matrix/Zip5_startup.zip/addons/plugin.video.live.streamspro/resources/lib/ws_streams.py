# -*- coding: utf-8 -*-

import requests
import re
import base64
import json
import urllib3
import xbmc

from urllib.parse import urljoin, urlparse

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

session = requests.Session()

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"

HEADERS = {
    "User-Agent": UA,
    "Accept": "*/*",
    "Accept-Language": "es-ES,es;q=0.9",
    "Connection": "keep-alive"
}


# =========================================================
# BASE64 SAFE
# =========================================================
def b64d(data):

    try:

        padding = len(data) % 4

        if padding:
            data += "=" * (4 - padding)

        return base64.b64decode(data).decode("utf-8", errors="ignore")

    except:
        return ""


# =========================================================
# EXTRAER ECONFIG
# =========================================================
def extract_econfig(html):

    patterns = [

        r"window\._econfig\s*=\s*'([^']+)'",
        r'window\._econfig\s*=\s*"([^"]+)"',
        r"_econfig='([^']+)'",
        r'_econfig="([^"]+)"'
    ]

    for p in patterns:

        m = re.search(p, html, re.S)

        if m:
            return m.group(1)

    return None


# =========================================================
# BUSCAR M3U8 EN JSON
# =========================================================
def search_first_m3u8(obj):

    if isinstance(obj, dict):

        for v in obj.values():

            if isinstance(v, str) and ".m3u8" in v:
                return v

            result = search_first_m3u8(v)

            if result:
                return result

    elif isinstance(obj, list):

        for item in obj:

            result = search_first_m3u8(item)

            if result:
                return result

    return None


# =========================================================
# BUSCAR M3U8 DIRECTO EN HTML
# =========================================================
def search_m3u8_in_html(html):

    patterns = [

        # src = "https://xxx.m3u8"
        r'''src\s*=\s*["']([^"']+\.m3u8[^"']*)["']''',

        # file: "https://xxx.m3u8"
        r'''file\s*:\s*["']([^"']+\.m3u8[^"']*)["']''',

        # source: "https://xxx.m3u8"
        r'''source\s*:\s*["']([^"']+\.m3u8[^"']*)["']''',

        # hls: "https://xxx.m3u8"
        r'''hls\s*:\s*["']([^"']+\.m3u8[^"']*)["']''',

        # cualquier url absoluta
        r'''(https?:\/\/[^"' ]+\.m3u8[^"' ]*)''',

        # rutas relativas
        r'''["'](\/[^"']+\.m3u8[^"']*)["']'''
    ]

    for p in patterns:

        m = re.search(p, html, re.I)

        if m:
            return m.group(1)

    return None


# =========================================================
# DECODIFICADOR ECONFIG
# =========================================================
def decode_econfig(econfig):

    layer1 = b64d(econfig)

    if not layer1:
        return None

    parts_count = 4
    chunk_size = -(-len(layer1) // parts_count)

    parts = []
    pos = 0

    for i in range(parts_count):

        parts.append(layer1[pos:pos + chunk_size])
        pos += chunk_size

    reorder = [2, 0, 3, 1]

    decoded_parts = [None] * 4

    for i in range(4):

        block = parts[i]

        fixed = block[:3] + block[4:]

        decoded_parts[reorder[i]] = b64d(fixed)

    joined = "".join(decoded_parts)

    final = b64d(joined)

    try:
        return json.loads(final)

    except:
        return final


# =========================================================
# NOTIFICACIÓN KODI
# =========================================================
def notify(msg):

    try:

        xbmc.executebuiltin(
            'Notification(Stream,%s,4000)' % msg
        )

    except:
        pass


# =========================================================
# BUILD STREAM
# =========================================================
def build_stream(m3u8, referer):

    p = urlparse(referer)

    origin = f"{p.scheme}://{p.netloc}"

    return (
        m3u8 +
        "|User-Agent=" + UA +
        "&Referer=" + referer +
        "&Origin=" + origin +
        "&verifypeer=false&verifyhost=false"
    )


# =========================================================
# RESOLVE PRINCIPAL
# =========================================================
def resolve(url, referer=""):

    try:

        headers = HEADERS.copy()

        headers["Referer"] = referer if referer else url

        # =====================================================
        # 1. REQUEST PRINCIPAL
        # =====================================================
        r = session.get(
            url,
            headers=headers,
            timeout=10,
            verify=False
        )

        html = r.text

        current_url = url

        # =====================================================
        # 2. EXTRAER ECONFIG
        # =====================================================
        econfig = extract_econfig(html)

        # =====================================================
        # 3. SI NO HAY ECONFIG → BUSCAR IFRAME
        # =====================================================
        if not econfig:

            iframe = re.search(
                r'<iframe[^>]+src=["\']([^"\']+)["\']',
                html,
                re.I
            )

            if iframe:

                iframe_url = iframe.group(1).strip()

                if iframe_url.startswith("//"):

                    iframe_url = "https:" + iframe_url

                elif not iframe_url.startswith("http"):

                    iframe_url = urljoin(url, iframe_url)

                headers["Referer"] = url

                try:

                    r = session.get(
                        iframe_url,
                        headers=headers,
                        timeout=10,
                        verify=False
                    )

                    html = r.text

                    current_url = iframe_url

                except:
                    notify("Error cargando iframe")
                    return "NA"

                # buscar econfig otra vez
                econfig = extract_econfig(html)

        # =====================================================
        # 4. SI EXISTE ECONFIG
        # =====================================================
        if econfig:

            data = decode_econfig(econfig)

            if data:

                m3u8 = search_first_m3u8(data)

                if m3u8:

                    return build_stream(
                        m3u8,
                        current_url
                    )

        # =====================================================
        # 5. BUSCAR M3U8 DIRECTO EN HTML
        # =====================================================
        m3u8 = search_m3u8_in_html(html)

        if m3u8:

            if m3u8.startswith("/"):

                p = urlparse(current_url)

                m3u8 = (
                    f"{p.scheme}://{p.netloc}{m3u8}"
                )

            return build_stream(
                m3u8,
                current_url
            )

        # =====================================================
        # 6. NO STREAM
        # =====================================================
        notify("Stream no disponible")

        return "NA"

    except:

        notify("Error resolviendo stream")

        return "NA"