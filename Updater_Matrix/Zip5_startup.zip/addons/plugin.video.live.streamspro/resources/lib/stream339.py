# -*- coding: utf-8 -*-
import re
import base64
import requests
from urllib.parse import quote

# DEBUG KODI
try:
    import xbmc

    def log(msg):
        xbmc.log("[STREAM339] " + str(msg), xbmc.LOGINFO)

except:
    def log(msg):
        print("[STREAM339]", msg)


def stream339(url):

    log("=== INICIO ===")
    log("URL: " + str(url))

    try:

        UA = "Mozilla/5.0"

        headers = {
            "User-Agent": UA,
            "Referer": url
        }

        log("Haciendo request...")
        r = requests.get(url, headers=headers, timeout=10)
        html = r.text

        log("HTML obtenido, tamaño: " + str(len(html)))

        # =========================
        # ARRAY
        # =========================
        matches = re.findall(
            r'\[(\d+)\s*,\s*"([A-Za-z0-9+/=]+)"\]',
            html
        )

        log("Matches encontrados: " + str(len(matches)))

        if not matches:
            log("❌ No se encontró array db")
            return ""

        arr = [(int(pos), b64) for pos, b64 in matches]
        arr.sort(key=lambda x: x[0])

        # =========================
        # CLAVES
        # =========================
        nums = re.findall(r'return\s*(\d{3,})', html)

        log("Claves encontradas: " + str(nums))

        if len(nums) < 2:
            log("❌ No se encontraron suficientes claves")
            return ""

        k = int(nums[0]) + int(nums[1])
        log("Valor de k: " + str(k))

        # =========================
        # DECODE
        # =========================
        playback = []

        for i, (pos, b64) in enumerate(arr):

            try:
                decoded = base64.b64decode(
                    b64
                ).decode("utf-8", errors="ignore")

                digits = re.sub(r'\D', '', decoded)

                if digits:
                    char = chr(int(digits) - k)
                    playback.append(char)

                if i < 5:
                    log(f"Sample decode {i}: digits={digits}")

            except Exception as e:
                log("Error decode: " + str(e))
                continue

        result = "".join(playback).strip()

        log("Resultado length: " + str(len(result)))
        log("Resultado preview: " + result[:100])

        # =========================
        # VALIDACIÓN FINAL
        # =========================
        if result.startswith("http"):

            log("✅ URL válida encontrada")

            # Origin automático
            m = re.match(r"(https?://[^/]+)", url)

            if m:
                origin = m.group(1)
            else:
                origin = url

            final = (
                result +
                "|User-Agent=" + quote(UA) +
                "&Referer=" + quote(url) +
                "&Origin=" + quote(origin) +
                "&verifypeer=false" +
                "&verifyhost=false"
            )

            log("URL FINAL KODI:")
            log(final)

            return final

        log("❌ Resultado no es URL válida")
        return ""

    except Exception as e:
        log("❌ ERROR GENERAL: " + str(e))
        return ""