# -*- coding: utf-8 -*-

import requests
import re

session = requests.Session()

HOST = "http://tv.m3uts.xyz"

HEADERS_GEN = {
    "User-Agent": "Dalvik/2.1.0 (Linux; Android 9)",
    "Content-Type": "application/x-www-form-urlencoded"
}

HEADERS_STREAM = {
    "User-Agent": "Magma Player/10",
    "X-App": "di",
    "X-Version": "10/1.0.9",
    "X-Did": "f6ba37795ee53ceb",
    "X-Hash": "3qfGuerpALK4c_zQ4vE_FZrkRabEiSSlRz-LUVU1cYDoSULKaPqr1xquK3vyXZLS6sRO-tCtLZPwxepVxEHMHwrhWpYDjUpPrPlyc_AuGvn5F8WnJeYNNkAzXkdPad4cwYAeCELyaKZ5NhdYfeTQTwcED0LuXZURDW06bcI9SfXQasl0giDj_50rWwQecnDm4GuMxdd-XL5MwdEfKzewq1P2kB_TYTld_TIJU2GXRh1se6-fGJIxpFQP_9ChsB_r_n3vcbr5uv6oRhJ2qdAd6qU4rG7EYOs85ivbLG1u3vvi20jL-QfAUXgNlH5scapa5jmPjscuH0PQB1vsL0wqXBYnPLdrMrrx0o5mnXgvlg3mu5bHK2nndr9-FZWdWquJ9pcG6D8rQWKixy5QLsDECYEzyqxdipvHOMuYSigsqsBC9kcNCA4TDN0_zvKHZZTHxDa9QriOjmS8bg8K9wn7Zr20c37VIS3fOVgLPzx8VMGJBvz3XwLYTAv_ycPprmacGDMD9O3W1FoqWSxrgHIHTA"
}


# --------------------------
# GENERAR M3U8
# --------------------------
def get_m3u8(stream_id):
    try:
        url = f"{HOST}/stream/gen/{stream_id}"

        data = {
            "id": stream_id,
            "cast": "false",
            "device": "f6ba37795ee53ceb",
            "code": ""
        }

        r = session.post(url, data=data, headers=HEADERS_GEN, timeout=10)

        m = re.search(r'(http.*?\.m3u8)', r.text)

        if not m:
            return None

        return m.group(1)

    except:
        return None


# --------------------------
# FORMATEAR HEADERS KODI
# --------------------------
def add_headers(url):
    try:
        headers = "&".join([f"{k}={v}" for k, v in HEADERS_STREAM.items()])
        return url + "|" + headers
    except:
        return url


# --------------------------
# RESOLVER FINAL
# --------------------------
def resolve(stream_id):
    try:

        m3u8 = get_m3u8(stream_id)

        if not m3u8:
            return "NA"

        return add_headers(m3u8)

    except:
        return "NA"