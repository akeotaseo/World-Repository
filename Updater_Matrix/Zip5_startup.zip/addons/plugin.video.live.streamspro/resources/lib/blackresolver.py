# -- coding utf-8 --

import re
import base64
import requests


class BlackResolver

    def __init__(self)

        self.session = requests.Session()

        self.headers = {
            User-Agent Mozilla5.0,
            Accept 
        }

        self.visited = set()


    # ─────────────────────────────
    # request
    # ─────────────────────────────

    def get(self, url)

        if url in self.visited
            return 

        self.visited.add(url)

        try

            self.headers[Referer] = url

            r = self.session.get(url, headers=self.headers, timeout=15, allow_redirects=True)

            return r.text

        except

            return 


    # ─────────────────────────────
    # detectar streams
    # ─────────────────────────────

    def detect_stream(self, text)

        patterns = [

            r'https[^s']+.m3u8[^s']',
            r'https[^s']+.mp4[^s']',
            r'https[^s']+.ts[^s']',
            r'https[^s']+.mpd[^s']'

        ]

        for p in patterns

            m = re.search(p, text)

            if m

                return m.group(0)

        return None


    # ─────────────────────────────
    # detectar players
    # ─────────────────────────────

    def detect_players(self, html)

        patterns = [

            r'filess([^]+)',
            r'sourcess([^]+)',
            r'sourcesss[{files([^]+)',
            r'playlistss[{.files([^]+)',
            r'hlsss([^]+)'

        ]

        for p in patterns

            m = re.search(p, html, re.S)

            if m

                url = m.group(1)

                if http in url

                    return url

        return None


    # ─────────────────────────────
    # detectar JSON
    # ─────────────────────────────

    def detect_json_stream(self, html)

        matches = re.findall(r'filess(http[^]+)', html)

        if matches
            return matches[0]

        return None


    # ─────────────────────────────
    # base64 multilayer
    # ─────────────────────────────

    def decode_base64_layers(self, text)

        for _ in range(6)

            matches = re.findall(r'([A-Za-z0-9+=]{40,})', text)

            for m in matches

                try

                    decoded = base64.b64decode(m).decode()

                    if http in decoded
                        return decoded

                    text = decoded

                except

                    pass

        return None


    # ─────────────────────────────
    # streamtp resolver
    # ─────────────────────────────

    def resolve_streamtp(self, html)

        tp_match = re.search(r'([[d+,s.]])', html, re.DOTALL)

        if not tp_match
            return None

        try
            tp = eval(tp_match.group(1))
            tp.sort(key=lambda x x[0])
        except
            return None

        keys = re.findall(r'returns+(d+)', html)

        k = 0
        if len(keys) = 2
            k = int(keys[0]) + int(keys[1])

        playback_url = 

        for _, b64 in tp

            try

                decoded = base64.b64decode(b64).decode()

                digits = ''.join(filter(str.isdigit, decoded))

                char_code = int(digits) - k

                playback_url += chr(char_code)

            except
                pass

        if http in playback_url
            return playback_url

        return None


    # ─────────────────────────────
    # detectar token streams
    # ─────────────────────────────

    def detect_token_stream(self, html)

        token_pattern = re.search(
            r'(https[^s']+.m3u8[^']+)',
            html
        )

        if token_pattern
            return token_pattern.group(1)

        return None


    # ─────────────────────────────
    # resolver iframe chain
    # ─────────────────────────────

    def resolve_iframes(self, html, depth=0)

        if depth  6
            return None

        iframes = re.findall(r'iframe[^]+src=([^]+)', html)

        for iframe in iframes

            if iframe.startswith()
                iframe = https + iframe

            html2 = self.get(iframe)

            stream = self.detect_stream(html2)

            if stream
                return stream

            stream = self.resolve(html2, depth + 1)

            if stream
                return stream

        return None


    # ─────────────────────────────
    # resolver principal
    # ─────────────────────────────

    def resolve(self, html_or_url, depth=0)

        if html_or_url.startswith(http)
            html = self.get(html_or_url)
        else
            html = html_or_url

        if not html
            return None


        # direct stream
        stream = self.detect_stream(html)
        if stream
            return stream


        # token stream
        token = self.detect_token_stream(html)
        if token
            return token


        # players
        player = self.detect_players(html)
        if player
            return player


        # JSON
        json_stream = self.detect_json_stream(html)
        if json_stream
            return json_stream


        # streamtp
        streamtp = self.resolve_streamtp(html)
        if streamtp
            return streamtp


        # base64
        b64 = self.decode_base64_layers(html)
        if b64
            return b64


        # iframe chain
        iframe = self.resolve_iframes(html)
        if iframe
            return iframe


        return None


# función pública
def resolve_any_host(url)

    try

        resolver = BlackResolver()

        result = resolver.resolve(url)

        if result
            return result

        return 

    except
        return 