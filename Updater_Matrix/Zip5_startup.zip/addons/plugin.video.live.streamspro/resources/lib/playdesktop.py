# -*- coding: utf-8 -*-
import re
import requests
import xbmc

def log(msg):
    xbmc.log("[PLAYDESKTOP] " + str(msg), xbmc.LOGINFO)

def resolve(url): # url = https://s2.kora.st/channel?id=31

    try:

        UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
        refe=re.search(r'//([^/]+)',url).group(1)
        fid=re.search(r'id=(\d+)',url).group(1)

        headers = {
            "User-Agent": UA,
            "Referer":"https://%s/"% refe,
            "Origin":"https://%s"% refe
        }
    

        api = "https://swiftlogicpath.com/embedbl.php?player=desktop&live=do%s" % fid

        log(api)

        r = requests.get(api, headers=headers, timeout=15, verify=False)

        html = r.text

        log("STATUS: %s" % r.status_code)
        log("HTML LEN: %s" % len(html))

        m = re.search(r'return\s*\(\[(.*?)\]\.join', html, re.S)

        if not m:
            log("REGEX FAIL")
            log(html[:1000])
            return ""

        chars = re.findall(r'"(.*?)"', m.group(1))

        if not chars:
            log("NO CHARS")
            return ""

        m3u8 = "".join(chars).replace("\\/", "/").strip()

        log(m3u8[:300])

        if not m3u8.startswith("http"):
            log("INVALID URL")
            return ""

        return m3u8+"|User-Agent="+UA+"&Referer=https://swiftlogicpath.com/&Origin=https://swiftlogicpath.com&verifypeer=false&verifyhost=false"

    except Exception as e:

        log("ERROR: %s" % str(e))
        return ""