# -*- coding: utf-8 -*-

import re
import requests

DEFAULT_UA = "Mozilla/5.0"


def resolve(url):

    try:

        headers = {
            "User-Agent": DEFAULT_UA
        }

        html = requests.get(
            url,
            headers=headers,
            timeout=15,
            verify=False
        ).text

        # id=telemundo
        m = re.search(r'[?&]id=([^&]+)', url, re.I)

        if not m:
            return None

        canal = m.group(1)

        patron = r'%s\s*:\s*\{(.*?)\}\s*,?' % re.escape(canal)

        bloque = re.search(
            patron,
            html,
            re.S | re.I
        )

        if not bloque:
            return None

        bloque = bloque.group(1)

        # mpd
        mpd = re.search(
            r'url\s*:\s*"([^"]+)"',
            bloque,
            re.I
        )

        if not mpd:
            return None

        mpd = mpd.group(1)

        if mpd.startswith("//"):
            mpd = "https:" + mpd

        # kid:key
        ck = re.search(
            r"[\"']([a-fA-F0-9]+)[\"']\s*:\s*[\"']([a-fA-F0-9]+)[\"']",
            bloque
        )

        if not ck:
            return None

        kid = ck.group(1)
        key = ck.group(2)

        return {
            "url": mpd,
            "key": "%s:%s" % (kid, key)
        }

    except Exception as e:
        print("resolver ERROR:", str(e))
        return None


def get_url(url):

    data = resolve(url)

    if not data:
        return None

    return data["url"]


def get_key(url):

    data = resolve(url)

    if not data:
        return None

    return data["key"]


def get_all(url):

    data = resolve(url)

    if not data:
        return None

    return (
        data["url"],
        data["key"]
    )


if __name__ == "__main__":

    data = resolve(
        "https://tvtveshd.com/player.php?id=telemundo"
    )

    print(data)