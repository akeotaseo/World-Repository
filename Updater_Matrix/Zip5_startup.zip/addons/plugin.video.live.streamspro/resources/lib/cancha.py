# -*- coding: utf-8 -*-

import re
import requests
import urllib3

urllib3.disable_warnings()

try:
    import xbmc

    def log(msg):
        xbmc.log("[CANCHA] " + str(msg), xbmc.LOGINFO)

except:

    def log(msg):
        print("[CANCHA]", msg)


UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/148.0.0.0 Safari/537.36"
)


def resolve(url):

    try:

        log("================================================")
        log("INPUT: %s" % url)

        playback = resolve_src(url)

        if not playback:

            log("NO PLAYBACK")
            return url

        # ====================================================
        # FORZAR raw=1
        # ====================================================

        if "raw=1" not in playback:

            if "?" in playback:
                playback += "&raw=1"
            else:
                playback += "?raw=1"

        origin = get_origin(playback)

        final = (
            playback
            + "|User-Agent=" + UA
            + "&Referer=" + origin + "/"
            + "&Origin=" + origin
            + "&verifypeer=false"
        )

        log("FINAL: %s" % final)

        return final

    except Exception as e:

        log("ERROR: %s" % e)

        return url


# =========================================================
# RESOLVER MULTIPLES CAPAS
# =========================================================

def resolve_src(url, depth=0):

    try:

        if depth >= 5:
            return url

        log("DEPTH %s -> %s" % (depth, url))

        headers = {
            "User-Agent": UA,
            "Referer": get_origin(url) + "/",
            "Origin": get_origin(url)
        }

        r = requests.get(
            url,
            headers=headers,
            timeout=15,
            verify=False
        )

        html = r.text

        # =====================================================
        # BUSCAR const SRC
        # =====================================================

        src = re.search(
            r'''const\s+SRC\s*=\s*["']([^"']+)''',
            html,
            re.I
        )

        # si no encuentra SRC
        if not src:

            # probablemente ya es playlist
            if "#EXTM3U" in html:
                return url

            return url

        playback = src.group(1)

        playback = playback.replace("\\/", "/")

        # =====================================================
        # URL RELATIVA
        # =====================================================

        if playback.startswith("/"):

            playback = get_origin(url) + playback

        elif not playback.startswith("http"):

            if not playback.startswith("?"):
                playback = "/" + playback

            playback = get_origin(url) + playback

        log("SRC FOUND: %s" % playback)

        # =====================================================
        # SI SIGUE SIENDO HTML -> RESOLVER OTRA VEZ
        # =====================================================

        if any(x in playback for x in [
            "player=",
            "embed",
            "proxy",
            "canal="
        ]):

            return resolve_src(playback, depth + 1)

        return playback

    except Exception as e:

        log("resolve_src ERROR: %s" % e)

        return url


def get_origin(url):

    m = re.search(r"(https?://[^/]+)", url, re.I)

    if m:
        return m.group(1)

    return ""