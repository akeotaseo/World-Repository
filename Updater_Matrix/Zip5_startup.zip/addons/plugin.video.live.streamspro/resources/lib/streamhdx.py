# -*- coding: utf-8 -*-
import re,ast,base64,requests,xbmc,urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def log(t):
    xbmc.log("[STREAMHDX] %s" % t, xbmc.LOGINFO)

def streamhdx(url):
    try:
        UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
        s=requests.Session()

        headers={
            "User-Agent":UA,
            "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language":"es-ES,es;q=0.9",
            "Cache-Control":"no-cache",
            "Pragma":"no-cache",
            "DNT":"1",
            "Upgrade-Insecure-Requests":"1",
            "Referer":"https://tvtvpl.com/",
            "Origin":"https://tvtvpl.com",
            "Sec-Fetch-Dest":"iframe",
            "Sec-Fetch-Mode":"navigate",
            "Sec-Fetch-Site":"cross-site",
            "Sec-Fetch-User":"?1"
        }

        log("URL: %s" % url)

        r=s.get(url,headers=headers,timeout=20,allow_redirects=True,verify=False)

        html=r.text

        log("STATUS: %s" % r.status_code)
        log("HTML LEN: %s" % len(html))

        if not html:
            log("HTML VACIO")
            return ""

        if "ANTI LEECH" in html.upper():
            log("POSIBLE ANTI-LEECH")

        m=re.search(r'EP\s*=\s*(\[\[.*?\]\])\s*;\s*EP\.sort',html,re.S)

        if not m:
            log("NO ARRAY EP")

            m=re.search(r'(\w+)\s*=\s*(\[\[.*?\]\])\s*;\s*\1\.sort',html,re.S)

            if not m:
                log("NO ARRAY GENERICO")

                pos=html.find("EP=[[")
                if pos!=-1:
                    log("FRAGMENTO: "+html[pos:pos+500])

                return ""

            arr_txt=m.group(2)
        else:
            arr_txt=m.group(1)

        log("ARRAY LEN: %s" % len(arr_txt))

        try:
            arr=ast.literal_eval(arr_txt)
        except Exception as e:
            log("ERROR ARRAY: %s" % e)
            return ""

        log("ARRAY ITEMS: %s" % len(arr))

        arr.sort(key=lambda x:x[0])

        nums=re.findall(r'return\s+(\d+)',html)

        log("KEYS ENCONTRADAS: %s" % len(nums))

        if len(nums) < 2:
            log("NO KEYS")
            return ""

        k=int(nums[0])+int(nums[1])

        log("K: %s (%s + %s)" % (k,nums[0],nums[1]))

        playback=""

        for pos,b64 in arr:
            try:
                dec=base64.b64decode(b64).decode("utf-8","ignore")
                digits=re.sub(r'\D','',dec)

                if digits:
                    playback+=chr(int(digits)-k)

            except Exception as e:
                pass

        log("PLAYBACK LEN: %s" % len(playback))
        log("PLAYBACK: %s" % playback[:300])

        if not playback.startswith("http"):
            log("PLAYBACK INVALIDO")
            return ""

        final=playback+"|User-Agent="+UA+"&Referer=https://streamhdx.com/&Origin=https://streamhdx.com&verifypeer=false&verifyhost=false"

        log("OK URL FINAL")
        return final

    except Exception as e:
        log("ERROR GENERAL: %s" % str(e))
        return ""