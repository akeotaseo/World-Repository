# -*- coding: utf-8 -*-

import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()


class QRWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):

        super(QRWindow, self).__init__()

        self.qr = kwargs.get("qr", "")
        self.texto = kwargs.get("texto", "")
        self.titulo = kwargs.get("titulo", "Código QR")

    def onInit(self):

        # Título
        self.getControl(12001).setLabel(self.titulo)

        # Texto
        self.getControl(12002).setText(self.texto)

        # QR
        self.getControl(12006).setImage(self.qr)

        # Foco
        self.setFocusId(12003)

    def onClick(self, controlId):

        if controlId == 12003:
            self.close()

    def onAction(self, action):

        action_id = action.getId()

        if action_id in [9, 10, 92]:
            self.close()


def show_qr(titulo, texto, qr):

    win = QRWindow(
        'QRWindow.xml',
        ADDON.getAddonInfo('path'),
        'default',
        '1080i',
        titulo=titulo,
        texto=texto,
        qr=qr
    )

    win.doModal()

    del win