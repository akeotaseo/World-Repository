# -*- coding: utf-8 -*-

import re
import requests

UA = "Mozilla/5.0"


def _headers(url):
    headers = {
        "User-Agent": UA,
        "Referer": url
    }

    r = requests.get(
        url,
        headers=headers,
        verify=False,
        timeout=15
    )

    return r.text


def _build(m3u8):

    host = re.search(r'https?://([^/]+)', m3u8)

    if host:
        host = host.group(1)
    else:
        host = ""

    return (
        m3u8 +
        "|User-Agent=" + UA +
        "&Referer=https://" + host + "/" +
        "&Origin=https://" + host +
        "&verifypeer=false&verifyhost=false"
    )


############################################################
# Metodo 1
############################################################

def _method_src(data):

    m = re.search(
        r'src=["\'](https?://.*?m3u8.*?)["\']',
        data,
        re.I
    )

    if m:
        return _build(m.group(1))

    return None


############################################################
# Metodo 2
############################################################

def _method_join(data):

    m = re.search(
        r'return\s*\(\[(.*?)\]\.join',
        data,
        re.S
    )

    if not m:
        return None

    chars = re.findall(r'"(.*?)"', m.group(1))

    if not chars:
        return None

    url = "".join(chars)
    url = url.replace("\\/", "/").strip()

    if ".m3u8" not in url:
        return None

    return _build(url)


############################################################
# Resolver Principal
############################################################

def resolver(url):

    try:
        data = _headers(url)
    except Exception:
        return "NA"

    methods = (
        _method_src,
        _method_join,
    )

    for method in methods:

        try:
            result = method(data)

            if result:
                return result

        except:
            pass

    return "NA"