# -*- coding: utf-8 -*-
import requests
import time
import json
import re
import uuid

# =========================
# LOG KODI / CONSOLA
# =========================
def log(msg):
    try:
        import xbmc
        xbmc.log(f"[VAVOO] {msg}", xbmc.LOGINFO)
    except:
        print("[VAVOO]", msg)

# =========================
# CONFIG
# =========================
AUTH_URL = "https://www.vavoo.tv/api/app/ping"
RESOLVE_URL = "https://vavoo.to/mediahubmx-resolve.json"

_session = requests.Session()
_session.headers.update({
    "User-Agent": "electron-fetch/1.0 electron (+https://github.com/arantes555/electron-fetch)",
    "Accept": "*/*",
    "Accept-Language": "de",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "close"
})

_cache = {"sig": None, "exp": 0}

def get_channels(group="Germany"):
    sig = get_signature()

    headers = {
        "content-type": "application/json",
        "mediahubmx-signature": sig
    }

    data = {
        "language": "de",
        "region": "AT",
        "catalogId": "vto-iptv",
        "id": "vto-iptv",
        "adult": False,
        "search": "",
        "sort": "name",
        "filter": {"group": group},
        "cursor": 0,
        "count": 9999,
        "clientVersion": "3.1.4"
    }

    r = _session.post(
        "https://vavoo.to/mediahubmx-catalog.json",
        headers=headers,
        data=json.dumps(data),
        timeout=10
    )

    js = r.json()

    canales = []

    for item in js.get("items", []):
        name = item.get("name")
        url = item.get("url")

        if name and url:
            canales.append((name, url))

    return canales

# =========================
# 1. FIRMA
# =========================
def get_signature():
    if _cache["sig"] and time.time() < _cache["exp"]:
        log("Usando firma en cache")
        return _cache["sig"]

    log("Solicitando nueva firma REAL...")

    unique_id = uuid.uuid4().hex[:16]

    data = {
        "token": "8Us2TfjeOFrzqFFTEjL3E5KfdAWGa5PV3wQe60uK4BmzlkJRMYFu0ufaM_eeDXKS2U04XUuhbDTgGRJrJARUwzDyCcRToXhW5AcDekfFMfwNUjuieeQ1uzeDB9YWyBL2cn5Al3L3gTnF8Vk1t7rPwkBob0swvxA",
        "reason": "player.enter",
        "locale": "de",
        "theme": "dark",
        "metadata": {
            "device": {
                "type": "Desktop",
                "brand": "Unknown",
                "model": "Unknown",
                "name": "Unknown",
                "uniqueId": unique_id
            },
            "os": {
                "name": "windows",
                "version": "10.0.22631",
                "abis": [],
                "host": "electron"
            },
            "app": {
                "platform": "electron",
                "version": "3.1.4",
                "buildId": "288045000",
                "engine": "jsc",
                "signatures": [],
                "installer": "unknown"
            },
            "version": {
                "package": "tv.vavoo.app",
                "binary": "3.1.4",
                "js": "3.1.4"
            }
        },
        "appFocusTime": 20000,
        "playerActive": True,
        "playDuration": 0,
        "devMode": False,
        "hasAddon": False,
        "castConnected": False,
        "package": "tv.vavoo.app",
        "version": "3.1.4",
        "process": "app",
        "firstAppStart": int(time.time() * 1000) - 86400000,
        "lastAppStart": int(time.time() * 1000),
        "ipLocation": "",
        "adblockEnabled": False,
        "proxy": {
            "supported": ["ss"],
            "engine": "ss",
            "enabled": False,
            "autoServer": True,
            "id": "ca-bhs"
        },
        "iap": {"supported": True}
    }

    headers = {
        "accept": "*/*",
        "user-agent": "electron-fetch/1.0 electron",
        "content-type": "application/json; charset=utf-8"
    }

    for i in range(2):
        try:
            r = _session.post(AUTH_URL, json=data, headers=headers, timeout=15)

            log(f"Status firma: {r.status_code}")

            js = r.json()
            sig = js.get("addonSig")

            if sig:
                log("🔥 Firma REAL obtenida")
                _cache["sig"] = sig
                _cache["exp"] = time.time() + 3600
                return sig

        except Exception as e:
            log(f"Error firma intento {i+1}: {e}")

    log("❌ No se pudo obtener firma")
    return None


# =========================
# 2. FOLLOW REDIRECT
# =========================
def follow(url):
    log(f"Follow URL: {url}")

    try:
        r = _session.get(url, allow_redirects=True, timeout=10, stream=True)
        final = r.url

        log(f"Final redirect: {final}")

        return final

    except Exception as e:
        log(f"Error follow: {e}")
        return url


# =========================
# 3. RESOLVE REAL
# =========================
def resolve(url):
    log(f"Resolviendo: {url}")

    # ❌ NO usar m3u8 directo
    if "live2/play3" in url:
        log("❌ URL VAVOO tipo FAKE (m3u8 placeholder)")
        return None

    sig = get_signature()
    if not sig:
        log("❌ No hay firma")
        return None

    headers = {
        "content-type": "application/json; charset=utf-8",
        "mediahubmx-signature": sig
    }

    data = {
        "language": "de",
        "region": "AT",
        "url": url,
        "clientVersion": "3.1.4"
    }

    try:
        log("POST resolve REAL...")

        r = _session.post(
            RESOLVE_URL,
            data=json.dumps(data),
            headers=headers,
            timeout=10
        )

        log(f"Status resolve: {r.status_code}")
        log(f"Respuesta resolve: {r.text}")

        js = r.json()

        stream = js[0]["url"]
        log(f"Stream base: {stream}")

        final = follow(stream)

        log(f"Stream final: {final}")

        headers_str = (
            "User-Agent=electron-fetch/1.0 electron&"
            "Accept=*/*&"
            "Accept-Encoding=gzip, deflate&"
            "Connection=close&"
            "verifypeer=false&verifyhost=false&"
            f"mediahubmx-signature={sig}&"
            "Referer=https://vavoo.to/&"
            "Origin=https://vavoo.to"
        )

        return f"{final}|{headers_str}"

    except Exception as e:
        log(f"❌ Error resolve: {e}")
        return None

# =========================
# 4. ALIAS PARA REGEX
# =========================
def getstream(url):
    log("🔥 getstream llamado")
    return resolve(url)