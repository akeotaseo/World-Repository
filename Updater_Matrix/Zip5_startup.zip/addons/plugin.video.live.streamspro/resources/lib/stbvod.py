# -*- coding: utf-8 -*-

import requests
import xbmc

requests.packages.urllib3.disable_warnings()


def test_vod(server, mac):

    from resources.lib import stbserver

    token = stbserver.get_token(server, mac)

    headers = stbserver.stb_headers(
        mac,
        token,
        server
    )

    s = requests.Session()

    profile_url = (
        f"http://{server}/portal.php?"
        f"type=stb&action=get_profile&JsHttpRequest=1-xml"
    )

    r = s.get(
        profile_url,
        headers=headers,
        verify=False,
        timeout=15
    )

    xbmc.log("===== PROFILE =====", xbmc.LOGINFO)
    xbmc.log(r.text[:10000], xbmc.LOGINFO)

    urls = [

        f"http://{server}/portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml",

        f"http://{server}/portal.php?type=vod&action=get_ordered_list&category=0&p=1&JsHttpRequest=1-xml",

        f"http://{server}/portal.php?type=vod&action=get_ordered_list&category=979&p=1&JsHttpRequest=1-xml",

        f"http://{server}/server/load.php?type=vod&action=get_categories&JsHttpRequest=1-xml",

        f"http://{server}/server/load.php?type=vod&action=get_ordered_list&category=979&p=1&JsHttpRequest=1-xml",

    ]

    for url in urls:

        try:

            r = s.get(
                url,
                headers=headers,
                verify=False,
                timeout=15
            )

            xbmc.log("===== TEST URL =====", xbmc.LOGINFO)
            xbmc.log(url, xbmc.LOGINFO)
            xbmc.log(r.text[:5000], xbmc.LOGINFO)

        except Exception as e:

            xbmc.log(str(e), xbmc.LOGINFO)

    return """
<items>
<item>
<title>Revisar kodi.log</title>
<link>NA</link>
</item>
</items>
"""