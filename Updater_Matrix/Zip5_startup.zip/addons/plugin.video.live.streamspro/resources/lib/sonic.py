# -*- coding: utf-8 -*-
import re
import requests
import traceback

session = requests.Session()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "*/*",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
}


def decode(encoded):
    clean = encoded.replace('|', '')

    # longitud hexadecimal válida
    if len(clean) % 2 != 0:
        print("HEX IMPAR")
        return None

    try:
        out = ''.join(
            chr(int(clean[i:i+2], 16))
            for i in range(0, len(clean), 2)
        )

        return out[::-1]

    except Exception as e:
        print("DECODE ERROR:", e)
        traceback.print_exc()
        return None


def extract_mp4(url):

    # -------- 1. GET /d/ --------
    r = session.get(url, headers=HEADERS, timeout=10)

    html = r.text

    print("PAGE /d/:", url)
    print(html[:1000])

    # acepta ' o "
    iframe = re.search(
        r'<iframe[^>]+src=[\'"]([^\'"]+)',
        html,
        re.I
    )

    if not iframe:
        print("NO IFRAME")
        return None, None

    embed_url = iframe.group(1)

    if embed_url.startswith("/"):
        base = re.match(r'https?://[^/]+', url).group(0)
        embed_url = base + embed_url

    print("EMBED:", embed_url)

    # -------- 2. GET /e/ --------
    headers_e = HEADERS.copy()
    headers_e["Referer"] = url

    r2 = session.get(
        embed_url,
        headers=headers_e,
        timeout=10
    )

    html_e = r2.text

    print("PAGE /e/:")
    print(html_e[:2000])

    # acepta ' o "
    encoded = re.search(
        r'const\s+_0x1\s*=\s*[\'"]([^\'"]+)',
        html_e,
        re.I
    )

    if not encoded:
        print("NO ENCODED STRING")
        return None, None

    encoded = encoded.group(1)

    print("ENCODED FOUND")

    # -------- 4. Decodificar --------
    mp4 = decode(encoded)

    if not mp4:
        print("NO MP4")
        return None, None

    print("MP4:", mp4)

    return mp4, embed_url


def preload(mp4, referer):

    try:
        session.head(
            mp4,
            headers={
                "User-Agent": HEADERS["User-Agent"],
                "Referer": referer
            },
            timeout=5
        )

    except Exception as e:
        print("PRELOAD ERROR:", e)


def resolve(url):

    for intento in range(2):

        try:

            print("INTENTO:", intento + 1)

            mp4, embed = extract_mp4(url)

            if not mp4:
                continue

            preload(mp4, embed)

            final = (
                mp4 +
                "|Referer=" + embed +
                "&User-Agent=" + HEADERS["User-Agent"]
            )

            print("FINAL:", final)

            return final

        except Exception as e:

            print("RESOLVE ERROR:", e)
            traceback.print_exc()

    return ""