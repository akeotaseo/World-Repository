import requests
from urllib.parse import urljoin

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"

HEADERS = {
    "accept": "*/*",
    "accept-language": "es-ES,es;q=0.9",
    "dnt": "1",
    "origin": "https://fb.undertok.online",
    "referer": "https://fb.undertok.online/",
    "user-agent": UA,

    # 🔥 los headers que pediste
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
}


class HLSProxy:

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(HEADERS)

    # =========================
    # RESOLVE (KODI ENTRY POINT)
    # =========================
    def resolve(self, url):
        print("[PROXY] RESOLVE:", url)

        m3u8 = self._get_m3u8(url)
        if not m3u8:
            return ""

        return m3u8

    # =========================
    # GET M3U8
    # =========================
    def _get_m3u8(self, url):
        try:
            r = self.session.get(url, timeout=15, verify=False)

            print("[PROXY] STATUS M3U8:", r.status_code)

            if r.status_code != 200:
                return None

            return self._rewrite_m3u8(url, r.text)

        except Exception as e:
            print("[PROXY] ERROR M3U8:", str(e))
            return None

    # =========================
    # REWRITE PLAYLIST
    # =========================
    def _rewrite_m3u8(self, base_url, playlist):
        lines = playlist.splitlines()
        out = []

        for line in lines:
            line = line.strip()

            # dejar tags intactos
            if not line or line.startswith("#"):
                out.append(line)
                continue

            # url absoluta
            full_url = urljoin(base_url, line)

            # 🔥 IMPORTANTE: mandar TS a proxy PHP
            proxied = "http://addonbg.co/proxyts.php?ts=" + full_url

            out.append(proxied)

        return "\n".join(out)

    # =========================
    # OPTIONAL: TS FETCH (si lo usas en Python backend)
    # =========================
    def fetch_ts(self, url):
        try:
            r = self.session.get(url, timeout=15, verify=False, stream=True)

            print("[PROXY] TS STATUS:", r.status_code)

            if r.status_code != 200:
                return None

            return r.content

        except Exception as e:
            print("[PROXY] ERROR TS:", str(e))
            return None