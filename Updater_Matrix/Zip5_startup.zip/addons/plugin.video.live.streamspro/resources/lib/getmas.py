# -*- coding: utf-8 -*-
import re
import requests
import base64
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# =========================
# CONFIG
# =========================
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"

session = requests.Session()
session.headers.update({"User-Agent": UA})


# =========================
# KODI HELPERS
# =========================
def notify(msg, title="BLACKGHOST"):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_ERROR, 4000)
    except:
        print("[NOTIFY]", title, msg)


def log(msg):
    try:
        import xbmc
        xbmc.log("[GETMAS] " + str(msg), xbmc.LOGERROR)
    except:
        print("[LOG]", msg)


def fail(msg):
    log("❌ FAIL: " + msg)
    notify(msg)
    return None


# =========================
# HTTP
# =========================
def get(url, referer=None):
    headers = {}
    if referer:
        headers["Referer"] = referer

    log(f"🌐 GET: {url}")

    try:
        r = session.get(url, headers=headers, timeout=15, verify=False)
        log(f"✅ GET OK ({len(r.text)} bytes)")
        return r.text
    except Exception as e:
        log(f"❌ HTTP ERROR: {url} -> {e}")
        return ""


# =========================
# HELPERS
# =========================
def extract_iframes(html):
    ifr = re.findall(r'<iframe[^>]+src="([^"]+)"', html or "")
    log(f"🔎 Iframes encontrados: {len(ifr)}")
    return ifr


def extract_m3u8(html):
    if not html:
        return None
    html = html.replace('\\/', '/')
    m = re.search(r'https?://[^\s"\']+\.m3u8[^\s"\']*', html)
    if m:
        log("🎯 M3U8 detectado directo")
    return m.group(0) if m else None


def headers_kodi(url, origin):
    return url + "|User-Agent=" + UA + "&verifypeer=false&verifyhost=false&verifyssl=false&Referer=" + origin + "&Origin=" + origin


def fix_url(url, referer=None):
    if not url:
        return url

    if url.startswith("//"):
        url = "https:" + url

    if url.startswith("/"):
        if referer:
            from urllib.parse import urljoin
            url = urljoin(referer, url)

    return url


# =========================
# CASO 1 - CAPO
# =========================
def resolve_capo(iframe_url):
    log("🟡 CAPO detectado")

    html = get(iframe_url)

    fid = re.search(r'fid="([^"]+)"', html or "")
    if not fid:
        log("❌ CAPO sin fid")
        return None

    fid = fid.group(1)

    url = f"https://capo8play.com/capo.php?player=mobile&live={fid}"
    html2 = get(url, iframe_url)

    m = re.search(r'\(\[(.*?)\]\.join', html2 or "")
    if not m:
        log("❌ CAPO sin join")
        return None

    chars = re.findall(r'"(.*?)"', m.group(1))
    m3u8 = "".join(chars)

    log("✅ CAPO OK")
    return m3u8 + "|Referer=https://capo8play.com/&User-Agent=" + UA + "&Origin=https://capo8play.com&verifypeer=false&verifyhost=false"


# =========================
# CASO 2 - EMBED
# =========================
def resolve_embed(url, referer=None):
    log("🟣 EMBED detectado")

    try:
        from resources.lib import ws_streams
        url = fix_url(url, referer)
        r = ws_streams.resolve(url, url)
        if r:
            log("✅ EMBED OK")
        return r
    except Exception as e:
        log(f"❌ EMBED ERROR: {e}")
        return None

# =========================
# CASO 2 - streamX
# =========================
def resolve_streamx(url, referer=None):
    log("🟣 EMBED streamx detectado")

    try:
        from resources.lib import streamx
        url = fix_url(url, referer)
        r = streamx.streamhdx(url)
        if r:
            log("✅ EMBED OK")
        return r
    except Exception as e:
        log(f"❌ EMBED ERROR: {e}")
        return None

# =========================
# CASO 3.1 - STREAM
# =========================
def resolve_stream(url):
    log("🔵 STREAM detectado")

    html = get(url)

    if not html:
        log("❌ STREAM sin HTML")
        return None

    # DIRECTO
    m = re.search(r'playbackURL\s*=\s*"([^"]+)"', html)
    if m:
        log("✅ STREAM directo")
        m3u8 = m.group(1)
        return m3u8 + "|User-Agent=" + UA + "&Referer=" + url + "&Origin=" + url

    # OFUSCADO
    log("🔐 STREAM ofuscado")

    m = re.search(r'(?:var|let)\s+playbackURL\s*=\s*""\s*,\s*(\w+)\s*=\s*\[\]', html)
    if not m:
        log("❌ STREAM sin patrón")
        return None

    var_name = m.group(1)

    arr_match = re.search(r'%s=\[(.*?)\];' % var_name, html, re.S)
    if not arr_match:
        log("❌ STREAM sin array")
        return None

    items = re.findall(r'\[(\d+),"([^"]+)"\]', arr_match.group(1))
    if not items:
        log("❌ STREAM sin items")
        return None

    items = sorted([(int(i[0]), i[1]) for i in items], key=lambda x: x[0])

    funcs = re.findall(r'function\s+\w+\(\)\{return\s+(\d+);\}', html)
    if len(funcs) < 2:
        log("❌ STREAM sin funciones k")
        return None

    k = int(funcs[0]) + int(funcs[1])

    playback = ""

    for _, val in items:
        try:
            decoded = base64.b64decode(val).decode()
            num = int(re.sub(r'\D', '', decoded))
            playback += chr(num - k)
        except:
            pass

    if not playback.startswith("http"):
        log("❌ STREAM decode falló")
        return None

    log("✅ STREAM decode OK")
    return playback + "|User-Agent=" + UA + "&Referer=" + url + "&Origin=" + url


# =========================
# CASO 5 - LA14HD
# =========================
def resolve_la14hd(url):
    log("🟢 LA14HD detectado")

    html = get(url, "https://la14hd.com/")
    m = re.search(r'playbackURL\s*=\s*"([^"]+)"', html or "")
    if not m:
        log("❌ LA14HD sin URL")
        return None

    log("✅ LA14HD OK")
    return m.group(1) + "|User-Agent=" + UA

# =========================
# CASO 6 - DEPORTIVO (FIX URL ESCAPADA)
# =========================
def resolve_depo(iframe_url):
    log("🟠 DEPORTIVO detectado")

    try:
        html = get(iframe_url)
        if not html:
            log("❌ HTML vacío")
            return None

        fid_match = re.search(r'fid="([^"]+)"', html)
        if not fid_match:
            log("❌ DEPORTIVO sin fid")
            return None

        fid = fid_match.group(1)
        log(f"🔑 FID: {fid}")

        for player in ["desktop", "mobile"]:
            url = f"https://deepcathink.com/deportivo.php?player={player}&live={fid}"
            log(f"🌐 GET: {url}")

            html2 = get(url, iframe_url)
            if not html2:
                continue

            m = re.search(r'\(\[(.*?)\]\.join', html2)
            if not m:
                continue

            chars = re.findall(r'"(.*?)"', m.group(1))
            m3u8 = "".join(chars).strip()

            # 🔥 LIMPIEZA CLAVE
            m3u8 = m3u8.replace("\\/", "/")

            if not m3u8.startswith("http"):
                log("❌ URL inválida")
                continue

            log(f"🎯 LIMPIO: {m3u8}")

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Referer": "https://deepcathink.com/",
                "Verifyhost": "false",
                "Verifypeer": "false",
                "Verifyssl": "false",
                "Origin": "https://deepcathink.com"
            }

            header_str = "&".join([f"{k}={v}" for k, v in headers.items()])

            final_url = f"{m3u8}|{header_str}"

            log("✅ DEPORTIVO OK (FINAL LISTO)")
            log(f"🚀 FINAL: {final_url[:150]}...")

            return final_url

        log("❌ No se pudo resolver DEPORTIVO")
        return None

    except Exception as e:
        log(f"💥 ERROR DEPORTIVO: {str(e)}")
        return None

# =========================
# RESOLVER
# =========================
def resolve_iframe(url, referer):

    url = fix_url(url, referer)
    log(f"➡️ Resolviendo: {url}")

    # ---- CASOS DIRECTOS ----
    if "playvi" in url:
        r = resolve_capo(url)
        if r:
            return r
        log("⚠️ CAPO fallback")

    if "canalesdeportivos" in url:
        r = resolve_depo(url)
        if r:
            return r
        log("⚠️ DEPORTIVO fallback")

    if "/player/" in url:
        r = resolve_embed(url, referer)
        if r:
            return r

    if "streamtp" in url:
        r = resolve_stream(url)
        if r:
            return r
        log("⚠️ STREAM fallback")

    if "streamx" in url:
        r = resolve_streamx(url)
        if r:
            return r
        log("⚠️ STREAM fallback")

    if "la14hd" in url:
        r = resolve_la14hd(url)
        if r:
            return r

    if "bolaloca" in url:
        r = resolve_embed(url, referer)
        if r:
            return r

    # ---- GET HTML ----
    html = get(url, referer)
    if not html:
        return None

    # ---- M3U8 DIRECTO ----
    m3u8 = extract_m3u8(html)
    if m3u8:
        return headers_kodi(m3u8, url)

    # ---- IFRAmes ----
    iframes = extract_iframes(html)

    for iframe in iframes:
        r = resolve_iframe(iframe, url)
        if r:
            return r

    return None

# =========================
# MAIN
# =========================
def get_stream(url, referer):

    log(f"🚀 INICIO: {url}")

    html = get(url, referer)

    if not html:
        return fail("Error al cargar la página")

    # 🔥 ===== AQUÍ VA EL FIX =====
    if "deepcathink.com/deportivo.php" in url:
        log("🟠 DEPORTIVO DIRECTO detectado")

        m = re.search(r'return\(\[(.*?)\]\.join', html, re.S)
        if m:
            chars = re.findall(r'"(.*?)"', m.group(1))
            m3u8 = "".join(chars).replace("\\/", "/").strip()

            if m3u8.startswith("http"):
                headers = {
                    "User-Agent": UA,
                    "Referer": "https://executeandship.com/",
                    "Origin": "https://executeandship.com",
                    "verifypeer": "false",
                    "verifyhost": "false",
                    "verifyssl": "false"
                }

                header_str = "&".join([f"{k}={v}" for k, v in headers.items()])
                final = f"{m3u8}|{header_str}"

                log("✅ DEPORTIVO DIRECTO OK")
                return final

        log("❌ DEPORTIVO DIRECTO falló")
    # 🔥 ===== FIN DEL FIX =====

    iframes = extract_iframes(html)

    for iframe in iframes:
        r = resolve_iframe(iframe, url)
        if r:
            log("🎉 STREAM FINAL ENCONTRADO")
            return r

    return fail("No se encontró ningún stream válido")