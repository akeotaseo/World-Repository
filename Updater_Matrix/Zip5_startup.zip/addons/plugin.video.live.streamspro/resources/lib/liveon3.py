# -*- coding: utf-8 -*-
import re
import requests
import base64
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# =========================
# CONFIG
# =========================
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/145.0.0.0 Safari/537.36"



# =========================
# KODI HELPERS (opcionales)
# =========================
def log(msg):
    try:
        import xbmc
        xbmc.log("[LIVEON3] " + msg, xbmc.LOGERROR)
    except:
        print("[LIVEON3]", msg)


def notify(msg, title="LIVEON3"):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_ERROR, 4000)
    except:
        print("[NOTIFY]", msg)


# =========================
# HTTP
# =========================
def get(url, referer=None):
    headers = {
        "User-Agent": UA
    }
    if referer:
        headers["Referer"] = referer

    try:
        r = requests.get(url, headers=headers, timeout=10, verify=False)
        return r.text
    except:
        return ""


# =========================
# MAIN RESOLVER
# =========================
def resolve(url, referer=None):

    def fail(msg):
        notify(msg)
        log("FAIL: " + msg)
        return ""

    try:
        log("==== INICIO LIVEON3 ====")

        # =========================
        # SESSION (CLAVE)
        # =========================
        s = requests.Session()

        headers = {
            "User-Agent": UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "es-ES,es;q=0.9",
            "Connection": "keep-alive"
        }

        # =========================
        # STEP 1: antenasport
        # =========================
        headers["Referer"] = referer or "https://antenasport.org/"
        r1 = s.get(url, headers=headers, timeout=10, verify=False)
        html = r1.text

        if not html:
            return fail("No carga antenasport")

        log("STEP1 OK")

        # iframe 1 → play.php
        m1 = re.search(r'<iframe[^>]+src="([^"]+liveon3\.zip/play\.php[^"]+)"', html)
        if not m1:
            return fail("No se encontró iframe play.php")

        iframe1 = m1.group(1)

        if iframe1.startswith("//"):
            iframe1 = "https:" + iframe1

        log("STEP2 iframe1 OK: " + iframe1)

        # =========================
        # STEP 2: play.php
        # =========================
        headers["Referer"] = url
        r2 = s.get(iframe1, headers=headers, timeout=10, verify=False)
        html2 = r2.text

        if not html2:
            return fail("No carga play.php")

        log("STEP2 HTML OK")

        if "embed-play" not in html2:
            log("WARNING: embed-play NO visible en HTML2")

        # iframe 2 → embed-play
        m2 = re.search(r'<iframe[^>]+src="([^"]+embed-play\.php[^"]+)"', html2)
        if not m2:
            return fail("No se encontró iframe embed-play")

        iframe2 = m2.group(1)

        if iframe2.startswith("//"):
            iframe2 = "https:" + iframe2

        log("STEP3 iframe2 OK")

        # =========================
        # STEP 3: embed-play
        # =========================
        headers["Referer"] = iframe1
        r3 = s.get(iframe2, headers=headers, timeout=10, verify=False)
        html3 = r3.text

        if not html3:
            return fail("No carga embed-play")

        log("STEP3 HTML OK")

        # =========================
        # 🔥 CAPTURAR X-AUTH (CLAVE)
        # =========================
        xauth = r3.headers.get("XAUTH") or r3.headers.get("Xauth")

        if xauth:
            log("XAUTH OK")
        else:
            log("WARNING: No se encontró XAUTH")

        # =========================
        # STEP 4: BASE64
        # =========================
        m3 = re.search(r'id="crf__"\s+value=[\'"]([^\'"]+)', html3)
        if not m3:
            return fail("No se encontró base64")

        b64 = m3.group(1)
        log("BASE64 OK")

        # =========================
        # STEP 5: DECODE
        # =========================
        try:
            m3u8 = base64.b64decode(b64).decode()
        except Exception as e:
            log("ERROR BASE64: " + str(e))
            return fail("Error decodificando base64")

        if not m3u8.startswith("http"):
            return fail("M3U8 inválido")

        log("M3U8 OK")

        # =========================
        # 🔥 HEADERS FINALES
        # =========================
        headers_final = (
            "User-Agent=" + UA +
            "&Referer=https://liveon3.zip/" +
            "&Origin=https://liveon3.zip" +
            "&verifypeer=false&verifyhost=false"
        )

        # agregar X-Auth si existe
        if xauth:
            headers_final += "&X-Auth=" + xauth

        # ⚠️ OPCIONAL: usar referer exacto del embed (más preciso)
        headers_final = headers_final.replace(
            "Referer=https://liveon3.zip/",
            "Referer=" + iframe2
        )

        log("==== FINAL OK ====")

        return m3u8 + "|" + headers_final

    except Exception as e:
        log("ERROR GENERAL: " + str(e))
        notify("Error en resolver")
        return ""