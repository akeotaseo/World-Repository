# -*- coding: utf-8 -*-
import re
import base64
import requests

def streamtp(url):

    try:

        UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0"
        origin = "https://streamtp-abc.net/"

        headers = {
            "User-Agent": UA,
            "Referer": url,
            "Origin": origin
        }

        r = requests.get(url, headers=headers, timeout=10)
        html = r.text

        # obtener array ofuscado
        m = re.search(
            r'=\s*(\[\[\d+,"[A-Za-z0-9+/=]+"\].*?\]\])',
            html,
            re.S
        )

        if not m:
            return ""

        arr = eval(m.group(1))
        arr.sort(key=lambda x: x[0])

        # obtener claves
        keys = re.findall(r'return\s*(\d+)', html)

        if len(keys) < 2:
            return ""

        k = int(keys[0]) + int(keys[1])

        playback = ""

        for pos, b64 in arr:

            decoded = base64.b64decode(b64).decode(errors="ignore")
            digits = re.sub(r'\D', '', decoded)

            if digits:
                playback += chr(int(digits) - k)

        return (
            playback +
            "|User-Agent=" + UA +
            "&Referer=" + url +
            "&Origin=" + origin +
            "&verifypeer=false&verifyhost=false"
        )

    except Exception:
        return ""