# -*- coding: utf-8 -*-

import os
import re
import json
import time
import gzip
import zlib
import struct
import threading
import http.server

from urllib.parse import urlparse, parse_qs, quote_plus, urljoin

import requests
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui


TAG = '[ Daddylive SegmentProxy ]'
TIMEOUT = 10
TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47
TIK_RAW = b'TIKTIKRAW'
TIK_GZ = b'TIKTIKTSGZ'
TIK_PIX = b'TIKTIKPX'
PORT_PROPERTY = 'daddylive.segmentproxy.port'
DIR_PROPERTY = 'daddylive.segmentproxy.manifestdir'
MANIFEST_REFRESH_INTERVAL = 2.0
ADDON = xbmcaddon.Addon(id='plugin.video.daddylive')

_manifest_dir = None
_manifest_cache = {}
_manifest_cache_lock = threading.Lock()
_manifest_sessions = {}

def log(msg, level=xbmc.LOGINFO):
    # Keep warning/error; gate info/debug behind Advanced -> Enable Debug Logging.
    if level <= xbmc.LOGINFO and ADDON.getSetting('debug_log') != 'true':
        return
    xbmc.log(f'{TAG} {msg}', level)

def _get_with_retry(url, headers=None, session=None, attempts=3, backoff=0.3):
    getter = session.get if session is not None else requests.get
    last_exc = None
    for attempt in range(attempts):
        try:
            return getter(url, headers=headers or {}, timeout=TIMEOUT)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            last_exc = e
            if attempt < attempts - 1:
                time.sleep(backoff * (attempt + 1))
    raise last_exc

def _is_ts(data, offset=0):
    return len(data) > offset + TS_PACKET_SIZE and data[offset] == TS_SYNC_BYTE and data[offset + TS_PACKET_SIZE] == TS_SYNC_BYTE

def _find_ts_start(data):
    limit = len(data) - (4 * TS_PACKET_SIZE)
    offset = data.find(b'G')
    while 0 <= offset < limit:
        if all(data[offset + k * TS_PACKET_SIZE] == TS_SYNC_BYTE for k in range(1, 5)):
            return offset
        offset = data.find(b'G', offset + 1)
    return -1

def _webp_exif_ts(data):
    if len(data) < 16 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        return None
    offset = 12
    while offset + 8 <= len(data):
        tag = data[offset:offset + 4]
        size = struct.unpack_from('<I', data, offset + 4)[0]
        offset += 8
        if offset + size > len(data):
            return None
        if tag == b'EXIF':
            chunk = data[offset:offset + size]
            return chunk if _is_ts(chunk) else None
        offset += size + (size & 1)
    return None

def _png_chunks(data):
    offset = 8
    while offset + 8 <= len(data):
        size = struct.unpack_from('>I', data, offset)[0]
        if size > len(data) - offset - 12:
            return
        yield data[offset + 4:offset + 8], data[offset + 8:offset + 8 + size], offset + 12 + size
        offset += 12 + size

def _png_iend_ts(data):
    for ctype, _, end in _png_chunks(data):
        if ctype == b'IEND':
            return data[end:] if _is_ts(data, end) else None
    return None

def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    return b if pb <= pc else c

def _png_rgb(data):
    width = height = depth = ctype = interlace = 0
    idat = []
    for name, chunk, _ in _png_chunks(data):
        if name == b'IHDR':
            width, height, depth, ctype, _c, _f, interlace = struct.unpack('>IIBBBBB', chunk[:13])
        elif name == b'IDAT':
            idat.append(chunk)
        elif name == b'IEND':
            break
    if not width or not height or depth != 8 or interlace or ctype not in (2, 6):
        return None
    raw = zlib.decompress(b''.join(idat))
    bpp = 4 if ctype == 6 else 3
    stride = width * bpp
    rgb = bytearray()
    prev = bytearray(stride)
    src = 0
    for _ in range(height):
        if src + 1 + stride > len(raw):
            return None
        ftype = raw[src]
        row = raw[src + 1:src + 1 + stride]
        src += 1 + stride
        if ftype == 0:
            recon = bytearray(row)
        elif ftype == 2:
            recon = bytearray((x + y) & 255 for x, y in zip(row, prev))
        elif ftype in (1, 3, 4):
            recon = bytearray(stride)
            for i in range(stride):
                left = recon[i - bpp] if i >= bpp else 0
                if ftype == 1:
                    value = row[i] + left
                elif ftype == 3:
                    value = row[i] + ((left + prev[i]) >> 1)
                else:
                    value = row[i] + _paeth(left, prev[i], prev[i - bpp] if i >= bpp else 0)
                recon[i] = value & 255
        else:
            return None
        if ctype == 2:
            rgb += recon
        else:
            pixels = bytearray(recon)
            del pixels[3::4]
            rgb += pixels
        prev = recon
    return bytes(rgb)

def _png_pixels_ts(data):
    rgb = _png_rgb(data)
    if not rgb or len(rgb) < 12 or rgb[:8] != TIK_PIX:
        return None
    size = struct.unpack_from('>I', rgb, 8)[0]
    if size <= 0 or 12 + size > len(rgb):
        return None
    packed = rgb[12:12 + size]
    if packed[:2] != b'\x1f\x8b':
        return None
    ts = gzip.decompress(packed)
    return ts if ts[:1] == b'G' else None

def _unwrap_segment(data):
    ts = _webp_exif_ts(data)
    if ts:
        return ts
    if data[:2] == b'\x89P':
        ts = _png_iend_ts(data)
        if ts:
            return ts
        try:
            ts = _png_pixels_ts(data)
        except Exception:
            ts = None
        return ts if ts else data
    offset = data.find(TIK_RAW)
    while offset >= 0:
        if data[offset + len(TIK_RAW):offset + len(TIK_RAW) + 1] == b'G':
            return data[offset + len(TIK_RAW):]
        offset = data.find(TIK_RAW, offset + 1)
    offset = data.find(TIK_GZ)
    if offset >= 0:
        try:
            return gzip.decompress(data[offset + len(TIK_GZ):])
        except Exception:
            pass
    offset = _find_ts_start(data)
    return data[offset:] if offset > 0 else data

def _rewrite_manifest(manifest_text, base_url, port, manifest_id):
    mid = quote_plus(manifest_id)
    lines = []
    for line in manifest_text.splitlines():
        stripped = line.strip()
        if stripped.startswith('#EXT-X-KEY') and 'URI="' in stripped:
            lines.append(re.sub(
                r'URI="([^"]+)"',
                lambda m: f'URI="http://127.0.0.1:{port}/key?mid={mid}&url={quote_plus(urljoin(base_url, m.group(1)))}"',
                stripped
            ))
        elif stripped.startswith('#EXT-X-MAP') and 'URI="' in stripped:
            lines.append(re.sub(
                r'URI="([^"]+)"',
                lambda m: f'URI="http://127.0.0.1:{port}/seg?mid={mid}&url={quote_plus(urljoin(base_url, m.group(1)))}"',
                stripped
            ))
        elif stripped and not stripped.startswith('#'):
            abs_url = urljoin(base_url, stripped)
            route = 'submanifest' if urlparse(abs_url).path.lower().endswith('.m3u8') else 'seg'
            lines.append(f'http://127.0.0.1:{port}/{route}?mid={mid}&url={quote_plus(abs_url)}')
        else:
            lines.append(line)
    return '\n'.join(lines)

def _recipe_path(manifest_id):
    return os.path.join(_manifest_dir, f'{os.path.basename(manifest_id)}.json')

def _read_recipe(manifest_id):
    try:
        with open(_recipe_path(manifest_id), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def _get_manifest_session(manifest_id):
    with _manifest_cache_lock:
        s = _manifest_sessions.get(manifest_id)
        if s is None:
            s = requests.Session()
            _manifest_sessions[manifest_id] = s
        return s

def _fetch_and_rewrite(manifest_id, recipe, port, attempts=3):
    try:
        resp = _get_with_retry(recipe['url'], headers=recipe.get('headers'), session=_get_manifest_session(manifest_id), attempts=attempts)
        if resp.status_code != 200:
            log(f'manifest bad status {resp.status_code} | {recipe["url"]}', xbmc.LOGERROR)
            return None
        text = resp.text
        if not text.lstrip().startswith('#EXTM3U'):
            log(f'manifest invalid | {recipe["url"]} | body: {text[:200]!r}', xbmc.LOGERROR)
            return None
        rewritten = _rewrite_manifest(text, resp.url, port, manifest_id)
        with _manifest_cache_lock:
            _manifest_cache[manifest_id] = {'data': rewritten, 'time': time.time(), 'refreshing': False}
        return rewritten
    except Exception as e:
        log(f'manifest fetch error: {e}', xbmc.LOGERROR)
        return None

def _background_refresh(manifest_id, recipe, port):
    try:
        _fetch_and_rewrite(manifest_id, recipe, port)
    finally:
        with _manifest_cache_lock:
            entry = _manifest_cache.get(manifest_id)
            if entry is not None:
                entry['refreshing'] = False

class _Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    def _send(self, status, payload=b'', content_type='application/octet-stream'):
        try:
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        except Exception:
            pass

    def do_GET(self):
        parsed = urlparse(self.path)
        port = self.server.server_address[1]
        if parsed.path.startswith('/manifest/'):
            manifest_id = parsed.path[len('/manifest/'):]
            if manifest_id.endswith('.m3u8'):
                manifest_id = manifest_id[:-5]
            recipe = _read_recipe(manifest_id)
            if recipe is None:
                return self._send(404)
            with _manifest_cache_lock:
                cached = _manifest_cache.get(manifest_id)
            if cached is None:
                rewritten = _fetch_and_rewrite(manifest_id, recipe, port, attempts=1)
                if rewritten is None:
                    return self._send(502)
            else:
                rewritten = cached['data']
                if time.time() - cached['time'] >= MANIFEST_REFRESH_INTERVAL and not cached.get('refreshing'):
                    cached['refreshing'] = True
                    threading.Thread(target=_background_refresh, args=(manifest_id, recipe, port), name='DaddyliveManifestRefresh', daemon=True).start()
            return self._send(200, rewritten.encode('utf-8'), 'application/vnd.apple.mpegurl')
        qs = parse_qs(parsed.query)
        target = qs.get('url', [None])[0]
        if not target:
            return self._send(400)
        manifest_id = qs.get('mid', [''])[0]
        headers = (_read_recipe(manifest_id) or {}).get('headers') or {}
        try:
            resp = _get_with_retry(target, headers=headers)
            if resp.status_code != 200:
                log(f'{parsed.path} bad status {resp.status_code} | {target}', xbmc.LOGERROR)
                return self._send(502)
            if parsed.path == '/submanifest':
                text = resp.text
                if not text.lstrip().startswith('#EXTM3U'):
                    log(f'submanifest invalid | {target} | body: {text[:200]!r}', xbmc.LOGERROR)
                    return self._send(502)
                return self._send(200, _rewrite_manifest(text, resp.url, port, manifest_id).encode('utf-8'), 'application/vnd.apple.mpegurl')
            if parsed.path == '/key':
                return self._send(200, resp.content)
            return self._send(200, _unwrap_segment(resp.content), 'video/mp2t')
        except Exception as e:
            log(f'{parsed.path} fetch error {target}: {e}', xbmc.LOGERROR)
            return self._send(502)

def start():
    global _manifest_dir
    _manifest_dir = xbmcvfs.translatePath('special://temp/daddylive_manifests/')
    os.makedirs(_manifest_dir, exist_ok=True)
    for name in os.listdir(_manifest_dir):
        try:
            os.remove(os.path.join(_manifest_dir, name))
        except Exception:
            pass
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
    server.daemon_threads = True
    port = server.server_address[1]
    threading.Thread(target=server.serve_forever, name='DaddyliveSegmentProxy', daemon=True).start()
    win = xbmcgui.Window(10000)
    win.setProperty(PORT_PROPERTY, str(port))
    win.setProperty(DIR_PROPERTY, _manifest_dir)
    log(f'started on 127.0.0.1:{port}, manifest dir={_manifest_dir}')
    return server

if __name__ == '__main__':
    proxy = start()
    xbmc.Monitor().waitForAbort()
    win = xbmcgui.Window(10000)
    win.clearProperty(PORT_PROPERTY)
    win.clearProperty(DIR_PROPERTY)
    proxy.shutdown()
    proxy.server_close()
