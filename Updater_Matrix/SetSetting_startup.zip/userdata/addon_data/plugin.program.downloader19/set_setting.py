﻿# -*- coding: utf-8 -*-
import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("Ρυθμίσεις......", "addon_data", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png', sound=False)
from updatervar import *

Dialog_U1                 = '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]'
Dialog_U3                 = '[B]Διορθωση Settings[/B]'
Dialog_U4                 = '[B]Ολοκληρώθηκε με επιτυχία[/B]'


def set_setting():
   ###  Blacklodge  ###
    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.blacklodge')):
        # 🚀 Βάζουμε το '60' ως string και αναγκάζουμε το Kodi να κάνει flush (save) στον δίσκο
        addon_bl = xbmcaddon.Addon('plugin.video.blacklodge')
        addon_bl.setSetting('items.per.page', '60')
        addon_bl.setSetting('movie.download.path', 'special://home/media/Downloads/Blacklodge/')
        addon_bl.setSetting('tv.download.path', 'special://home/media/Downloads/Blacklodge/')
        addon_bl.setSetting('subtitles.lang.1', 'Greek')
        addon_bl.setSetting('subtitles.lang.2', 'English')
        addon_bl.setSetting('remove.keywords', 'Dublado,Dubbed,Dub,Dual,Latino,LATiNO,KORSUB,Hindi,HC,HDCAM,HDTC,HDRip,3D,3d,h264rus,iTA,Ita,iTALiAN,FRENCH,HDTS,HD.TS,CAM,HDCAM')
        
    ###  TmdbMovies  ###
    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.tmdbmovies')):
        addon_tmdbmovies       = xbmcaddon.Addon('plugin.video.tmdbmovies')
        setting_tmdbmovies     = addon_tmdbmovies.getSetting
        setting_set_tmdbmovies = addon_tmdbmovies.setSetting
        if not setting_tmdbmovies('use_osv3_subs')=='true':
            xbmc.sleep(500)
            setting_set_set_tmdbmovies = addon_tmdbmovies.setSetting
            addon_tmdbmovies.setSetting('use_osv3_subs', 'true')

    ###  DaddyLive  ###
    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.daddylive')):
        addon_daddylive       = xbmcaddon.Addon('plugin.video.daddylive')
        setting_daddylive     = addon_daddylive.getSetting
        setting_set_daddylive = addon_daddylive.setSetting
        if not setting_daddylive('time_format')=='1':
            xbmc.sleep(500)
            setting_set_daddylive('time_format', '1')
        if not setting_daddylive('mode')=='1':
            xbmc.sleep(500)
            setting_set_daddylive('mode', '1')

    ###  F4mTester  ###
    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.f4mTester')):
        addon_f4mTester       = xbmcaddon.Addon('plugin.video.f4mTester')
        setting_f4mTester     = addon_f4mTester.getSetting
        setting_set_f4mTester = addon_f4mTester.setSetting
        if setting_f4mTester('ask')=='false':
            xbmc.sleep(500)
            setting_set_f4mTester('ask', 'true')
        if setting_f4mTester('player_type')=='1':
            xbmc.sleep(500)
            setting_set_f4mTester('player_type', '0')

    ###  Scrapee  ###
    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.scrapee')):
        addon_scrapee       = xbmcaddon.Addon('plugin.video.scrapee')
        setting_scrapee     = addon_scrapee.getSetting
        setting_set_scrapee = addon_scrapee.setSetting
        
        if setting_scrapee('movie_download_directory')=='special://profile/addon_data/plugin.video.scrapee/Movies Downloads/':
            xbmc.sleep(500)
            setting_set_scrapee('movie_download_directory', 'special://home/media/Downloads/Scrapee')

        if setting_scrapee('tvshow_download_directory')=='special://profile/addon_data/plugin.video.scrapee/TV Show Downloads/':
            xbmc.sleep(500)
            setting_set_scrapee('tvshow_download_directory', 'special://home/media/Downloads/Scrapee')

        if setting_scrapee('premium_download_directory')=='special://profile/addon_data/plugin.video.scrapee/Premium Downloads/':
            xbmc.sleep(500)
            setting_set_scrapee('premium_download_directory', 'special://home/media/Downloads/Scrapee')

        if setting_scrapee('image_download_directory')=='special://profile/addon_data/plugin.video.scrapee/Image Downloads/':
            xbmc.sleep(500)
            setting_set_scrapee('image_download_directory', 'special://home/media/Downloads/Scrapee')

# Δημιουργία και κλείσιμο του Progress Background
BG.create(Dialog_U1, Dialog_U4)
xbmc.sleep(2000)
BG.update(50, Dialog_U1, Dialog_U3)
xbmc.sleep(2000)
BG.update(100, Dialog_U1, Dialog_U4)
xbmc.sleep(2000)
BG.close()

# Εκτέλεση των ρυθμίσεων
set_setting()
